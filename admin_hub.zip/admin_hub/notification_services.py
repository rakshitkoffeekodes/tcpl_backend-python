import requests

def mobicomm_submit_sms(contact_no, code):
    # Prepare the SMS content
    message = f"Your One Time Verification Code for Tapi Cashless login is {code},Please do not share it with anyone. Thanks Tapi Cashless."

    # Replace the placeholders with actual values
    sms_url = "https://mobicomm.dove-sms.com/submitsms.jsp"
    sms_params = {
        'user': 'TAPICASH',
        'key': '66a1621a84XX',
        'mobile': f"+91{contact_no}",
        'message': message,
        'senderid': 'TAPICL',
        'accusage': '1',
        'entityid': '1701172165114242200',
        'tempid': '1707172206814737429'
    }

    # Send the SMS using a GET request
    response = requests.get(sms_url, params=sms_params)

    return response
