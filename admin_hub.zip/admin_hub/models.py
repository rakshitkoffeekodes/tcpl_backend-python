from django.db import models


class PgTrnChoice(models.TextChoices):
    PENDING = 'PENDING'
    COMPLETED = 'COMPLETED'
    FAILED = 'FAILED'
    SETTLED = 'SETTLED'


class MrkTyChoice(models.TextChoices):
    CR = 'CR' 
    DR = 'DR'


class RequestStatus(models.TextChoices):
    PENDING = 'PENDING'
    APPROVED = 'APPROVED'
    REJECTED = 'REJECTED'
    REVERSED = 'REVERSED'


class TransactionMode(models.TextChoices):
        IMPS = 'IMPS'
        RTGS = 'RTGS'
        NEFT = 'NEFT'


class AdHSNSAC(models.Model):
    hsnsac_id = models.AutoField(primary_key=True)
    hsnsac_code = models.CharField(max_length=255)
    tax_rate = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        'PortalUser', on_delete=models.PROTECT, db_column='created_by', null=True)
    updated_at = models.DateTimeField(null=True)
    is_deactive = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)

    def __str__(self):
        return self.hsnsac_code

    class Meta:
        db_table = "ad_hsn_sac_code"
        app_label = 'admin_hub'


class AdService(models.Model):
    service_id = models.AutoField(primary_key=True)
    service_name = models.CharField(max_length=50)
    description = models.TextField(null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        'PortalUser', on_delete=models.PROTECT, db_column='created_by', null=True)
    updated_at = models.DateTimeField(null=True)
    is_deactive = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)

    def __str__(self):
        return self.service_name

    class Meta:
        db_table = "ad_service"
        app_label = 'admin_hub'


class AdServiceProvider(models.Model):
    sp_id = models.AutoField(primary_key=True)
    service = models.ForeignKey(
        AdService, on_delete=models.CASCADE)
    sp_name = models.CharField(max_length=150, null=True)
    label = models.CharField(max_length=255, null=True)
    tds_rate = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    created_by = models.ForeignKey(
        'PortalUser', on_delete=models.PROTECT, db_column='created_by', null=True)
    hsn_sac = models.ForeignKey(AdHSNSAC, on_delete=models.CASCADE, null=True)
    updated_at = models.DateTimeField(null=True)
    is_deactive = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)

    def __str__(self):
        return self.sp_name

    class Meta:
        db_table = "ad_service_provider"
        app_label = 'admin_hub'


class AdCharges(models.Model):
    CHARGES_TYPE_CHOICES = [
        ('CR', 'Credit'),
        ('DR', 'Debit'),
    ]

    CHARGES_RATE_TYPE_CHOICES = [
        ('is_flat', 'Is_Flat'),
        ('is_percent', 'Is_Percent'),
    ]
    CHARGE_CATEGORY_CHOICES = [
        ('to_us', 'To Us'),
        ('to_provide', 'To Provide'),
    ]
    charges_id = models.AutoField(primary_key=True)
    service_provider = models.ForeignKey(
        AdServiceProvider, on_delete=models.CASCADE)
    charges_type = models.CharField(max_length=2, choices=CHARGES_TYPE_CHOICES)
    rate_type = models.CharField(
        max_length=20, choices=CHARGES_RATE_TYPE_CHOICES)
    minimum = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    maximum = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    rate = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True)
    charge_category = models.CharField(
        max_length=20, choices=CHARGE_CATEGORY_CHOICES, default='to_us')
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        'PortalUser', on_delete=models.CASCADE, db_column='created_by', null=True, blank=True)
    updated_at = models.DateTimeField(null=True)
    is_deactive = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.charges_id} ({self.service_provider.sp_name})"

    class Meta:
        db_table = 'ad_charges'
        app_label = 'admin_hub'


class AdCommissionCharges(models.Model):
    CHARGES_TYPE_CHOICES = [
        ('CR', 'Credit'),
        ('DR', 'Debit'),
    ]

    CHARGES_RATE_TYPE_CHOICES = [
        ('is_flat', 'Is_Flat'),
        ('is_percent', 'Is_Percent'),
        ('is_slab', 'Is_Slab'),
    ]

    commission_charges_id = models.AutoField(primary_key=True)
    service_provider = models.ForeignKey(
        AdServiceProvider, on_delete=models.CASCADE)
    charges_type = models.CharField(max_length=2, choices=CHARGES_TYPE_CHOICES)
    rate_type = models.CharField(
        max_length=20, choices=CHARGES_RATE_TYPE_CHOICES)
    minimum = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    maximum = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    rate = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        'PortalUser', on_delete=models.CASCADE, db_column='created_by', null=True, blank=True)
    updated_at = models.DateTimeField(null=True)
    is_deactive = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.commission_charges_id} ({self.service_provider.sp_name})"

    class Meta:
        db_table = 'ad_commission_charges'
        app_label = 'admin_hub'


class PortalUser(models.Model):
    PORTAL_USER_TYPE = [
        ('Admin', 'Admin'),
        ('Distributor', 'Distributor'),
        ('Retailer', 'Retailer'),
    ]
    id = models.AutoField(primary_key=True)
    pu_name = models.CharField(max_length=150)
    pu_email = models.CharField(max_length=50)
    pu_contact_no = models.CharField(max_length=10, unique=True)
    pu_login_pin = models.CharField(max_length=128, null=True, blank=True)
    pu_role = models.CharField(max_length=20, choices=PORTAL_USER_TYPE)
    verify_code = models.CharField(max_length=128, blank=True, null=True)
    verify_code_expire_at = models.DateTimeField(blank=True, null=True)
    is_verify = models.BooleanField(default=False)
    is_kyc_verify = models.BooleanField(default=False, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(null=True)
    is_deactive = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.id} ({self.pu_role})"

    class Meta:
        db_table = 'ad_portal_user'
        app_label = 'admin_hub'


class PortalUserLoginLogs(models.Model):
    id = models.AutoField(primary_key=True)
    pu_user = models.ForeignKey(PortalUser, on_delete=models.PROTECT)
    pu_user_role = models.CharField(max_length=50)
    pu_token = models.CharField(max_length=300, null=True, blank=True)
    is_expire = models.BooleanField(default=False, null=True, blank=True)
    expire_datetime = models.DateTimeField(null=True, blank=True)
    browser_type = models.CharField(max_length=100, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.id} ({self.pu_user})"

    class Meta:
        db_table = 'ad_portal_user_login_logs'
        app_label = 'admin_hub'


class PortalUserDetails(models.Model):
    pud_id = models.AutoField(primary_key=True)
    pu = models.ForeignKey(PortalUser, on_delete=models.PROTECT)
    pud_unique_id = models.CharField(max_length=8, null=True, blank=True)
    aadhaar_card = models.CharField(max_length=12, null=True, blank=True)
    pan_card = models.CharField(max_length=10, null=True, blank=True)
    pan_response = models.TextField(null=True, blank=True)
    dst_rtl_image = models.ImageField(upload_to='Retailer', null=True, blank=True)
    dst_rtl_location = models.JSONField(null=True, blank=True)
    shop_name = models.CharField(max_length=255, null=True, blank=True)
    shop_address = models.TextField(null=True, blank=True)
    shop_state = models.IntegerField(null=True, blank=True)
    shop_city = models.IntegerField(null=True, blank=True)
    shop_zip_code = models.CharField(max_length=6, null=True, blank=True)
    doc_images = models.JSONField(null=True, blank=True)
    shop_location = models.JSONField(null=True, blank=True)
    shop_gst_number = models.CharField(max_length=15, unique=True, null=True, blank=True)
    busniess_type = models.CharField(max_length=10, null=True, blank=True)
    alternate_contact_no = models.CharField(max_length=10, null=True, blank=True)
    address = models.TextField(null=True, blank=True)
    state_id = models.IntegerField(null=True, blank=True)
    city_id = models.IntegerField(null=True, blank=True)
    zip_code = models.CharField(max_length=6, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(null=True, blank=True)

    def __str__(self) -> str:
        return f"{self.pud_id}"

    class Meta:
        db_table = 'ad_portal_user_details'
        app_label = 'admin_hub'


class PortalUserWallet(models.Model):
    puw_id = models.AutoField(primary_key=True)
    pu = models.ForeignKey(PortalUser, on_delete=models.PROTECT)
    main_wallet = models.DecimalField(max_digits=19, decimal_places=2, default=0.00)
    commission_wallet = models.DecimalField(max_digits=19, decimal_places=2, null=True, blank=True)
    cashin_wallet = models.DecimalField(max_digits=19, decimal_places=2, null=True, blank=True)
    pg_wallet = models.DecimalField(max_digits=19, decimal_places=2, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(null=True)
    updated_by = models.IntegerField(null=True, db_column='updated_by')

    def __str__(self):
        return f"{self.puw_id}"

    class Meta:
        db_table = 'ad_portal_user_wallet'
        app_label = 'admin_hub'


class DistributorHierarchy(models.Model):
    dh_id = models.AutoField(primary_key=True)
    dh_name = models.CharField(max_length=150, unique=True)
    dh_parent_id = models.IntegerField(null=True, blank=True)
    dh_description = models.TextField()
    dh_prefix = models.CharField(max_length=6, null=True, blank=True)
    is_used = models.BooleanField(default=False)
    is_deactive = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        PortalUser, on_delete=models.PROTECT, db_column='created_by', null=True)
    updated_at = models.DateTimeField(null=True)
    updated_by = models.IntegerField(null=True, db_column='updated_by')

    def __str__(self) -> str:
        return super().__str__()

    class Meta:
        db_table = 'ad_distributor_hierarchy'
        app_label = 'admin_hub'


class HierarchyCharges(models.Model):
    hc_id = models.AutoField(primary_key=True)
    dh = models.ForeignKey(DistributorHierarchy, on_delete=models.PROTECT, null=True)
    sp = models.ForeignKey(AdServiceProvider, on_delete=models.PROTECT, null=True)
    mark_type = models.CharField(max_length=10, choices=MrkTyChoice.choices, null=True)
    hc_charges = models.JSONField(null=True)
    is_deactive = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        PortalUser, on_delete=models.PROTECT, db_column='created_by', null=True)
    updated_at = models.DateTimeField(null=True)
    updated_by = models.IntegerField(null=True, db_column='updated_by')

    def __str__(self) -> str:
        return super().__str__()

    class Meta:
        db_table = 'ad_hierarchy_charges'
        app_label = 'admin_hub'


class PortalUserCharges(models.Model):
    puc_id = models.AutoField(primary_key=True)
    sp = models.ForeignKey(AdServiceProvider, on_delete=models.PROTECT, null=True)
    dh = models.ForeignKey(DistributorHierarchy, on_delete=models.PROTECT, null=True)
    pu_id = models.IntegerField(null=True)
    parent_id = models.IntegerField(null=True)
    mark_type = models.CharField(max_length=10, choices=MrkTyChoice.choices, null=True)
    puc_charges = models.JSONField(null=True)
    is_pinned = models.BooleanField(default=False)
    is_deactive = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        PortalUser, on_delete=models.PROTECT, db_column='created_by', null=True)
    updated_at = models.DateTimeField(null=True)
    updated_by = models.IntegerField(null=True, db_column='updated_by')

    def __str__(self) -> str:
        return super().__str__()

    class Meta:
        db_table = 'ad_portal_user_charges'
        app_label = 'admin_hub'


class UserCodeVerification(models.Model):
    ucv_id = models.AutoField(primary_key=True)
    ucv_data = models.CharField(max_length=30)
    verify_code = models.CharField(max_length=128, blank=True, null=True)
    verify_code_expire_at = models.DateTimeField(blank=True, null=True)
    is_verify = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return super().__str__()

    class Meta:
        db_table = 'ad_user_code_verification'
        app_label = 'admin_hub'


class BankDetails(models.Model):
    bd_id = models.AutoField(primary_key=True)
    deposite_category = models.JSONField()
    bank_name = models.CharField(max_length=128, blank=True, null=True)
    ifsc_code = models.CharField(max_length=128, blank=True, null=True)
    branch_name = models.CharField(max_length=128, blank=True, null=True)
    account_type = models.CharField(max_length=128, blank=True, null=True)
    account_number = models.CharField(max_length=128, blank=True, null=True)
    is_deactive = models.BooleanField(default=False)
    is_delete = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        PortalUser, on_delete=models.PROTECT, db_column='created_by', null=True, blank=True)
    updated_at = models.DateTimeField(null=True, blank=True)
    updated_by = models.IntegerField(null=True, blank=True, db_column='updated_by')
   
    def __str__(self) -> str:
        return super().__str__()

    class Meta:
        db_table = 'ad_bank_detail'
        app_label = 'admin_hub'


class FundRequest(models.Model):
    fr_id = models.AutoField(primary_key=True)
    deposite_category = models.JSONField()
    deposite_bank = models.ForeignKey(BankDetails, on_delete=models.PROTECT)
    deposite_amount = models.DecimalField(max_digits=19, decimal_places=2, null=True)
    transaction_id = models.CharField(max_length=128, blank=True, null=True)
    utr_number = models.CharField(max_length=128, blank=True, null=True)
    transaction_mode = models.CharField(choices=TransactionMode, max_length=128, blank=True, null=True)
    payment_proof = models.JSONField()
    remark = models.TextField(blank=True, null=True)
    is_deactive = models.BooleanField(default=False)
    is_delete = models.BooleanField(default=False)
    request_status = models.CharField(choices=RequestStatus, max_length=100, default=RequestStatus.PENDING)
    reasons = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        PortalUser, on_delete=models.PROTECT, db_column='created_by', null=True)
    updated_at = models.DateTimeField(null=True)
    updated_by = models.IntegerField(null=True, db_column='updated_by')
   
    def __str__(self) -> str:
        return super().__str__()

    class Meta:
        db_table = 'ad_fund_request'
        app_label = 'admin_hub'



'''
Transaction Module (Service wise Transaction Model, Global Transaction Model, Wallet Transaction Model)
'''
class PyOtServiceTrn(models.Model):
    service_trn_id = models.AutoField(primary_key=True)
    sp = models.ForeignKey(AdServiceProvider, on_delete=models.PROTECT)
    trn_unique_id = models.CharField(max_length=55)
    trn_amount = models.DecimalField(max_digits=19, decimal_places=2, null=True, blank=True)
    trn_response = models.JSONField(null=True, blank=True)
    customer_name = models.CharField(max_length=50, null=True, blank=True)
    customer_aadhaar_no = models.CharField(max_length=12, null=True, blank=True)
    customer_contact_no = models.CharField(max_length=10, null=True, blank=True)
    trn_status = models.CharField(max_length=15, null=True, blank=True)
    service_trn_dt = models.DateTimeField(auto_now_add=True)
    created_at = models.DateTimeField(auto_now_add=True)


    def __str__(self):
        return f"{self.service_trn_id}"

    class Meta:
        db_table = 'ad_payot_service_transaction'
        app_label = 'admin_hub'


class GlTrn(models.Model):
    gl_trn_id = models.AutoField(primary_key=True)
    service_trn_id = models.IntegerField()
    pu = models.ForeignKey(PortalUser, on_delete=models.PROTECT)
    gl_trn_amt = models.DecimalField(max_digits=19, decimal_places=2, null=True, blank=True)
    gl_tds_rate = models.DecimalField(max_digits=19, decimal_places=2, null=True, blank=True)
    gl_tax_rate = models.DecimalField(max_digits=19, decimal_places=2, null=True, blank=True)
    gl_tds_amt = models.DecimalField(max_digits=19, decimal_places=2, null=True, blank=True)
    gl_tax_amt = models.DecimalField(max_digits=19, decimal_places=2, null=True, blank=True)
    effectvie_wallet = models.CharField(max_length=20, null=True, blank=True)
    effectvie_amt = models.DecimalField(max_digits=19, decimal_places=2, null=True, blank=True)
    effective_type = models.CharField(max_length=10, choices=MrkTyChoice.choices)
    gl_trn_dt = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.gl_trn_id}"

    class Meta:
        db_table = 'ad_global_transaction'
        app_label = 'admin_hub'


class WalletTrn(models.Model):
    wl_trn_id = models.AutoField(primary_key=True)
    action_id = models.IntegerField(null=True, blank=True)
    action_type = models.CharField(max_length=100)
    pu = models.ForeignKey(PortalUser, on_delete=models.PROTECT)
    wl_label = models.CharField(max_length=100)
    effectvie_wallet = models.CharField(max_length=20)
    effectvie_amt = models.DecimalField(max_digits=19, decimal_places=2)
    effective_type = models.CharField(max_length=10, choices=MrkTyChoice.choices)
    wl_trn_dt = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.wl_trn_id}"

    class Meta:
        db_table = 'ad_wallet_transaction'
        app_label = 'admin_hub'


'''
Payout Module Start
'''
class PyOtCustomer(models.Model):
    pyot_customer_id = models.AutoField(primary_key=True)
    customer_first_name = models.CharField(max_length=255)
    customer_last_name = models.CharField(max_length=255, null=True, blank=True)
    customer_contact_no = models.CharField(max_length=10, unique=True)
    customer_address = models.CharField(max_length=1000, null=True, blank=True)
    customer_zip_code = models.IntegerField(null=True, blank=True)
    pyot_unique_id = models.CharField(max_length=13, unique=True, null=True, blank=True)
    verify_code = models.CharField(max_length=128, blank=True, null=True)
    verify_code_expire_at = models.DateTimeField(blank=True, null=True)
    is_verify = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(null=True)

    def __str__(self):
        return f"{self.customer_first_name} {self.customer_last_name}"

    class Meta:
        db_table = 'ad_pyot_customer'
        app_label = 'admin_hub'


class PyOtBankAccount(models.Model):
    pyot_bnk_id = models.AutoField(primary_key=True)
    pyot_beneficiary_id = models.CharField(max_length=12)
    pyot_beneficiary_name = models.CharField(max_length=100)
    pyot_bank_name = models.CharField(max_length=100)
    bnk_acc_no = models.BigIntegerField(null=True, blank=True)
    bnk_ifsc = models.TextField(null=True, blank=True)
    pyot_vpa = models.CharField(max_length=50, null=True, blank=True)
    customer_contact = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        PortalUser, on_delete=models.PROTECT, db_column='created_by', null=True)
    updated_at = models.DateTimeField(null=True)
    updated_by = models.IntegerField(null=True, db_column='updated_by')
    is_verified = models.BooleanField(default=False)
    is_deactive = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    is_added = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.pyot_bnk_id} ({self.pyot_bank_name})"

    class Meta:
        db_table = 'ad_pyot_bank_account'
        app_label = 'admin_hub'


class PayoutTransaction(models.Model):
    py_trn_id = models.AutoField(primary_key=True)
    py_transfer_id = models.CharField(max_length=12, unique=True)
    pyot_bnk = models.ForeignKey(PyOtBankAccount, on_delete=models.PROTECT, null=True, blank=True)
    py_trn_amount = models.DecimalField(max_digits=19, decimal_places=2)
    py_trn_mode = models.CharField(max_length=15)
    py_trn_status = models.CharField(max_length=20, default="PENDING")
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        PortalUser, on_delete=models.PROTECT, db_column='created_by', null=True)
    updated_at = models.DateTimeField(null=True)
    updated_by = models.IntegerField(null=True, db_column='updated_by')

    def __str__(self):
        return f"{self.py_trn_id}"

    class Meta:
        db_table = 'ad_payout_transaction'
        app_label = 'admin_hub'

'''
Payout Module End
'''
