from .views import *


class CfPayOutAPIView(APIView):
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsRetailer] 

    def post(self, request):
        try:
            if 'contact_number' in request.data and 'first_name' in request.data and 'last_name' in request.data and 'address' in request.data and 'zip_code' in request.data:
                return self.get_payout_with_mobile(request)
            elif 'contact_number' in request.data and 'otp' in request.data:
                return self.verify_mobile_otp(request)
            elif 'contact_number' in request.data:
                return self.check_mobile_number(request)
            elif 'account_number' in request.data:
                return self.get_payout_with_account(request)
            elif 'beneficiary_id' in request.data and 'py_trn_amount' in request.data and 'transaction_mode' in request.data:
                return self.create_payout_transaction(request)
            elif 'page_number' in request.data or 'page_size' in request.data:
                return self.fetch_payout_transaction(request)
            else:
                return Response({'status': 'fail', 'message': 'Invalid data.'}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def get_payout_with_mobile(self, request):
        try:
            contact_number = request.data.get('contact_number')
            first_name = request.data.get('first_name')
            last_name = request.data.get('last_name')
            address = request.data.get('address')
            zip_code = request.data.get('zip_code')
            if not contact_number:
                return Response({'status': 'fail', 'message': 'contact number is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
            if not first_name:
                return Response({'status': 'fail', 'message': 'first name is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
            if not last_name:
                return Response({'status': 'fail', 'message': 'last name is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
            if not zip_code:
                return Response({'status': 'fail', 'message': 'zip code is required.'}, status=status.HTTP_400_BAD_REQUEST)

            mobile_number_validation = validate_mobile_number(contact_number)
            if mobile_number_validation == False:
                return Response({'status': 'fail', 'message': 'Invalid contact number format.'}, status=status.HTTP_400_BAD_REQUEST)

            first_name_validation = isstring(first_name)
            if first_name_validation == False:
                return Response({'status': 'fail', 'message': 'First name must be a valid string.'}, status=status.HTTP_400_BAD_REQUEST)

            last_name_validation = isstring(last_name)
            if last_name_validation == False:
                return Response({'status': 'fail', 'message': 'Last name must be a valid string.'}, status=status.HTTP_400_BAD_REQUEST)

            zip_code_validation = isnumber(zip_code)
            if zip_code_validation == False:
                return Response({'status': 'fail', 'message': 'Zip code must be a number.'}, status=status.HTTP_400_BAD_REQUEST)
            if len(zip_code) != 6:
                return Response({'status': 'fail', 'message': 'Zip code must be 6 digits long.'}, status=status.HTTP_400_BAD_REQUEST)

            get_payout_customer = PyOtCustomer.objects.get(customer_contact_no=contact_number)
            
            if get_payout_customer.pyot_unique_id == None:
                try:
                    exists_contact_number = PyOtCustomer.objects.get(customer_contact_no=contact_number)
                except PyOtCustomer.DoesNotExist:
                    return Response({'status': 'fail', 'message': 'This contact number does not exist.'}, status=status.HTTP_400_BAD_REQUEST)
                
                pyot_cs_prefix = "PYOT_CS"

                last_pyot_id = PyOtCustomer.objects.filter(pyot_unique_id__startswith="PYOT_CS").order_by(
                    '-pyot_unique_id').first()
                if last_pyot_id:
                    last_number = int(last_pyot_id.pyot_unique_id[-5:])  
                    new_number = f"{last_number + 1:05d}"  
                else:
                    new_number = "00001"

                exists_contact_number.pyot_unique_id = f'{pyot_cs_prefix}{new_number}'
                exists_contact_number.customer_first_name=first_name
                exists_contact_number.customer_last_name=last_name
                exists_contact_number.customer_address=address
                exists_contact_number.customer_zip_code=zip_code
                exists_contact_number.is_verify = True
                exists_contact_number.save()

                serializer = PyOtCustomerSerializer(exists_contact_number)
                data = {
                    'results': serializer.data
                }

                return Response({'status': 'success', 'message': 'New customer created successfully.', 'data': data}, status=status.HTTP_200_OK)

            else:
                return Response({'status': 'success', 'message': 'Customer with this contact number already exists'}, status=status.HTTP_200_OK)

        except PyOtCustomer.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Payout customer dose not exists.'}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def check_mobile_number(self, request):
        try:
            contact_number = request.data.get('contact_number')

            if not contact_number:
                return Response({'status': 'fail', 'message': 'contact number is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
            mobile_number_validation = validate_mobile_number(contact_number)
            if mobile_number_validation == False:
                return Response({'status': 'fail', 'message': 'Invalid contact number format.'}, status=status.HTTP_400_BAD_REQUEST)
            
            exists_mobile_number = PyOtCustomer.objects.get(customer_contact_no=contact_number)
            if exists_mobile_number.is_verify == True:
                banks_list = []

                payout_banks = PyOtBankAccount.objects.all()

                for bank in payout_banks:
                    for value in bank.customer_contact:
                        if value==contact_number:
                            banks_list.append(bank)

                if len(banks_list) != 0:
                    banks_list = PyOtBankSerializer(banks_list, many=True).data

                data = {
                    'results': banks_list,
                    'customer_contact_no': exists_mobile_number.customer_contact_no,
                    'customer_first_name': exists_mobile_number.customer_first_name,
                    'customer_last_name': exists_mobile_number.customer_last_name,
                    'customer_address': exists_mobile_number.customer_address,
                    'customer_zip_code': exists_mobile_number.customer_zip_code,
                    'pyot_unique_id': exists_mobile_number.pyot_unique_id
                }

                return Response({'status': 'success', 'message': 'Get Banks Account Details.', 'data': data}, status=status.HTTP_200_OK)
            
            else:
                code = get_random_string(length=6, allowed_chars='0123456789')
                exists_mobile_number.verify_code = code
                exists_mobile_number.verify_code_expire_at = timezone.now() + timedelta(minutes=15)
                exists_mobile_number.save()
                
                response = mobicomm_submit_sms(contact_number, code)

                # Check the SMS API response status
                if response.status_code == 200:
                    response_data = {
                        'status': 'success',
                        'message': 'OTP has been sent via SMS.',
                        'data': {'code': code, "is_generated": True, 'is_registered': True}
                    }
                    return Response({'status': 'success', 'message': 'A verification code has been sent to the mobile number.', 'verify_code': code, 'expiry_time': '15 minutes'}, status=status.HTTP_200_OK)
                else:
                    response_data = {
                        'status': 'error',
                        'message': 'Failed to send the OTP via SMS.',
                        'details': response.text  # Include the response for debugging
                    }
                    return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        except PyOtCustomer.DoesNotExist:
            code = get_random_string(length=6, allowed_chars='0123456789')
            PyOtCustomer.objects.create(
                customer_contact_no=contact_number,
                verify_code=code,
                verify_code_expire_at=timezone.now() + timedelta(minutes=15),
            )
            return Response({'status': 'success', 'message': 'A verification code has been sent to the mobile number.', 'verify_code': code, 'expiry_time': '15 minutes'}, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def verify_mobile_otp(self, request):
        try:
            contact_number = request.data.get('contact_number')
            otp = request.data.get('otp')

            if not contact_number:
                return Response({'status': 'fail', 'message': 'contact number is required.'}, status=status.HTTP_400_BAD_REQUEST)

            if not otp:
                return Response({'status': 'fail', 'message': 'otp is required.'}, status=status.HTTP_400_BAD_REQUEST)

            mobile_number_validation = validate_mobile_number(contact_number)
            if mobile_number_validation == False:
                return Response({'status': 'fail', 'message': 'Invalid contact number format.'}, status=status.HTTP_400_BAD_REQUEST)

            code_validation = isnumber(otp)
            if code_validation == False:
                return Response({'status': 'fail', 'message': 'OTP code must be a number.'}, status=status.HTTP_400_BAD_REQUEST)

            if len(otp) != 6:
                return Response({'status': 'fail', 'message': 'OTP code must be 6 digits long.'}, status=status.HTTP_400_BAD_REQUEST)

            get_payout_customer = PyOtCustomer.objects.get(customer_contact_no=contact_number)
            if otp == get_payout_customer.verify_code:

                if timezone.now() < get_payout_customer.verify_code_expire_at:
                    get_payout_customer.verify_code = None
                    get_payout_customer.verify_code_expire_at = None
                    get_payout_customer.save()

                    data = {
                        'status': 'success',
                        'message': 'OTP verified successfully'
                    }
                    return Response(data, status=status.HTTP_200_OK)

                else:
                    return Response({'status': 'fail', 'message': 'OTP has expired.'}, status=status.HTTP_400_BAD_REQUEST)

            else:
                return Response({'status': 'fail', 'message': 'Invalid OTP provided.'}, status=status.HTTP_400_BAD_REQUEST)

        except PyOtCustomer.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Payout customer dose not exists.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def get_payout_with_account(self, request):
        try:
            account_number = request.data.get('account_number')
            if not account_number:
                return Response({'status': 'fail', 'message': 'account number is required.'}, status=status.HTTP_400_BAD_REQUEST)

            account_number_validation = isnumber(account_number)
            if account_number_validation == False:
                return Response({'status': 'fail', 'message': 'account number must be a number.'}, status=status.HTTP_404_NOT_FOUND)

            get_payout_account = PyOtBankAccount.objects.get(bnk_acc_no=account_number)

            customer_data = []

            for contact in get_payout_account.customer_contact:
                get_contact_number = PyOtCustomer.objects.filter(customer_contact_no=contact).first()
                if get_contact_number:
                    customer_data.append(get_contact_number)
            
            if len(customer_data) != 0:
                serializer = PyOtCustomerSerializer(customer_data, many=True).data
            else:
                serializer = []
            bank_serializer = PyOtBankSerializer(get_payout_account)
            data = {
                'status': 'success',    
                'message': 'get all contact number successfully.',
                'results': {
                    'bank_details': bank_serializer.data,
                    'customer_details': serializer
                }
            }
            return Response(data, status=status.HTTP_200_OK)

        except PyOtBankAccount.DoesNotExist:
            return Response({'status': 'fail', 'message': 'account number dose not exists.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def create_payout_transaction(self, request):
        client_id = "CF379597CR4QJ3VPU07S7391HLIG",
        client_secret = "cfsk_ma_test_579d140d50ce6d479c922805f91c1f9a_747f96ec"
        add_beneficiary_url = "https://api.cashfree.com/payout/beneficiary"
        payout_transfer_url = "https://api.cashfree.com/payout/transfers"

        headers = {
            "accept": "application/json",
            "x-api-version": "2024-01-01",
            "content-type": "application/json",
            "x-client-id": "CF449777CRQG8U0O577S73AHL800",
            "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b",
            # "x-client-id": "CF379597CR4QJ3VPU07S7391HLIG",
            # "x-client-secret": "cfsk_ma_test_579d140d50ce6d479c922805f91c1f9a_747f96ec"
        }

        customer_contact_no = request.data.get('customer_contact_no')
        beneficiary_id = request.data.get('beneficiary_id')
        sp_id = request.data.get('sp_id')
        py_trn_amount = request.data.get('py_trn_amount')
        transaction_mode = request.data.get('transaction_mode')

        try:
            with transaction.atomic():
                pyot_bnk_obj = PyOtBankAccount.objects.get(pyot_beneficiary_id=beneficiary_id)
                pyot_cus_obj = PyOtCustomer.objects.get(customer_contact_no=customer_contact_no)
                try:
                    puw_obj = PortalUserWallet.objects.get(pu_id=request.user.id)
                except PortalUserWallet.DoesNotExist:
                    return Response({'status': 'fail', 'message': 'User Wallet Does Not Exist'}, status=status.HTTP_404_NOT_FOUND)

                main_wallet = float(puw_obj.main_wallet)

                if float(py_trn_amount) >= float(main_wallet):
                    return Response({'status': 'fail', 'message': 'User have insufficient balance.'}, status=status.HTTP_404_NOT_FOUND)
                
                if not pyot_bnk_obj.is_added:
                    print('if1', 'if1')
                    add_beneficiary_payload = {
                        "beneficiary_instrument_details": {
                            "bank_account_number": str(pyot_bnk_obj.bnk_acc_no),
                            "bank_ifsc": str(pyot_bnk_obj.bnk_ifsc)
                        },
                        "beneficiary_id": str(beneficiary_id),
                        "beneficiary_name": str(pyot_bnk_obj.pyot_beneficiary_name),
                        "beneficiary_contact_details": {
                            "beneficiary_email": "mr9537858000@gmail.com",
                            "beneficiary_phone": "9537858000"
                        }
                    }

                    beneficiary_response = requests.post(
                        add_beneficiary_url, json=add_beneficiary_payload, headers=headers)
                    
                    bene_response = beneficiary_response.json()
                    print(bene_response, 'bene_response')
                    if beneficiary_response.status_code == 201:
                        print('if2', 'if2')
                        transfer_payload = {
                            "beneficiary_details": {"beneficiary_id": beneficiary_id},
                            "transfer_id": get_random_string(length=12),
                            "transfer_amount": py_trn_amount,
                            "transfer_currency": "INR",
                            "transfer_mode": transaction_mode,
                            # "fundsource_id": "CASHFREE_362089"
                            "fundsource_id": "YES_CONNECTED_55010_091bf6b"
                        }
                        payout_response = requests.post(payout_transfer_url, json=transfer_payload, headers=headers)
                        py_response = payout_response.json()
                        print(py_response, 'py_response')
                        if payout_response.status_code == 200:
                            data = {
                                'order_amount': py_trn_amount,
                                'id': request.user.id,
                                'sp_id': sp_id,
                                'customer_contact_no': customer_contact_no,
                                'customer_name': f"{pyot_cus_obj.customer_first_name} {pyot_cus_obj.customer_last_name}",
                                'trn_response': py_response
                            }
                            after_tx_cal(request, data)

                            return Response({'status': 'success', 'message': "Payout Transfer done successfully"}, status=payout_response.status_code)
                        else:
                            return Response({'status': 'fail', 'message': py_response["message"]}, status=payout_response.status_code)
                    else:
                        print('else2', 'else2')
                        transfer_payload = {
                            "beneficiary_details": {"beneficiary_id": beneficiary_id},
                            "transfer_id": get_random_string(length=12),
                            "transfer_amount": py_trn_amount,
                            "transfer_currency": "INR",
                            "transfer_mode": transaction_mode,
                            # "fundsource_id": "CASHFREE_362089"
                            "fundsource_id": "YES_CONNECTED_55010_091bf6b"
                        }
                        payout_response = requests.post(payout_transfer_url, json=transfer_payload, headers=headers)
                        py_response = payout_response.json()
                        print(py_response, 'py_response else2')
                        if payout_response.status_code == 200:
                            data = {
                                'order_amount': py_trn_amount,
                                'id': request.user.id,
                                'sp_id': sp_id,
                                'customer_contact_no': customer_contact_no,
                                'customer_name': f"{pyot_cus_obj.customer_first_name} {pyot_cus_obj.customer_last_name}",
                                'trn_response': py_response
                            }
                            after_tx_cal(request, data)
    
                            return Response({'status': "success", 'message': "Payout Transfer done successfully"}, status=payout_response.status_code)
                        else:
                            return Response({'status': 'fail', 'message': py_response["message"]}, status=payout_response.status_code)
                else:
                    print('else1', 'else1')
                    transfer_payload = {
                        "beneficiary_details": {"beneficiary_id": beneficiary_id},
                        "transfer_id": get_random_string(length=12),
                        "transfer_amount": py_trn_amount,
                        "transfer_currency": "INR",
                        "transfer_mode": transaction_mode,
                        # "fundsource_id": "CASHFREE_362089"
                        "fundsource_id": "YES_CONNECTED_55010_091bf6b"
                    }
                    payout_response = requests.post(payout_transfer_url, json=transfer_payload, headers=headers)
                    py_response = payout_response.json()
                    print(py_response, 'py_response else1')
                    if payout_response.status_code == 200:
                        data = {
                                'order_amount': py_trn_amount,
                                'id': request.user.id,
                                'sp_id': sp_id,
                                'customer_contact_no': customer_contact_no,
                                'customer_name': f"{pyot_cus_obj.customer_first_name} {pyot_cus_obj.customer_last_name}",
                                'trn_response': py_response
                            }
                        after_tx_cal(request, data)
                        
                        return Response({'status': 'success', 'message': "Payout Transfer done successfully"}, status=status.HTTP_200_OK)
                    else:
                        return Response({'status': 'fail', 'message': py_response["message"]}, status=payout_response.status_code)
        except PyOtCustomer.DoesNotExist:
            response_data = {
                'status': 'error',
                'message': 'Customer with this contact number does not exist.'
            }
            return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def fetch_payout_transaction(self, request):
        page_number = request.data.get('page_number', 1)
        page_size = request.data.get('page_size')

        try:
            if not page_size: return Response({'status': 'fail','message': 'page_size is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if isnumber(page_size) == False: return Response({'status': 'fail','message': 'page_size must contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)

            if page_number:
                if isnumber(page_number) == False: return Response({'status': 'fail','message': 'page_number must contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)

            queryset = PyOtServiceTrn.objects.all()

            paginator = Paginator(queryset, page_size)
            try:
                page_obj = paginator.page(page_number)
            except EmptyPage:
                return Response({
                    'status': 'fail',
                    'message': 'Page not found.',
                    'data': {}
                }, status=status.HTTP_404_NOT_FOUND)

            if page_obj is not None:
                if not queryset.exists():
                    paginated_response_data = {
                        'total_pages': 0,
                        'current_page': 0,
                        'total_items': 0,
                        'results': []
                    }
                    response_data = {
                        'status': 'fail',
                        'message': 'Payout Transaction Data not found.',
                        'data': paginated_response_data
                    }
                    return Response(response_data, status=status.HTTP_200_OK)

                serializer = PyOtServiceTrnSerializer(page_obj.object_list, many=True).data
                for trn in serializer:
                    print(trn['sp'], type(trn['sp']))
                    sp_obj = AdServiceProvider.objects.get(sp_id=trn['sp'])
                    trn['label'] = sp_obj.label
                paginated_response_data = {
                    'total_pages': paginator.num_pages,
                    'current_page': page_obj.number,
                    'total_items': paginator.count,
                    'results': serializer
                }
                return Response({
                    'status': 'success',
                    'message': 'Payout Transaction data',
                    'data': paginated_response_data
                }, status=status.HTTP_200_OK)

            serializer = PyOtServiceTrnSerializer(queryset, many=True, context={'request': request}).data

            for trn in serializer:
                print(trn['sp'], type(trn['sp']))
                sp_obj = AdServiceProvider.objects.get(sp_id=trn['sp'])
                trn['label'] = sp_obj.label

            response_data = {
                'status': 'success',
                'message': 'Payout Transaction data',
                'data': serializer
            }
            return Response(response_data, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'status': 'fail',
                'message': str(e),
                'data': {}
            }, status=status.HTTP_400_BAD_REQUEST)


class CfPayoutBeneficiaryAPIView(APIView):
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsRetailer]

    def post(self, request):
        try:
            if 'bank_name' in request.data and 'beneficiary_name' in request.data and 'account_number' in request.data and 'ifsc_code' in request.data and 'contact_number' in request.data:
                return self.add_customer_payout_bank_account(request)
            elif 'page_size' in request.data or 'page_number' in request.data:
                return self.fatch_customer_payout_bank_account(request)
            else:
                return Response({'status': 'fail', 'message': 'Invalid data.'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def add_customer_payout_bank_account(self, request):
        try:
            bank_name = request.data.get('bank_name')
            beneficiary_name = request.data.get('beneficiary_name')
            account_number = request.data.get('account_number')
            ifsc_code = request.data.get('ifsc_code')
            contact_number = request.data.get('contact_number')

            if not bank_name: return Response({'status': 'fail', 'message': 'bank name is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not beneficiary_name: return Response({'status': 'fail', 'message': 'beneficiary name is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not account_number: return Response({'status': 'fail', 'message': 'account number is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not ifsc_code: return Response({'status': 'fail', 'message': 'IFSC code is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not contact_number: return Response({'status': 'fail', 'message': 'contact number is required.'}, status=status.HTTP_400_BAD_REQUEST)

            existing_account = PyOtBankAccount.objects.filter(pyot_bank_name=bank_name, pyot_beneficiary_name=beneficiary_name, bnk_acc_no=account_number, bnk_ifsc=ifsc_code).first()
            if existing_account:
                if contact_number in existing_account.customer_contact:
                    return Response({'status': 'success', 'message': 'This bank account with the provided contact number already exists.'}, status=status.HTTP_200_OK)
                else:
                    existing_account.customer_contact.append(contact_number)
                    existing_account.save()
                    return Response({'status': 'success', 'message': 'Contact number added to existing payout bank account.'}, status=status.HTTP_200_OK)

            else:
                existing_account_number = PyOtBankAccount.objects.filter(bnk_acc_no=account_number).first()
                print('==>', existing_account_number)
                if existing_account_number and int(account_number) == existing_account_number.bnk_acc_no:
                    return Response({'status': 'fail', 'message': 'Account number already existing payout bank account.'}, status=status.HTTP_400_BAD_REQUEST)

                beneficiary_id = get_random_string(length=12, allowed_chars='qwertyuiopasdfghjklzxcvbnm')

                PyOtBankAccount.objects.create(
                    pyot_beneficiary_id=beneficiary_id,
                    pyot_beneficiary_name=beneficiary_name,
                    pyot_bank_name=bank_name,
                    bnk_acc_no=account_number,
                    bnk_ifsc=ifsc_code,
                    customer_contact=[contact_number]
                )

                return Response({'status': 'success', 'message': 'Payout bank account added successfully.'}, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


    def fatch_customer_payout_bank_account(self, request):
        try:
            page_number = int(request.data.get('page_number', 1))
            page_size = int(request.data.get('page_size', 10))
            mobile_number = request.data.get('mobile_number', None)
            account_number = request.data.get('account_number', None)

            # Validate page size
            if page_size <= 0:
                return Response({'status': 'fail', 'message': 'Page size must be a positive integer.'}, status=status.HTTP_400_BAD_REQUEST)

            # Filter queryset
            queryset = PyOtBankAccount.objects.filter(is_deleted=False)
            if mobile_number:
                queryset = queryset.filter(customer_contact__contains=[mobile_number])
            if account_number:
                queryset = queryset.filter(bnk_acc_no=account_number)

            # Pagination
            paginator = Paginator(queryset, page_size)

            # Check for requested page validity
            if page_number > paginator.num_pages:
                return Response({'status': 'fail', 'message': 'Invalid page number.'}, status=status.HTTP_400_BAD_REQUEST)

            # Get the requested page  
            page_obj = paginator.page(page_number)

            bank_account_serializer = PyOtBankSerializer(page_obj, many=True)
            data = {
                "results": bank_account_serializer.data
            }

            return Response({
                'status': 'success',
                'data': data,
                'total_pages': paginator.num_pages,
                'current_page': page_number,
            })

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
