from django.db import transaction
from rest_framework.response import Response
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework import status
import requests
import json
import hashlib
import hmac

def create_razorpay_pg_order(request, data):
    name = data.get('name')
    email = data.get('email')
    contact_no = data.get('contact_no')
    amount = data.get('amount')
    currency = "INR"

    api_key = "rzp_test_rEAW6ojdmqFEbn"
    secret_key = "mPPJMnQtFd0o5Q1hKTXTgZSe"

    try:
        order_payload = {
            "amount": float(amount)*100,
            "currency": currency
        }

        # scheme = "https" if request.is_secure() else "http"
        callback_url = "admin_hub/payment-gateway/razorpay/"

        details = {
            "api_key": api_key,
            "name": name,
            "email": email,
            "contact_no": contact_no,
            "callback_url": callback_url
        }

        url = "https://api.razorpay.com/v1/orders"

        new_order_response = requests.post(url, auth=(api_key, secret_key), json=order_payload)

        if new_order_response.status_code == 200:
            details['order'] = json.loads(new_order_response.text)
            response = {'status': 'success', 'data': details}

        else:
            details['order'] = json.loads(new_order_response.text)
            response = {'status': 'fail', 'data': details}

        return response
    except Exception as e:
        response = {'status': 'error', 'message': str(e)}

        return response


def verify_razorpay_payment_gateway(request, data):
    razorpay_order_id = data.get('razorpay_order_id')
    razorpay_payment_id = data.get('razorpay_payment_id')
    razorpay_signature = data.get('razorpay_signature')
    method = request.method

    api_key = "rzp_test_rEAW6ojdmqFEbn"
    secret_key = "mPPJMnQtFd0o5Q1hKTXTgZSe"

    try:
        with transaction.atomic():
            if method == "POST":

                if 'razorpay_order_id' not in request.data or 'razorpay_payment_id' not in request.data or 'razorpay_signature' not in request.data or 'method' not in request.data:
                    return Response(
                            {'status': 'fail', 'message': 'razorpay_order_id, razorpay_payment_id and razorpay_signature are required'},
                            status=status.HTTP_400_BAD_REQUEST
                        )

                params_dict={
                    'razorpay_order_id': razorpay_order_id,
                    'razorpay_payment_id' : razorpay_payment_id,
                    'razorpay_signature': razorpay_signature
                }

                message = f"{razorpay_order_id}|{razorpay_payment_id}"
                generated_signature = hmac.new(secret_key.encode("utf-8"), message.encode("utf-8"), hashlib.sha256).hexdigest()
                
                print(generated_signature, 'generated_signature')
                print(razorpay_signature, 'razorpay_signature')

                if generated_signature == razorpay_signature:

                    url = f"https://api.razorpay.com/v1/payments/{razorpay_payment_id}"

                    payment_response = requests.get(url, auth=(api_key, secret_key))

                    if payment_response.status_code == 200:
                        return Response({'status': 'success', 'message': 'Payment is successful', 'response': payment_response.json()}, status=status.HTTP_200_OK)

                    else:
                        return Response({'status': 'fail', 'data': payment_response.json()}, status=payment_response.status_code)

                else:
                    return Response({'status': 'fail', 'message': 'Signature verification failed'}, status=status.HTTP_404_NOT_FOUND)
            else:
                return Response({'status': 'fail', 'message': 'Payment is failed'}, status=status.HTTP_404_NOT_FOUND)

    except Exception as e:
        return Response(
                {'status': 'error', 'message': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )