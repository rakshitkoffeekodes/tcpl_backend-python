import json
from django.db import connections, transaction
from django.utils.timezone import now
from .models import (
    PortalUserCharges, AdHSNSAC, AdServiceProvider, 
    WalletTrn, PortalUserWallet, PyOtServiceTrn, GlTrn, PortalUser
)


def calculate_tds(amount, tds_rate):
    """Calculate TDS based on the rate."""
    tds_amount = (float(amount) * float(tds_rate)) / 100
    amount_after_tds = float(amount) - float(tds_amount)
    return float(amount_after_tds), None, float(tds_amount)


def calculate_gst(amount, gst_rate):
    """Calculate GST based on the rate."""
    tax_amount = (float(amount) * float(gst_rate)) / 100
    amount_after_tax = float(amount) - float(tax_amount)
    return float(amount_after_tax), float(tax_amount), None


def charge_with_gst(amount, gst_rate, tds_rate):
    """Calculate amount for 'CHARGE WITH GST'."""
    tax_amount = (float(amount) * float(gst_rate)) / 100
    amount_after_tax = float(amount) - float(tax_amount)

    tds_amount = (float(amount_after_tax) * float(tds_rate)) / 100
    amount_after_tds = float(amount_after_tax) - float(tds_amount)

    return float(amount_after_tds), float(tax_amount), float(tds_amount)


def log_wallet_transaction(user, action_type, label, amount, effective_wallet, effective_type):
    """Create a wallet transaction entry."""
    WalletTrn.objects.create(
        action_id=user.id,
        action_type=action_type,
        pu=user,
        wl_label=label,
        effectvie_wallet=effective_wallet,
        effectvie_amt=amount,
        effective_type=effective_type,
        wl_trn_dt=now()
    )


def update_user_wallet(user, amount, charge_type, wallet_type):
    """Update the user wallet dynamically based on the effective wallet type."""
    wallet = PortalUserWallet.objects.get(pu=user)
    if charge_type == 'CR':  # Credit
        setattr(wallet, wallet_type, float(getattr(wallet, wallet_type)) + amount)
    elif charge_type == 'DR':  # Debit
        setattr(wallet, wallet_type, float(getattr(wallet, wallet_type)) - amount)
    wallet.updated_at = now()
    wallet.save()


def get_matching_charge(order_amount, charges_data):
    """
    Select the appropriate charge dictionary from the list based on order amount.
    If min and max are 0, return the first dictionary.
    If not, find the one where the order amount fits in the range.
    """
    for charge in charges_data:
        min_value = float(charge.get('minimum', 0))
        max_value = float(charge.get('maximum', 0))

        # If both min and max are 0, return the first dictionary
        if min_value == 0 and max_value == 0:
            return charge

        # Check if the order_amount fits within the min-max range
        if min_value <= float(order_amount) <= max_value:
            return charge

    # If no match found, raise an error (optional)
    raise ValueError("No valid charge entry found for the given order amount.")


@transaction.atomic
def after_tx_cal(request, data):
    try:
        # Extract data from request
        order_amount = data.get('order_amount')
        user = PortalUser.objects.get(id=data.get('id'))
        sp_id = data.get('sp_id')

        # Create PyOtServiceTrn entry
        service_trn = PyOtServiceTrn.objects.create(
            sp_id=sp_id,
            trn_unique_id=f"TRN-{now().strftime('%Y%m%d%H%M%S')}",
            trn_amount=order_amount,
            trn_response=data.get('trn_response'),  
            customer_name=data.get('customer_name'),
            customer_contact_no=data.get('customer_contact_no'),
            trn_status='COMPLETED',  
        )

        # Fetch user's charges and parent data
        user_charges = PortalUserCharges.objects.get(pu_id=user.id, sp_id=sp_id)
        tax_rate = AdHSNSAC.objects.get(hsnsac_id=user_charges.sp.hsn_sac_id).tax_rate
        tds_rate = AdServiceProvider.objects.get(sp_id=sp_id).tds_rate

        # Recursive Query to fetch all users in the hierarchy
        cursor = connections['tcpl_admin_db'].cursor()
        query = f'''WITH RECURSIVE "Descendants" AS (
        SELECT "pu_id", "parent_id", "puc_charges", "mark_type", "sp_id", "dh_id"
        FROM "ad_portal_user_charges"
        WHERE "pu_id" = {user.id} AND "sp_id" = {sp_id}
        UNION ALL
        SELECT n."pu_id", n."parent_id", n."puc_charges", n."mark_type", n."sp_id", n."dh_id"
        FROM "ad_portal_user_charges" n
        JOIN "Descendants" d ON n."pu_id" = d."parent_id" AND n."sp_id" = d."sp_id"
        )
        SELECT * FROM "Descendants";'''
        cursor.execute(query)
        result = cursor.fetchall()
        cursor.close()

        for res in result:
            pu_id, parent_id, puc_charges, charge_type, sp_id, dh_id = res
            charges_data = json.loads(puc_charges)

            # Get the relevant charge dictionary based on order amount
            selected_charge = get_matching_charge(order_amount, charges_data)

            # Extract relevant data from the selected charge
            charge_type = selected_charge["charge_type"]
            commission_type = selected_charge["commission_type"]
            effective_wallet = selected_charge["effective_wallet"]

            # Determine remaining amount based on commission type
            if commission_type == "COMMISSION WITH GST":
                remaining_amount, tax_amount, tds_amount = charge_with_gst(order_amount, tax_rate, tds_rate)
            elif commission_type == "COMMISSION WITHOUT GST":
                remaining_amount, tax_amount, tds_amount = calculate_tds(order_amount, tds_rate)
            elif commission_type == "CHARGE WITH GST":
                remaining_amount, tax_amount, tds_amount = calculate_gst(order_amount, tax_rate)
            else:
                raise Exception(f"Invalid commission type: {commission_type}")

            # Log GL transaction for each user
            GlTrn.objects.create(
                service_trn_id=service_trn.service_trn_id,
                pu_id=pu_id,
                gl_trn_amt=order_amount,
                gl_tds_rate=tds_rate,
                gl_tax_rate=tax_rate,
                gl_tds_amt=tds_amount,
                gl_tax_amt=tax_amount,
                effectvie_wallet=effective_wallet,
                effectvie_amt=remaining_amount,
                effective_type=charge_type,
                gl_trn_dt=now(),
            )

            # Update the user's wallet based on the effective wallet
            commission_user = PortalUser.objects.get(id=pu_id)
            update_user_wallet(commission_user, remaining_amount, charge_type, effective_wallet)

            # Log the wallet transaction
            log_wallet_transaction(
                user=commission_user,
                action_type='CR',
                label=f"{commission_type} Transaction",
                amount=remaining_amount,
                effective_wallet=effective_wallet,
                effective_type=charge_type
            )

    except Exception as e:
        raise Exception(f"Error distributing commissions: {str(e)}")
