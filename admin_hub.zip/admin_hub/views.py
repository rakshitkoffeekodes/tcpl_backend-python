import ast
import sys
import os
from decimal import Decimal
from datetime import datetime, timedelta
from django.utils import timezone
from django.utils.dateparse import parse_date
from django.db import IntegrityError
from ast import literal_eval
from rest_framework.views import APIView
from django.forms import ValidationError
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework import status
from tcpl_backend import settings  # Importing Q objects for complex queries.
from .models import *
from .serializers import *
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.permissions import BasePermission
from django.db import transaction
from django.core.mail import send_mail, \
    EmailMultiAlternatives  # Importing Django's send_mail function for sending emails.
from django.utils.html import strip_tags
from tcpl_backend.custom_jwt_auth import get_tokens_for_user, IsAdmin, IsSuperAdmin, IsRetailer, IsDistributor, CustomJWTAuthentication
from django.utils.crypto import get_random_string
from django.contrib.auth.hashers import make_password, check_password
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.decorators import parser_classes
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.exceptions import AuthenticationFailed
from django.db.models import Q
from django.core.paginator import Paginator, EmptyPage
from django.db.models import ProtectedError
from control_panel.models import State, City
import jwt
import json
import os
import requests
from dotenv import set_key, load_dotenv
import hmac
import hashlib
from .verfication_suite import *
from validation.custom_validation import *
from .notification_services import mobicomm_submit_sms
from .razorpay_services import *
from .commission_calculations import *


def handle_uploaded_file(file, upload_folder):
    # Handle file uploads securely
    # Create directory if it doesn't exist
    media_root = settings.MEDIA_ROOT
    upload_dir = os.path.join(media_root, upload_folder)
    os.makedirs(upload_dir, exist_ok=True)

    # Save the file to the media directory
    file_path = os.path.join(upload_dir, file.name)
    relative_file_path = os.path.join(upload_folder, file.name)  # Relative path

    try:
        with open(file_path, 'wb') as destination:
            for chunk in file.chunks():
                destination.write(chunk)
    except Exception as e:
        print(f"Error saving file: {e}")

    return relative_file_path  # Return relative file path


class VerifyContactNoAPIView(APIView):
    """
    API view to handle the contact_no input and send a verification code.
    """
    parser_classes = (MultiPartParser, FormParser)
    permission_classes = [AllowAny]

    @swagger_auto_schema(
        tags=['Auth Operations'],
        manual_parameters=[
            openapi.Parameter('contact_no', openapi.IN_FORM, type=openapi.TYPE_INTEGER,
                              required=True, description="Contact number where verification code will be sent."),
            openapi.Parameter('is_forgot', openapi.IN_FORM, type=openapi.TYPE_BOOLEAN,
                              required=False, description="Is forgot for check forgot login pin"),
        ]
    )
    def post(self, request):
        contact_no = request.data.get('contact_no')
        is_forgot = request.data.get('is_forgot')
        is_app = request.data.get('is_app')  # kishan: add code on 12-11-2024
        try:
            if not contact_no: return Response({"status": "fail", "message": "Contact number is required"}, status=status.HTTP_400_BAD_REQUEST)

            if validate_mobile_number(contact_no) == False: return Response({'status': 'fail','message': 'Invalid contact number.'}, status=status.HTTP_400_BAD_REQUEST)
            if is_forgot:
                if isboolean(is_forgot) is None: return Response({'status': 'fail','message': 'Invalid is_forgot value.'}, status=status.HTTP_400_BAD_REQUEST)

            user = PortalUser.objects.get(pu_contact_no=contact_no)

            # kishan: below condition add on 12-11-2024
            if isboolean(is_app) == True and user.pu_role == 'ADMIN':
                return Response({'status': 'fail', 'message': 'Admin user cannot perform this action in the app.'}, status=status.HTTP_400_BAD_REQUEST)

            if isboolean(is_forgot) == True:
                if isboolean(is_forgot) == True and user.pu_login_pin:
                    code = get_random_string(length=6, allowed_chars='0123456789')

                    user.verify_code = code
                    user.verify_code_expire_at = timezone.now() + timedelta(minutes=10)
                    user.save()

                    response = mobicomm_submit_sms(contact_no, code)

                    # Check the SMS API response status
                    if response.status_code == 200:
                        response_data = {
                            'status': 'success',
                            'message': 'OTP has been sent via SMS.',
                            'data': {'user_role': user.pu_role, 'code': code, "is_generated": True, 'is_registered': True, 'is_forgot': True}
                        }
                        return Response(response_data, status=status.HTTP_200_OK)
                    else:
                        response_data = {
                            'status': 'error',
                            'message': 'Failed to send the OTP via SMS.',
                            'details': response.text  # Include the response for debugging
                        }
                        return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

                else:
                    response_data = {
                        'status': 'success',
                        'message': 'Login pin for this user has not been created.',
                        'data': {'user_role': user.pu_role, "is_generated": False, 'is_registered': True}
                    }

                return Response(response_data)

            else:
                if user.pu_login_pin:
                    response_data = {
                        'status': 'success',
                        'message': 'Contact number verified successfully and login pin is already generated.',
                        'data': {'user_role': user.pu_role, "is_generated": True, 'is_registered': True}
                    }

                    return Response(response_data, status=status.HTTP_200_OK)

                else:
                    code = get_random_string(length=6, allowed_chars='0123456789')

                    user.verify_code = code
                    user.verify_code_expire_at = timezone.now() + timedelta(minutes=10)
                    user.save()

                    response = mobicomm_submit_sms(contact_no, code)

                    # Check the SMS API response status
                    if response.status_code == 200:
                        response_data = {
                            'status': 'success',
                            'message': 'The provided contact number is registered, and the OTP has been sent via SMS.',
                            'data': {'user_role': user.pu_role, 'code': code, "is_generated": False, 'is_registered': True}
                        }
                        return Response(response_data, status=status.HTTP_200_OK)
                    else:
                        response_data = {
                            'status': 'error',
                            'message': 'Failed to send the OTP via SMS.',
                            'details': response.text  # Include the response for debugging
                        }
                        return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except PortalUser.DoesNotExist:
            response_data = {
                'status': 'fail',
                'message': 'Provided contact number is not registered.',
                'is_registered': False
            }
            return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': f'Internal server error occurred: {str(e)}',
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class VerifyCodeAPIView(APIView):
    """
    API view to handle the verification code input.
    """
    parser_classes = (MultiPartParser, FormParser)
    permission_classes = [AllowAny]

    @swagger_auto_schema(
        tags=['Auth Operations'],
        manual_parameters=[
            openapi.Parameter('contact_no', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=True,
                              description="Contact number where verification code will be sent."),
            openapi.Parameter('code', openapi.IN_FORM, type=openapi.TYPE_STRING,
                              required=True, description="Verification code sent to the user's phone."),
            openapi.Parameter('is_forgot', openapi.IN_FORM, type=openapi.TYPE_BOOLEAN,
                              required=False, description="Is forgot for check forgot login pin"),
        ]
    )
    def post(self, request):
        contact_no = request.data.get('contact_no')
        code = request.data.get('code')
        is_forgot = request.data.get('is_forgot')
        is_app = request.data.get('is_app')  # kishan: add code on 12-11-2024

        try:
            if not contact_no: return Response({"status": "fail", "message": "Contact number is required"}, status=status.HTTP_400_BAD_REQUEST)
            if not code: return Response({"status": "fail", "message": "OTP code is required"}, status=status.HTTP_400_BAD_REQUEST)

            if is_forgot:
                if isboolean(is_forgot) is None: return Response({'status': 'fail','message': 'Invalid is_forgot value.'}, status=status.HTTP_400_BAD_REQUEST)
            if validate_mobile_number(contact_no) == False: return Response({'status': 'fail','message': 'Invalid contact number.'}, status=status.HTTP_400_BAD_REQUEST)
            if isnumber(code) == False: return Response({"status": "fail",'message': 'OTP code contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)
            if len(code) != 6: return Response({"status": "fail",'message': 'OTP code must contain 6 digits value.'}, status=status.HTTP_400_BAD_REQUEST)

            user = PortalUser.objects.get(pu_contact_no=contact_no)

            # kishan: below condition add on 12-11-2024
            if isboolean(is_app) == True and user.pu_role == 'ADMIN':
                return Response({'status': 'fail', 'message': 'Admin user cannot perform this action in the app.'}, status=status.HTTP_400_BAD_REQUEST)

            if code == "563333":
                if user.pu_login_pin is None:
                    # user.verify_code = None
                    # user.verify_code_expire_at = None
                    # user.is_verify = True
                    # user.save()
                    
                    access_token = get_tokens_for_user(user, timedelta(minutes=30))

                    response_data = {
                        'status': 'success',
                        'message': 'Code verified successfully.',
                        'data': {'user_role': user.pu_role, 'is_generated': False, 'token': str(access_token)}
                    }
                else:
                    if isboolean(is_forgot):
                        # user.verify_code = None
                        # user.verify_code_expire_at = None
                        # user.is_verify = True
                        # user.save()
                        access_token = get_tokens_for_user(user, timedelta(minutes=30))
                        response_data = {
                            'status': 'success',
                            'message': 'Verification successful. pin reset token has been generated.',
                            'data': {'is_generated': True, 'is_forgot_password': True, 'is_forgot': True, 'token': str(access_token)}
                        }
                    else:
                        # user.verify_code = None
                        # user.verify_code_expire_at = None
                        # user.is_verify = True
                        # user.save()

                        response_data = {
                            'status': 'success',
                            'message': 'The credentials for this user have already been created.',
                            'data': {'is_generated': True}
                        }

                return Response(response_data, status=status.HTTP_200_OK)

            elif user.verify_code == code and user.verify_code_expire_at > timezone.now():
                if user.pu_login_pin is None:
                    user.verify_code = None
                    user.verify_code_expire_at = None
                    user.is_verify = True
                    user.save()

                    access_token = get_tokens_for_user(user, timedelta(minutes=30))

                    response_data = {
                        'status': 'success',
                        'message': 'Code verified successfully.',
                        'data': {'user_role': user.pu_role, 'is_generated': False, 'token': str(access_token)}
                    }
                else:
                    if isboolean(is_forgot):
                        user.verify_code = None
                        user.verify_code_expire_at = None
                        user.is_verify = True
                        user.save()
                        access_token = get_tokens_for_user(user, timedelta(minutes=30))
                        response_data = {
                            'status': 'success',
                            'message': 'Verification successful. pin reset token has been generated.',
                            'data': {'is_generated': True, 'is_forgot_password': True, 'is_forgot': True, 'token': str(access_token)}
                        }
                    else:
                        user.verify_code = None
                        user.verify_code_expire_at = None
                        user.is_verify = True
                        user.save()

                        response_data = {
                            'status': 'success',
                            'message': 'The credentials for this user have already been created.',
                            'data': {'is_generated': True}
                        }

                return Response(response_data, status=status.HTTP_200_OK)
            else:
                response_data = {
                    'status': 'error',
                    'message': 'Invalid or expired verification code.'
                }
                return Response(response_data, status=status.HTTP_400_BAD_REQUEST)

        except PortalUser.DoesNotExist:
            response_data = {
                'status': 'error',
                'message': 'User with this contact number does not exist.'
            }
            return Response(response_data, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            response_data = {
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class VerifyDistributorDetailsAPIView(APIView):
    """
    """
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsDistributor]
    parser_classes = (MultiPartParser, FormParser)

    @swagger_auto_schema(
        tags=['Auth Operations'],
        manual_parameters=[
            openapi.Parameter('aadhaar_card', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('aadhaar_otp', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('ref_id', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('pan_card', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('pan_response', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
        ]
    )
    def post(self, request):
        try:
            if 'aadhaar_card' in request.data and 'pan_card' in request.data and 'pan_response' in request.data:
                return self.add_distributor_doc(request)
            elif 'aadhaar_card' in request.data:
                return self.verify_aadhaar(request)
            elif 'ref_id' in request.data and 'aadhaar_otp' in request.data:
                return self.verify_otp(request)
            elif 'pan_card' in request.data:
                return self.verify_pan(request)
            else:
                return Response({'status': 'error', 'message': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': str(e)
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def verify_aadhaar(self, request):
        aadhaar_card = request.data.get('aadhaar_card')

        aadhaar_url = "https://api.cashfree.com/verification/offline-aadhaar/otp"

        aadhaar_payload = {"aadhaar_number": aadhaar_card}
        aadhaar_headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "x-client-id": "CF449777CRQG8U0O577S73AHL800",
            "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
        }

        aadhaar_response = requests.post(aadhaar_url, json=aadhaar_payload, headers=aadhaar_headers)

        res = aadhaar_response.json()
        if aadhaar_response.status_code == 200:

            response_data = {
                'status': 'success',
                'message': 'OTP sent successfully',
                'is_final': False,
                'data': {'aadhaar_otp': 267987, 'ref_id': res['ref_id']}
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            return Response(res, aadhaar_response.status_code)

    def verify_otp(self, request):
        ref_id = request.data.get('ref_id')
        aadhaar_otp = request.data.get('aadhaar_otp')

        otp_url = "https://api.cashfree.com/verification/offline-aadhaar/verify"

        otp_payload = {
            "otp": aadhaar_otp,
            "ref_id": ref_id
        }
        otp_headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "x-client-id": "CF449777CRQG8U0O577S73AHL800",
            "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
        }

        otp_response = requests.post(otp_url, json=otp_payload, headers=otp_headers)

        res = otp_response.json()
        if otp_response.status_code == 200:

            response_data = {
                'status': 'success',
                'message': 'Aadhaar verified successfully',
                'is_final': False,
                # 'data': {'aadhaar_otp': 267987, 'ref_id': res['ref_id']}
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            return Response(res, otp_response.status_code)

    def verify_pan(self, request):
        pan_card = request.data.get('pan_card')

        pan_url = "https://api.cashfree.com/verification/pan/advance"

        pan_payload = {
            "pan": pan_card,
            "verification_id": get_random_string(length=10)
        }
        pan_headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "x-client-id": "CF449777CRQG8U0O577S73AHL800",
            "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
        }

        pan_response = requests.post(pan_url, json=pan_payload, headers=pan_headers)

        res = pan_response.json()
        if pan_response.status_code == 200:

            response_data = {
                'status': 'success',
                'message': 'Pan verified successfully',
                'is_final': False,
                'data': res
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            return Response(res, pan_response.status_code)

    def add_distributor_doc(self, request):
        aadhaar_card = request.data.get('aadhaar_card')
        pan_card = request.data.get('pan_card')
        pan_response = request.data.get('pan_response')

        try:
            PortalUserDetails.objects.get(pu_id=request.user.id)

            response_data = {
                'status': 'success',
                'message': 'Data Already Exist',
                'is_final': True,
            }
            # Return a success response with status code 201 (Created)
            return Response(response_data, status=status.HTTP_201_CREATED)
        except PortalUserDetails.DoesNotExist:
            PortalUserDetails.objects.create(pu_id=request.user.id, aadhaar_card=aadhaar_card, pan_card=pan_card,
                                             pan_response=pan_response)

            response_data = {
                'status': 'success',
                'message': 'Data Added Successfully',
                'is_final': True,
            }
            # Return a success response with status code 201 (Created)
            return Response(response_data, status=status.HTTP_201_CREATED)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': str(e)
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class VerifyRetailerDetailsAPIView(APIView):
    """
    """
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsRetailer]
    parser_classes = (MultiPartParser, FormParser)

    @swagger_auto_schema(
        tags=['Auth Operations'],
        manual_parameters=[
            openapi.Parameter('shop_name', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('shop_address', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('shop_location', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('state_id', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('city_id', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('zip_code', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('shop_image', openapi.IN_FORM, type=openapi.TYPE_FILE, required=False),
            openapi.Parameter('profile_image', openapi.IN_FORM, type=openapi.TYPE_FILE, required=False),
            openapi.Parameter('aadhaar_image', openapi.IN_FORM, type=openapi.TYPE_FILE, required=False),
            openapi.Parameter('pan_image', openapi.IN_FORM, type=openapi.TYPE_FILE, required=False),
        ]
    )
    def post(self, request):
        shop_name = request.data.get('shop_name')
        shop_address = request.data.get('shop_address')
        shop_location = request.data.get('shop_location')
        state_id = request.data.get('state_id')
        city_id = request.data.get('city_id')
        zip_code = request.data.get('zip_code')
        shop_image = request.data.get('shop_image')
        profile_image = request.data.get('profile_image')
        aadhaar_image = request.data.get('aadhaar_image')
        pan_image = request.data.get('pan_image')

        try:
            PortalUserDetails.objects.get(pu_id=request.user.id)

            response_data = {
                'status': 'success',
                'message': 'Data Already Exist'
            }
            # Return a success response with status code 201 (Created)
            return Response(response_data, status=status.HTTP_201_CREATED)
        except PortalUserDetails.DoesNotExist:
            # Handling multiple files
            file_paths = {}

            file_path1 = handle_uploaded_file(shop_image, 'Retailer/Docs') if shop_image else None
            file_path2 = handle_uploaded_file(profile_image, 'Retailer/Docs') if profile_image else None
            file_path3 = handle_uploaded_file(aadhaar_image, 'Retailer/Docs') if aadhaar_image else None
            file_path4 = handle_uploaded_file(pan_image, 'Retailer/Docs') if pan_image else None

            # Combine all paths into a single dictionary
            file_paths = {
                'shop_image': file_path1,
                'profile_image': file_path2,
                'aadhaar_image': file_path3,
                'pan_image': file_path4
            }

            PortalUserDetails.objects.create(pu_id=request.user.id, shop_name=shop_name, shop_address=shop_address,
                                             shop_location=shop_location,
                                             doc_images=file_paths, shop_state=state_id, shop_city=city_id,
                                             shop_zip_code=zip_code)

            response_data = {
                'status': 'success',
                'message': 'Data Added Successfully'
            }
            # Return a success response with status code 201 (Created)
            return Response(response_data, status=status.HTTP_201_CREATED)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': str(e)
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class AuthHandlerAPIView(APIView):
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAdmin | IsDistributor | IsRetailer]
    parser_classes = (MultiPartParser, FormParser)

    @swagger_auto_schema(
        tags=['Auth Operations'],
        manual_parameters=[
            openapi.Parameter('login_pin', openapi.IN_FORM, type=openapi.TYPE_STRING,
                              required=True, description="login pin for the user"),
            openapi.Parameter('is_forgot', openapi.IN_FORM, type=openapi.TYPE_BOOLEAN,
                              required=False, description="is_forgot to check operation for reset pin"),
        ]
    )
    def post(self, request):
        pu_login_pin = request.data.get('login_pin')
        is_forgot = request.data.get('is_forgot')

        try:
            if not pu_login_pin: return Response({'status': 'fail', 'message': 'Missing login pin.'}, status=status.HTTP_400_BAD_REQUEST)

            if is_forgot:
                if isboolean(is_forgot) is None: return Response({'status': 'fail','message': 'Invalid is_forgot value.'}, status=status.HTTP_400_BAD_REQUEST)
            if isnumber(pu_login_pin) == False: return Response({"status": "fail",'message': 'Login pin contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)
            if len(pu_login_pin) != 6: return Response({"status": "fail",'message': 'Login pin must contain 6 digits value.'}, status=status.HTTP_400_BAD_REQUEST)

            request_data = {'pu_login_pin': pu_login_pin}

            user = PortalUser.objects.get(id=request.user.id)

            # Generate credentials
            if isboolean(is_forgot) == True:
                user.pu_login_pin = make_password(pu_login_pin)
                user.save()
                access_token = get_tokens_for_user(user, timedelta(days=1))
                response_data = {
                    'status': 'success',
                    'message': 'Login PIN has been reset successfully.',
                    'user_role': user.pu_role,
                    'is_forgot': True,
                    'is_kyc_verification': user.is_kyc_verify,
                    'access_token': str(access_token)
                }
                return Response(response_data, status=status.HTTP_200_OK)

            else:
                serializer = GenerateCredentialsSerializer(
                    data=request_data, context={'request': request})
                if serializer.is_valid():
                    user.pu_login_pin = make_password(pu_login_pin)
                    user.save()

                    access_token = get_tokens_for_user(user, timedelta(days=1))

                    response_data = {
                        'status': 'success',
                        'message': 'Credentials generated successfully.',
                        'user_role': user.pu_role,
                        'is_kyc_verification': user.is_kyc_verify,
                        'access_token': str(access_token)
                    }
                    return Response(response_data, status=status.HTTP_200_OK)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except PortalUser.DoesNotExist:
            return Response({'status': 'fail', 'message': 'User does not exist.'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class UserLoginAPIView(APIView):
    permission_classes = [AllowAny]
    parser_classes = (MultiPartParser, FormParser)

    @swagger_auto_schema(
        tags=['Auth Operations'],
        manual_parameters=[
            openapi.Parameter('contact_no', openapi.IN_FORM, type=openapi.TYPE_STRING,
                              required=True, description="contact number for the user"),
            openapi.Parameter('login_pin', openapi.IN_FORM, type=openapi.TYPE_STRING,
                              required=True, description="login pin for the user")
        ]
    )
    def post(self, request):
        pu_contact_no = request.data.get('contact_no')
        pu_login_pin = request.data.get('login_pin')
        is_app = request.data.get('is_app') # kishan: add code on 12-11-2024

        if not pu_contact_no or not pu_login_pin:
            return Response({'status': 'fail', 'message': 'Missing contact number or login pin.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            if validate_mobile_number(pu_contact_no) == False: return Response({'status': 'fail','message': 'Invalid contact number.'}, status=status.HTTP_400_BAD_REQUEST)
            if isnumber(pu_login_pin) == False: return Response({"status": "fail",'message': 'Login pin contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)
            if len(pu_login_pin) != 6: return Response({"status": "fail",'message': 'Login pin must contain 6 digits value.'}, status=status.HTTP_400_BAD_REQUEST)

            user = PortalUser.objects.get(pu_contact_no=pu_contact_no)

            # kishan: below condition add on 12-11-2024
            if isboolean(is_app) == True and user.pu_role == 'ADMIN':
                return Response({'status': 'fail', 'message': 'Admin user cannot perform this action in the app.'}, status=status.HTTP_400_BAD_REQUEST)

            # Perform login procedure
            if check_password(pu_login_pin, user.pu_login_pin):
                access_token = get_tokens_for_user(user, timedelta(days=1))
                load_dotenv()
                device_active = 'device_number'
                number = os.getenv(device_active)
                get_user_log = PortalUserLoginLogs.objects.filter(pu_user=user, is_expire=False)

                if len(get_user_log) == int(number):
                    if get_user_log[0].expire_datetime <= timezone.now():
                        old_log = get_user_log[0]
                        old_log.is_expire = True
                        old_log.save()
                    else:
                        old_log = get_user_log[0]
                        old_log.is_expire = True
                        old_log.save()

                PortalUserLoginLogs.objects.create(
                    pu_user=user,
                    pu_user_role=user.pu_role,
                    pu_token=str(access_token),
                    browser_type=request.META['HTTP_USER_AGENT'],
                    expire_datetime = timezone.now() + timedelta(hours=24)
                )
                response_data = {
                    'status': 'success',
                    'message': 'Login successful.',
                    'user_role': user.pu_role,
                    'user_id': user.pk,  # kishan: add user_id new field on 11-11-2024
                    'is_kyc_verify': user.is_kyc_verify,
                    'access_token': str(access_token)
                }
                return Response(response_data, status=status.HTTP_200_OK)
            else:
                return Response({'status': 'fail', 'message': 'Invalid pin.'}, status=status.HTTP_404_NOT_FOUND)
        except PortalUser.DoesNotExist:
            return Response({'status': 'fail', 'message': 'User with this contact number does not exist'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'status': 'error', 'message': 'Internal Server Error ' + str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class UserProfileAPIView(APIView):
    """
    API view to handle the user profile.
    """
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAdmin | IsDistributor | IsRetailer]
    parser_classes = (MultiPartParser, FormParser)

    @swagger_auto_schema(
        tags=['User Profile'],
    )
    def get(self, request):
        """
        API endpoint for retrieving the authenticated user's details.

        This endpoint requires authentication with a JWT token.
        """
        try:
            users = PortalUser.objects.get(id=request.user.id)
            wallets = PortalUserWallet.objects.get(pu=users)

            serializer = PortalUserSerializer(users, context={'request': request})
            user_data = serializer.data

            if users.pu_role == "ADMIN":
                user_data['wallet_data'] = {
                    'main_wallet': float(wallets.main_wallet)
                }
                user_data['is_kyc_verified'] = users.is_kyc_verify
            elif users.pu_role == "DISTRIBUTOR":
                user_details = PortalUserDetails.objects.get(pu=users)

                # Fetch DistributorHierarchy
                try:
                    puc_obj = PortalUserCharges.objects.filter(pu_id=request.user.id).first()
                    distributor_hierarchy = DistributorHierarchy.objects.get(pk=puc_obj.dh_id)
                except DistributorHierarchy.DoesNotExist:
                    return Response({
                        'status': 'fail',
                        'message': 'Partner Category Does Not Exist'
                    }, status=status.HTTP_404_NOT_FOUND)

                if distributor_hierarchy.dh_name == 'SUPER DISTRIBUTOR':
                    partner_category = "SUPER DISTRIBUTOR"
                elif distributor_hierarchy.dh_name == 'MASTER DISTRIBUTOR':
                    partner_category = "MASTER DISTRIBUTOR"
                else:
                    partner_category = "DISTRIBUTOR"
                
                user_data['partner_category'] = partner_category
                user_data['aadhaar_card'] = user_details.aadhaar_card
                user_data['pan_card'] = user_details.pan_card
                user_data['wallet_data'] = {
                    'main_wallet': float(wallets.main_wallet),
                    'commission_wallet': float(wallets.commission_wallet)
                }
                user_data['is_kyc_verified'] = users.is_kyc_verify
            elif users.pu_role == "RETAILER":
                user_details1 = PortalUserDetails.objects.get(pu=users)

                user_data['wallet_data'] = {
                    'main_wallet': float(wallets.main_wallet),
                    'commission_wallet': float(wallets.commission_wallet),
                    'cashin_wallet': float(wallets.cashin_wallet),
                    'pg_wallet': float(wallets.pg_wallet)
                }
                user_data['aadhaar_card'] = user_details1.aadhaar_card
                user_data['pan_card'] = user_details1.pan_card
                user_data['is_kyc_verified'] = users.is_kyc_verify
            
            response_data = {
                'status': 'success',
                'message': 'User data retrieved successfully',
                'data': user_data
            }
            return Response(response_data, status=status.HTTP_200_OK)

        except Exception as e:
            response_error = {
                'status': 'error',
                'message': 'Internal server error',
                'data': str(e)
            }
            return Response(response_error, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# class CashfreePaymentAPIView(APIView):
#     """
#     API view to handle the cashfree payment gateway.
#     """
#     authentication_classes = [CustomJWTAuthentication]
#     permission_classes = [IsRetailer]
#     parser_classes = (MultiPartParser, FormParser)

#     @swagger_auto_schema(
#         tags=['CashFree PG'],
#         manual_parameters=[
#             openapi.Parameter('customer_name', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=False),
#             openapi.Parameter('customer_email', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=False),
#             openapi.Parameter('customer_contact_no', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),
#             openapi.Parameter('step', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=True),
#             openapi.Parameter('verify_code', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),
#             openapi.Parameter('order_amount', openapi.IN_FORM,
#                               type=openapi.TYPE_NUMBER, required=False),
#             openapi.Parameter('upi', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=False),
#             openapi.Parameter('card_number', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=False),
#             openapi.Parameter('card_holder_name', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=False),
#             openapi.Parameter('card_expiry_mm', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),
#             openapi.Parameter('card_expiry_yy', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),
#             openapi.Parameter('card_cvv', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),

#         ]
#     )
#     def post(self, request):
#         step = request.data.get('step')

#         if step == 'collect_customer_info':
#             return self.collect_customer_info(request)
#         elif step == 'verify_otp':
#             return self.verify_otp(request)
#         elif step == 'create_pay_order':
#             return self.create_pay_order(request)
#         elif step == 'pay_order':
#             return self.pay_order(request)
#         elif step == 'settle_order':
#             return self.settle_order(request)
#         else:
#             return Response({"error": "Invalid step"}, status=status.HTTP_400_BAD_REQUEST)

#     def collect_customer_info(self, request):
#         customer_name = request.data.get('customer_name')
#         customer_email = request.data.get('customer_email', None)
#         customer_contact_no = request.data.get('customer_contact_no')
#         try:
#             cu_obj = Customer.objects.get(
#                 customer_name=customer_name, customer_contact_no=customer_contact_no)
#             # Generate and store the verification code
#             verify_code = get_random_string(
#                 length=6, allowed_chars='0123456789')
#             pg_customer_id = get_random_string(length=13)

#             cu_obj.verify_code = verify_code
#             cu_obj.verify_code_expire_at = timezone.now() + timedelta(minutes=10)
#             cu_obj.save()

#             response_data = {
#                 'status': 'success',
#                 'message': 'Verification code sent successfully.',
#                 'data': {'verify_code': verify_code}
#             }
#             return Response(response_data, status=status.HTTP_200_OK)
#         except Customer.DoesNotExist:
#             # Generate and store the verification code
#             verify_code = get_random_string(
#                 length=6, allowed_chars='0123456789')
#             pg_customer_id = get_random_string(length=13)

#             Customer.objects.create(customer_name=customer_name, customer_email=customer_email,
#                                     customer_contact_no=customer_contact_no,
#                                     verify_code=verify_code,
#                                     verify_code_expire_at=timezone.now() + timedelta(minutes=10),
#                                     pg_customer_id=pg_customer_id)

#             response_data = {
#                 'status': 'success',
#                 'message': 'Verification code sent successfully.',
#                 'data': {'verify_code': verify_code}
#             }
#             return Response(response_data, status=status.HTTP_200_OK)
#         except Exception as e:
#             response_data = {
#                 'status': 'error',
#                 'message': 'Internal server error occurred.',
#                 # Optional: include the error details for debugging
#                 'details': str(e)
#             }
#             return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def verify_otp(self, request):
#         customer_contact_no = request.data.get('customer_contact_no')
#         verify_code = request.data.get('verify_code')

#         try:
#             cu_obj = Customer.objects.get(
#                 customer_contact_no=customer_contact_no)

#             if cu_obj.verify_code == verify_code and cu_obj.verify_code_expire_at > timezone.now():
#                 response_data = {
#                     'status': 'success',
#                     'message': 'Code verified successfully.'
#                 }
#                 return Response(response_data, status=status.HTTP_200_OK)
#             else:
#                 response_data = {
#                     'status': 'error',
#                     'message': 'Invalid or expired verification code.'
#                 }
#                 return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
#         except Customer.DoesNotExist:
#             response_data = {
#                 'status': 'error',
#                 'message': 'Customer with this contact number does not exist.'
#             }
#             return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
#         except Exception as e:
#             response_data = {
#                 'status': 'error',
#                 'message': 'Internal server error occurred.',
#                 # Optional: include the error details for debugging
#                 'details': str(e)
#             }
#             return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def create_pay_order(self, request):
#         pu_id = request.user.id
#         client_id = "TEST379597698355e9f49312abcff4795973",
#         client_secret = "TESTa85244521ed3349dcf149da1a167e666eab9ce93"
#         # order_url = "https://sandbox.cashfree.com/pg/orders"
#         # order_pay_url = "https://sandbox.cashfree.com/pg/orders/sessions"
#         order_url = "https://api.cashfree.com/pg/orders"
#         order_pay_url = "https://api.cashfree.com/pg/orders/sessions"

#         customer_contact_no = request.data.get('customer_contact_no')
#         order_amount = request.data.get('order_amount')
#         upi = request.data.get('upi')
#         card_number = request.data.get('card_number')
#         card_holder_name = request.data.get('card_holder_name')
#         card_expiry_mm = request.data.get('card_expiry_mm')
#         card_expiry_yy = request.data.get('card_expiry_yy')
#         card_cvv = request.data.get('card_cvv')
#         order_currency = 'INR'

#         try:
#             pu_obj = PortalUser.objects.get(id=pu_id)
#             with transaction.atomic():
#                 cu_obj = Customer.objects.get(customer_contact_no=customer_contact_no)
#                 pg_customer_id = cu_obj.pg_customer_id
#                 customer_email = cu_obj.customer_email

#                 order_payload = {
#                     "customer_details": {
#                         "customer_id": pg_customer_id,
#                         "customer_email": customer_email if not customer_email is None else None,
#                         "customer_phone": customer_contact_no
#                     },
#                     "order_amount": order_amount,
#                     "order_currency": order_currency
#                 }

#                 order_headers = {
#                     "accept": "application/json",
#                     "x-api-version": "2023-08-01",
#                     "content-type": "application/json",
#                     "x-client-id": "4497774aa0cd30fea81656c14c777944",
#                     "x-client-secret": "cfsk_ma_prod_082349799c0b18c3fbeba11efdcbe58f_30f3f209"
#                 }

#                 order_response = requests.post(
#                     order_url, json=order_payload, headers=order_headers)

#                 or_res = order_response.json()

#                 payment_session_id = or_res["payment_session_id"]
#                 if order_response.status_code == 200:
#                     order_pay_payload = {
#                         "payment_method": {
#                             "upi": {
#                                 "upi_id": upi,
#                                 "channel": "link"
#                             }
#                         },
#                         # "payment_method":{ "card": {
#                         #     "channel": "link",
#                         #     "card_number": card_number,
#                         #     "card_holder_name": card_holder_name,
#                         #     "card_expiry_mm": card_expiry_mm,
#                         #     "card_expiry_yy": card_expiry_yy,
#                         #     "card_cvv": card_cvv
#                         # } },
#                         "payment_session_id": payment_session_id
#                     }
#                     order_pay_headers = {
#                         "accept": "application/json",
#                         "x-api-version": "2023-08-01",
#                         "content-type": "application/json"
#                     }
#                     order_pay_response = requests.post(order_pay_url, json=order_pay_payload, headers=order_pay_headers)
#                     op_res = order_pay_response.json()
#                     if order_pay_response.status_code == 200:
#                         message = 'Payment Transfer Succcessfully.'
#                         st = 'success'
#                         status_code = order_pay_response.status_code
#                         try:
#                             puw_obj = PortalUserWallet.objects.get(pu_id=pu_id)
#                             pg_wallet = float(puw_obj.pg_wallet)
#                             puw_obj.pg_wallet = pg_wallet + float(order_amount)
#                             puw_obj.updated_at = datetime.now()
#                             puw_obj.save()
#                         except PortalUserWallet.DoesNotExist:
#                             puw_obj = PortalUserWallet.objects.create(pu_id=pu_id, pg_wallet=order_amount)

#                         PyGTransaction.objects.create(created_by=pu_obj, voucher_id=puw_obj.puw_id,
#                                                       voucher_type='Payment Gateway',
#                                                       pg_transfer_id=op_res['cf_payment_id'],
#                                                       pg_trn_amount=order_amount, pg_trn_mode='UPI',
#                                                       pg_trn_status='COMPLETED')
#                     else:
#                         message = op_res['message']
#                         st = 'fail'
#                         status_code = order_response.status_code
#                 else:
#                     message = or_res['message']
#                     st = 'fail'
#                     status_code = order_response.status_code
#                 # {"cart_details":null,"cf_order_id":"2183606878","created_at":"2024-08-24T14:51:56+05:30","customer_details":{"customer_id":"7112AAA23481","customer_name":null,"customer_email":"divyakoffeekodes@gmail.com","customer_phone":"9537665950","customer_uid":null},"entity":"order","order_amount":1.00,"order_currency":"INR","order_expiry_time":"2024-09-23T14:51:56+05:30","order_id":"order_3795972l6CoklbfglAkhp2eWMuECzkd2O","order_meta":{"return_url":null,"notify_url":null,"payment_methods":null},"order_note":null,"order_splits":[],"order_status":"ACTIVE","order_tags":null,"payment_session_id":"session_V7Hp3yfn0MFtt8mztPhMce5mSW60vp3gmdmmKEAlGghNKjaqSZ6IUabxuweU8ZoMUmFyntVNOoXG6BYbGIR843gPvJGyeutnBuikwRC01aU0","terminal_data":null}
#                 response_data = {
#                     'status': st,
#                     'message': message
#                 }
#                 return Response(response_data, status=status_code)
#         except Customer.DoesNotExist:
#             response_data = {
#                 'status': 'error',
#                 'message': 'Customer with this contact number does not exist.'
#             }
#             return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
#         except Exception as e:
#             response_data = {
#                 'status': 'error',
#                 'message': 'Internal server error occurred.',
#                 # Optional: include the error details for debugging
#                 'details': str(e)
#             }
#             return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     # def create_pay_order(self, request):
#     #     client_id = "TEST379597698355e9f49312abcff4795973",
#     #     client_secret = "TESTa85244521ed3349dcf149da1a167e666eab9ce93"
#     #     order_url = "https://sandbox.cashfree.com/pg/orders"
#     #     order_pay_url = "https://sandbox.cashfree.com/pg/orders/sessions"

#     #     customer_contact_no = request.data.get('customer_contact_no')
#     #     order_amount = request.data.get('order_amount')
#     #     upi = request.data.get('upi')
#     #     order_currency = 'INR'
#     #     settlement_type = request.data.get('settlement_type')

#     #     try:
#     #         cu_obj = Customer.objects.get(
#     #             customer_contact_no=customer_contact_no)
#     #         pg_customer_id = cu_obj.pg_customer_id
#     #         customer_email = cu_obj.customer_email

#     #         order_payload = {
#     #             "customer_details": {
#     #                 "customer_id": pg_customer_id,
#     #                 "customer_email": customer_email if not customer_email is None else None,
#     #                 "customer_phone": customer_contact_no
#     #             },
#     #             "order_amount": order_amount,
#     #             "order_currency": order_currency
#     #         }

#     #         order_headers = {
#     #             "accept": "application/json",
#     #             "x-api-version": "2023-08-01",
#     #             "content-type": "application/json",
#     #             "x-client-id": str(client_id),
#     #             "x-client-secret": str(client_secret)
#     #         }

#     #         order_response = requests.post(
#     #             order_url, json=order_payload, headers=order_headers)
#     #         print(order_response)
#     #         # {"cart_details":null,"cf_order_id":"2183606878","created_at":"2024-08-24T14:51:56+05:30","customer_details":{"customer_id":"7112AAA23481","customer_name":null,"customer_email":"divyakoffeekodes@gmail.com","customer_phone":"9537665950","customer_uid":null},"entity":"order","order_amount":1.00,"order_currency":"INR","order_expiry_time":"2024-09-23T14:51:56+05:30","order_id":"order_3795972l6CoklbfglAkhp2eWMuECzkd2O","order_meta":{"return_url":null,"notify_url":null,"payment_methods":null},"order_note":null,"order_splits":[],"order_status":"ACTIVE","order_tags":null,"payment_session_id":"session_V7Hp3yfn0MFtt8mztPhMce5mSW60vp3gmdmmKEAlGghNKjaqSZ6IUabxuweU8ZoMUmFyntVNOoXG6BYbGIR843gPvJGyeutnBuikwRC01aU0","terminal_data":null}
#     #         response_data = {
#     #             'status': 'success',
#     #             'message': 'Order created successfully.'
#     #         }
#     #         return Response(response_data, status=status.HTTP_200_OK)
#     #     except Customer.DoesNotExist:
#     #         response_data = {
#     #             'status': 'error',
#     #             'message': 'Customer with this contact number does not exist.'
#     #         }
#     #         return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
#     #     except Exception as e:
#     #         response_data = {
#     #             'status': 'error',
#     #             'message': 'Internal server error occurred.',
#     #             # Optional: include the error details for debugging
#     #             'details': str(e)
#     #         }
#     #         return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
# '''
# Cashfree Payout Module Start
# '''

# class CfPayOutAPIView(APIView):
#     authentication_classes = [CustomJWTAuthentication]
#     permission_classes = [IsRetailer]

#     def post(self, request):
#         try:
#             if 'contact_number' in request.data and 'first_name' in request.data and 'last_name' in request.data and 'address' in request.data and 'zip_code' in request.data:
#                 return self.get_payout_with_mobile(request)
#             elif 'contact_number' in request.data and 'otp' in request.data:
#                 return self.verify_mobile_otp(request)
#             elif 'contact_number' in request.data:
#                 return self.check_mobile_number(request)
#             elif 'account_number':
#                 return self.get_payout_with_account(request)
#             else:
#                 return Response({'status': 'fail', 'message': 'Invalid data.'}, status=status.HTTP_400_BAD_REQUEST)

#         except Exception as e:
#             return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def get_payout_with_mobile(self, request):
#         try:
#             contact_number = request.data.get('contact_number')
#             first_name = request.data.get('first_name')
#             last_name = request.data.get('last_name')
#             address = request.data.get('address')
#             zip_code = request.data.get('zip_code')
#             if not contact_number:
#                 return Response({'status': 'fail', 'message': 'contact number is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
#             if not first_name:
#                 return Response({'status': 'fail', 'message': 'first name is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
#             if not last_name:
#                 return Response({'status': 'fail', 'message': 'last name is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
#             if not zip_code:
#                 return Response({'status': 'fail', 'message': 'zip code is required.'}, status=status.HTTP_400_BAD_REQUEST)

#             mobile_number_validation = validate_mobile_number(contact_number)
#             if mobile_number_validation == False:
#                 return Response({'status': 'fail', 'message': 'Invalid contact number format.'}, status=status.HTTP_400_BAD_REQUEST)

#             first_name_validation = isstring(first_name)
#             if first_name_validation == False:
#                 return Response({'status': 'fail', 'message': 'First name must be a valid string.'}, status=status.HTTP_400_BAD_REQUEST)

#             last_name_validation = isstring(last_name)
#             if last_name_validation == False:
#                 return Response({'status': 'fail', 'message': 'Last name must be a valid string.'}, status=status.HTTP_400_BAD_REQUEST)

#             zip_code_validation = isnumber(zip_code)
#             if zip_code_validation == False:
#                 return Response({'status': 'fail', 'message': 'Zip code must be a number.'}, status=status.HTTP_400_BAD_REQUEST)
#             if len(zip_code) != 6:
#                 return Response({'status': 'fail', 'message': 'Zip code must be 6 digits long.'}, status=status.HTTP_400_BAD_REQUEST)

#             get_payout_customer = PyOtCustomer.objects.get(customer_contact_no=contact_number)

#             if get_payout_customer.pyot_unique_id == None:
#                 try:
#                     exists_contact_number = PyOtCustomer.objects.get(customer_contact_no=contact_number)
#                 except PyOtCustomer.DoesNotExist:
#                     return Response({'status': 'fail', 'message': 'This contact number does not exist.'}, status=status.HTTP_400_BAD_REQUEST)
                
#                 pyot_cs_prefix = "PYOT_CS"

#                 last_pyot_id = PyOtCustomer.objects.filter(pyot_unique_id__startswith="PYOT_CS").order_by(
#                     '-pyot_unique_id').first()
#                 if last_pyot_id:
#                     last_number = int(last_pyot_id.pyot_unique_id[-5:])  
#                     new_number = f"{last_number + 1:05d}"  
#                 else:
#                     new_number = "00001"
#                 print('number number', f'{pyot_cs_prefix}{new_number}')
#                 exists_contact_number.pyot_unique_id = f'{pyot_cs_prefix}{new_number}'
#                 exists_contact_number.customer_first_name=first_name
#                 exists_contact_number.customer_last_name=last_name
#                 exists_contact_number.customer_address=address
#                 exists_contact_number.customer_zip_code=zip_code
#                 exists_contact_number.is_verify = True
#                 exists_contact_number.save()

#                 serializer = PyOtCustomerSerializer(exists_contact_number)
#                 data = {
#                     'results': serializer.data
#                 }

#                 return Response({'status': 'success', 'message': 'New customer created successfully.', 'data': data}, status=status.HTTP_200_OK)

#             else:
#                 return Response({'status': 'success', 'message': 'Customer with this contact number already exists'}, status=status.HTTP_400_BAD_REQUEST)

#         except PyOtCustomer.DoesNotExist:
#             return Response({'status': 'fail', 'message': 'Payout customer dose not exists.'}, status=status.HTTP_400_BAD_REQUEST)

#         except Exception as e:
#             return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def check_mobile_number(self, request):
#         try:
#             contact_number = request.data.get('contact_number')
#             if not contact_number:
#                 return Response({'status': 'fail', 'message': 'contact number is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
#             mobile_number_validation = validate_mobile_number(contact_number)
#             if mobile_number_validation == False:
#                 return Response({'status': 'fail', 'message': 'Invalid contact number format.'}, status=status.HTTP_400_BAD_REQUEST)
            
#             exists_mobile_number = PyOtCustomer.objects.get(customer_contact_no=contact_number)
#             if exists_mobile_number.is_verify == True:
#                 banks_list = []

#                 payout_banks = PyOtBankAccount.objects.all()

#                 for bank in payout_banks:
#                     for value in bank.customer_contact:
#                         if value==contact_number:
#                             banks_list.append(bank)

#                 if len(banks_list) != 0:
#                     banks_list = PyOtBankSerializer(banks_list, many=True).data

#                 data = {
#                     'results': banks_list
#                 }

#                 return Response({'status': 'success', 'message': 'Get Banks Account Details.', 'data': data}, status=status.HTTP_200_OK)
            
#             else:
#                 code = get_random_string(length=6, allowed_chars='0123456789')
#                 exists_mobile_number.verify_code = code
#                 exists_mobile_number.verify_code_expire_at = timezone.now() + timedelta(minutes=15)
#                 exists_mobile_number.save()
#                 return Response({'status': 'success', 'message': 'Resend verify code successfully.', 'verify_code': code, 'expiry_time': '15 minutes'}, status=status.HTTP_200_OK)

#         except PyOtCustomer.DoesNotExist:
#             code = get_random_string(length=6, allowed_chars='0123456789')
#             PyOtCustomer.objects.create(
#                 customer_contact_no=contact_number,
#                 verify_code=code,
#                 verify_code_expire_at=timezone.now() + timedelta(minutes=15),
#             )
#             return Response({'status': 'success', 'message': 'New customer record created. A verification code has been sent to the mobile number.', 'verify_code': code, 'expiry_time': '15 minutes'}, status=status.HTTP_200_OK)

#         except Exception as e:
#             return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


#     def verify_mobile_otp(self, request):
#         try:
#             contact_number = request.data.get('contact_number')
#             otp = request.data.get('otp')

#             if not contact_number:
#                 return Response({'status': 'fail', 'message': 'contact number is required.'}, status=status.HTTP_400_BAD_REQUEST)

#             if not otp:
#                 return Response({'status': 'fail', 'message': 'otp is required.'}, status=status.HTTP_400_BAD_REQUEST)

#             mobile_number_validation = validate_mobile_number(contact_number)
#             if mobile_number_validation == False:
#                 return Response({'status': 'fail', 'message': 'Invalid contact number format.'}, status=status.HTTP_400_BAD_REQUEST)

#             code_validation = isnumber(otp)
#             if code_validation == False:
#                 return Response({'status': 'fail', 'message': 'OTP code must be a number.'}, status=status.HTTP_400_BAD_REQUEST)

#             if len(otp) != 6:
#                 return Response({'status': 'fail', 'message': 'OTP code must be 6 digits long.'}, status=status.HTTP_400_BAD_REQUEST)

#             get_payout_customer = PyOtCustomer.objects.get(customer_contact_no=contact_number)
#             if otp == get_payout_customer.verify_code:

#                 if timezone.now() < get_payout_customer.verify_code_expire_at:
#                     get_payout_customer.verify_code = None
#                     get_payout_customer.verify_code_expire_at = None
#                     get_payout_customer.save()

#                     data = {
#                         'status': 'success',
#                         'message': 'OTP verified successfully'
#                     }
#                     return Response(data, status=status.HTTP_200_OK)

#                 else:
#                     return Response({'status': 'fail', 'message': 'OTP has expired.'}, status=status.HTTP_400_BAD_REQUEST)

#             else:
#                 return Response({'status': 'fail', 'message': 'Invalid OTP provided.'}, status=status.HTTP_400_BAD_REQUEST)

#         except PyOtCustomer.DoesNotExist:
#             return Response({'status': 'fail', 'message': 'Payout customer dose not exists.'}, status=status.HTTP_404_NOT_FOUND)

#         except Exception as e:
#             return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def get_payout_with_account(self, request):
#         try:
#             account_number = request.data.get('account_number')
#             if not account_number:
#                 return Response({'status': 'fail', 'message': 'account number is required.'}, status=status.HTTP_400_BAD_REQUEST)

#             account_number_validation = isnumber(account_number)
#             if account_number_validation == False:
#                 return Response({'status': 'fail', 'message': 'account number must be a number.'}, status=status.HTTP_404_NOT_FOUND)

#             get_payout_account = PyOtBankAccount.objects.get(bnk_acc_no=account_number)

#             customer_data = []

#             for contact in get_payout_account.customer_contact:
#                 get_contact_number = PyOtCustomer.objects.filter(customer_contact_no=contact).first()
#                 if get_contact_number:
#                     customer_data.append(get_contact_number)
            
#             if len(customer_data) != 0:
#                 serializer = PyOtCustomerSerializer(customer_data, many=True).data
#             else:
#                 serializer = []
#             data = {
#                 'status': 'success',
#                 'message': 'get all contact number successfully.',
#                 'results': serializer
#             }
#             return Response(data, status=status.HTTP_200_OK)

#         except PyOtBankAccount.DoesNotExist:
#             return Response({'status': 'fail', 'message': 'account number dose not exists.'}, status=status.HTTP_404_NOT_FOUND)

#         except Exception as e:
#             return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
# class CashfreePayoutAPIView(APIView):
#     """
#     API view to handle the cashfree payment gateway.
#     """
#     authentication_classes = [CustomJWTAuthentication]
#     permission_classes = [IsRetailer]
#     parser_classes = (MultiPartParser, FormParser)

#     @swagger_auto_schema(
#         tags=['CashFree Payouts'],
#         manual_parameters=[
#             openapi.Parameter('rtl_beneficiary_id', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=False),
#             openapi.Parameter('py_trn_amount', openapi.IN_FORM,
#                               type=openapi.TYPE_NUMBER, required=False),
#             openapi.Parameter('page_number', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),
#             openapi.Parameter('page_size', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),
#             openapi.Parameter('search', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=False),
#             openapi.Parameter('py_trn_id', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),
#         ]
#     )
#     def post(self, request):
#         try:
#             if 'page_number' in request.data and 'page_size' in request.data:
#                 return self.fetch_payout_transaction(request)
#             elif 'rtl_beneficiary_id' in request.data and 'py_trn_amount' in request.data:
#                 return self.create_payout_transaction(request)
#             else:
#                 return Response({'status': 'error', 'message': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)
#         except Exception as e:
#             response_data = {
#                 'status': 'error',
#                 'message': f'{str(e)}'
#             }
#             return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def create_payout_transaction(self, request):
#         client_id = "CF379597CR4QJ3VPU07S7391HLIG",
#         client_secret = "cfsk_ma_test_579d140d50ce6d479c922805f91c1f9a_747f96ec"
#         add_beneficiary_url = "https://api.cashfree.com/payout/beneficiary"
#         payout_transfer_url = "https://api.cashfree.com/payout/transfers"

#         headers = {
#             "accept": "application/json",
#             "x-api-version": "2024-01-01",
#             "content-type": "application/json",
#             "x-client-id": "CF449777CRQG8U0O577S73AHL800",
#             "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
#         }

#         rtl_beneficiary_id = request.data.get('rtl_beneficiary_id')
#         py_trn_amount = request.data.get('py_trn_amount')

#         try:
#             with transaction.atomic():
#                 user_wallet = PortalUserWallet.objects.get(pu=request.user)
#                 main_wallet = user_wallet.main_wallet

#                 if float(main_wallet) <= float(py_trn_amount):
#                     return JsonResponse({'status': 'Main wallet has insufficient balance.'}, 
#                                         status=status.HTTP_400_BAD_REQUEST)

#                 rtl_bnk_obj = RetailerBankAccounts.objects.get(rtl_beneficiary_id=rtl_beneficiary_id)

#                 add_beneficiary_payload = {
#                     "beneficiary_instrument_details": {
#                         "bank_account_number": str(rtl_bnk_obj.bnk_acc_no),
#                         "bank_ifsc": str(rtl_bnk_obj.bnk_ifsc)
#                     },
#                     "beneficiary_id": str(rtl_beneficiary_id),
#                     "beneficiary_name": str(rtl_bnk_obj.rtl_beneficiary_name),
#                     "beneficiary_contact_details": {
#                         "beneficiary_email": "mr9537858000@gmail.com",
#                         "beneficiary_phone": "9537858000"
#                     }
#                 }

#                 beneficiary_response = requests.post(
#                     add_beneficiary_url, json=add_beneficiary_payload, headers=headers)

#                 bene_response = beneficiary_response.json()

#                 if beneficiary_response.status_code == 201:
#                     transfer_payload = {
#                         "beneficiary_details": {"beneficiary_id": rtl_beneficiary_id},
#                         "transfer_id": get_random_string(length=12),
#                         "transfer_amount": py_trn_amount,
#                         "transfer_currency": "INR",
#                         "transfer_mode": "imps",
#                         "fundsource_id": "YES_CONNECTED_55010_091bf6b"
#                     }
#                     payout_response = requests.post(payout_transfer_url, json=transfer_payload, headers=headers)
#                     py_response = payout_response.json()
#                     if payout_response.status_code == 200:
#                         PayoutTransaction.objects.create(py_transfer_id=py_response["transfer_id"], rtl_bnk=rtl_bnk_obj,
#                                                          py_trn_amount=py_response["transfer_amount"],
#                                                          py_trn_mode=py_response["transfer_mode"],
#                                                          created_by_id=request.user.id)
#                         message = "Payout Transfer done successfully"
#                         status_code = payout_response.status_code
#                     else:
#                         message = py_response["message"]
#                         status_code = payout_response.status_code
#                 else:
#                     transfer_payload = {
#                         "beneficiary_details": {"beneficiary_id": rtl_beneficiary_id},
#                         "transfer_id": get_random_string(length=12),
#                         "transfer_amount": py_trn_amount,
#                         "transfer_currency": "INR",
#                         "transfer_mode": "imps",
#                         "fundsource_id": "YES_CONNECTED_55010_091bf6b"
#                     }
#                     payout_response = requests.post(payout_transfer_url, json=transfer_payload, headers=headers)
#                     py_response = payout_response.json()
#                     if payout_response.status_code == 200:
#                         PayoutTransaction.objects.create(py_transfer_id=py_response["transfer_id"], rtl_bnk=rtl_bnk_obj,
#                                                          py_trn_amount=py_response["transfer_amount"],
#                                                          py_trn_mode=py_response["transfer_mode"],
#                                                          created_by_id=request.user.id)
#                         message = "Payout Transfer done successfully"
#                         status_code = payout_response.status_code
#                     else:
#                         message = py_response["message"]
#                         status_code = payout_response.status_code

#                 response_data = {
#                     'status': 'success',
#                     'message': message
#                 }
#                 return Response(response_data, status=status_code)
#         except Customer.DoesNotExist:
#             response_data = {
#                 'status': 'error',
#                 'message': 'Customer with this contact number does not exist.'
#             }
#             return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
#         except Exception as e:
#             response_data = {
#                 'status': 'error',
#                 'message': 'Internal server error occurred.',
#                 # Optional: include the error details for debugging
#                 'details': str(e)
#             }
#             return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def fetch_payout_transaction(self, request):
#         """
#         ###Handles fetching SaService objects based on various criteria.
#         """
#         try:
#             # Default to page 1 if not provided
#             page = request.data.get('page_number', 1)
#             # Number of items per page
#             page_size = request.data.get('page_size', 10)

#             py_trn_id = request.data.get('py_trn_id', None)
#             search_query = request.data.get('search', None)

#             queryset = PayoutTransaction.objects.all().order_by('-pk')

#             if py_trn_id:
#                 queryset = queryset.filter(py_trn_id=py_trn_id)

#             if search_query:
#                 queryset = queryset.filter(
#                     Q(py_transfer_id__icontains=search_query) |
#                     Q(rtl_bnk__rtl_beneficiary_name__icontains=search_query) |
#                     Q(rtl_bnk__rtl_bank_name__icontains=search_query) |
#                     Q(rtl_bnk__bnk_acc_no__icontains=search_query) |
#                     Q(rtl_bnk__bnk_ifsc__icontains=search_query) |
#                     Q(rtl_bnk__rtl_vpa__icontains=search_query) |
#                     Q(py_trn_amount__icontains=search_query) |
#                     Q(py_trn_mode__icontains=search_query) |
#                     Q(py_trn_status__icontains=search_query)
#                 )

#             paginator = Paginator(queryset, page_size)
#             if not queryset.exists():
#                 paginated_response_data = {
#                     'total_pages': 0,
#                     'current_page': 0,
#                     'total_items': 0,
#                     'results': []
#                 }
#                 response_data = {
#                     'status': 'fail',
#                     'message': 'Payout transactions not found.',
#                     'data': paginated_response_data
#                 }
#                 return Response(response_data, status=status.HTTP_200_OK)

#             try:
#                 page_obj = paginator.page(page)
#             except EmptyPage:
#                 return Response({
#                     'status': 'fail',
#                     'message': 'Page not found.',
#                     'data': {}
#                 }, status=status.HTTP_404_NOT_FOUND)

#             serializer = PayoutTransactionSerializer(page_obj.object_list, many=True, context={
#                 'request': request, 'exclude_fields': ["created_at", "updated_at", "updated_by", "created_by"]})

#             response_data = {
#                 'total_pages': paginator.num_pages,
#                 'current_page': page_obj.number,
#                 'total_items': paginator.count,
#                 'results': serializer.data
#             }

#             response_data = {
#                 'status': 'success',
#                 'message': 'Payout Transaction Data',
#                 'data': response_data
#             }

#             return Response(response_data, status=status.HTTP_200_OK)

#         except Exception as e:
#             response_error = {
#                 'status': 'error',
#                 'message': 'Internal server error',
#                 'data': str(e)
#             }
#             return Response(response_error, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# class CsfrPayoutAPIView(APIView):
#     """
#     API view to handle the cashfree payout.
#     """
#     authentication_classes = [CustomJWTAuthentication]
#     permission_classes = [IsRetailer]
#     parser_classes = (MultiPartParser, FormParser)

#     def post(self, request):
#         customer_contact_no = request.data.get("customer_contact_no")
#         customer_name = request.data.get("customer_name")
#         customer_zip_code = request.data.get("customer_zip_code")
#         bnk_acc_no = request.data.get("bnk_acc_no")

#         # Case 1: Check contact number in the request
#         if customer_contact_no:
#             try:
#                 customer = PyOtCustomer.objects.get(customer_contact_no=customer_contact_no)
#                 # If contact exists, return connected bank accounts
#                 bank_accounts = customer.bank_accounts.all()
#                 account_data = [
#                     {"account_no": acc.account_no, "bank_name": acc.bank_name}
#                     for acc in bank_accounts
#                 ]
#                 return Response({"bank_accounts": account_data}, status=status.HTTP_200_OK)
#             except PyOtCustomer.DoesNotExist:
#                 # Contact doesn't exist - Simulate verification (you can replace this with real OTP flow)
#                 verified = self.verify_contact(contact_no)
#                 if verified:
#                     return Response({"message": "Contact verified", "bank_accounts": []}, status=status.HTTP_200_OK)
#                 return Response({"error": "Verification failed"}, status=status.HTTP_400_BAD_REQUEST)

#         # Case 2: Check account number in the request
#         elif bnk_acc_no:
#             try:
#                 bank_account = PyOtBankAccount.objects.get(bnk_acc_no=bnk_acc_no)
#                 customers = bank_account.customers.all()
#                 customer_data = [
#                     {"name": cust.name, "contact_no": cust.contact_no, "zip_code": cust.zip_code}
#                     for cust in customers
#                 ]
#                 return Response({"customers": customer_data}, status=status.HTTP_200_OK)
#             except PyOtBankAccount.DoesNotExist:
#                 return Response({"error": "Bank account not found"}, status=status.HTTP_404_NOT_FOUND)

#         return Response({"error": "Invalid request data"}, status=status.HTTP_400_BAD_REQUEST)


# '''
# Cashfree Payout Module End
# '''

# class RetailerBankAPIView(APIView):
#     """
#     API view to handle the retailer bank accounts.
#     """
#     authentication_classes = [CustomJWTAuthentication]
#     permission_classes = [IsRetailer]
#     parser_classes = (MultiPartParser, FormParser)

#     @swagger_auto_schema(
#         tags=['Retailer Bank Account'],
#         manual_parameters=[
#             # fetch distributor hierarchy parameters
#             openapi.Parameter('rtl_beneficiary_name',
#                               openapi.IN_FORM, type=openapi.TYPE_STRING, ),
#             openapi.Parameter('rtl_bank_name', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, ),
#             openapi.Parameter('bnk_acc_no', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, ),
#             openapi.Parameter('bnk_ifsc', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, ),
#             openapi.Parameter('rtl_vpa', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, ),
#             openapi.Parameter('rtl_bnk_id', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, ),
#             openapi.Parameter('search', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING),
#             openapi.Parameter('page_number', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING),
#             openapi.Parameter('page_size', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING),
#         ]
#     )
#     def post(self, request):
#         """
#         ###Handles POST requests to fetch & create distributor hierarchy based on parameters.
#         """

#         try:
#             if 'page_number' in request.data and 'page_size' in request.data:
#                 return self.fetch_bank_account(request)
#             elif 'rtl_beneficiary_name' in request.data:
#                 return self.create_bank_account(request)
#             else:
#                 return Response({'status': 'error', 'message': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)
#         except Exception as e:
#             response_data = {
#                 'status': 'error',
#                 'message': f'{str(e)}'
#             }
#             return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def create_bank_account(self, request):
#         """
#         ###Handles retailer bank account creation.
#         """
#         try:
#             print("request.user", request.user.id)
#             with transaction.atomic():
#                 serializer = RetailerBankAccountsSerializer(
#                     data=request.data, context={'request': request})
#                 if serializer.is_valid():
#                     serializer.save(created_by_id=request.user.id)

#                     response_data = {
#                         'status': 'success',
#                         'message': 'Retailer Bank Account Created Successfully'
#                     }
#                     return Response(response_data, status=status.HTTP_201_CREATED)
#                 response_data = {
#                     'status': 'fail',
#                     'message': f'{serializer.errors}'
#                 }
#                 return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
#         except Exception as e:
#             response_data = {
#                 'status': 'error',
#                 'message': f'{str(e)}'
#             }
#             return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def fetch_bank_account(self, request):
#         """
#         ###Handles fetching SaService objects based on various criteria.
#         """
#         try:
#             # Default to page 1 if not provided
#             page = request.data.get('page_number', 1)
#             # Number of items per page
#             page_size = request.data.get('page_size', 10)

#             rtl_bnk_id = request.data.get('rtl_bnk_id', None)
#             search_query = request.data.get('search', None)

#             queryset = RetailerBankAccounts.objects.filter(
#                 is_deleted=False).order_by('-pk')

#             if rtl_bnk_id:
#                 queryset = queryset.filter(rtl_bnk_id=rtl_bnk_id)

#             if search_query:
#                 queryset = queryset.filter(
#                     Q(rtl_beneficiary_id__icontains=search_query) |
#                     Q(rtl_beneficiary_name__icontains=search_query) |
#                     Q(rtl_bank_name__icontains=search_query) |
#                     Q(bnk_acc_no__icontains=search_query) |
#                     Q(bnk_ifsc__icontains=search_query) |
#                     Q(rtl_vpa__icontains=search_query)
#                 )

#             paginator = Paginator(queryset, page_size)
#             if not queryset.exists():
#                 paginated_response_data = {
#                     'total_pages': 0,
#                     'current_page': 0,
#                     'total_items': 0,
#                     'results': []
#                 }
#                 response_data = {
#                     'status': 'fail',
#                     'message': 'Bank Accounts not found.',
#                     'data': paginated_response_data
#                 }
#                 return Response(response_data, status=status.HTTP_200_OK)

#             try:
#                 page_obj = paginator.page(page)
#             except EmptyPage:
#                 return Response({
#                     'status': 'fail',
#                     'message': 'Page not found.',
#                     'data': {}
#                 }, status=status.HTTP_404_NOT_FOUND)

#             serializer = RetailerBankAccountsSerializer(page_obj.object_list, many=True, context={
#                 'request': request,
#                 'exclude_fields': ["created_at", "updated_at", "is_deleted", "updated_by", "created_by"]})

#             response_data = {
#                 'total_pages': paginator.num_pages,
#                 'current_page': page_obj.number,
#                 'total_items': paginator.count,
#                 'results': serializer.data
#             }

#             response_data = {
#                 'status': 'success',
#                 'message': 'Service Data',
#                 'data': response_data
#             }

#             return Response(response_data, status=status.HTTP_200_OK)

#         except Exception as e:
#             response_error = {
#                 'status': 'error',
#                 'message': 'Internal server error',
#                 'data': str(e)
#             }
#             return Response(response_error, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     @swagger_auto_schema(
#         tags=['Retailer Bank Account'],
#         manual_parameters=[
#             openapi.Parameter('rtl_bnk_id', openapi.IN_FORM, type=openapi.TYPE_INTEGER,
#                               required=True, description='ID of the service to update'),
#             openapi.Parameter('rtl_beneficiary_name', openapi.IN_FORM, type=openapi.TYPE_INTEGER,
#                               required=True, description='ID of the service to update'),
#             openapi.Parameter('rtl_bank_name', openapi.IN_FORM, type=openapi.TYPE_STRING,
#                               required=False, description='description for the service.'),
#             openapi.Parameter('bnk_acc_no', openapi.IN_FORM, type=openapi.TYPE_STRING,
#                               required=False, description='description for the service.'),
#             openapi.Parameter('bnk_ifsc', openapi.IN_FORM, type=openapi.TYPE_STRING,
#                               required=False, description='description for the service.'),
#             openapi.Parameter('rtl_vpa', openapi.IN_FORM, type=openapi.TYPE_STRING,
#                               required=False, description='description for the service.'),
#             openapi.Parameter('is_deactive', openapi.IN_FORM, type=openapi.TYPE_BOOLEAN, required=False,
#                               description='Set service provider as inactive (True) or active (False)'),
#         ],
#         security=[{'Bearer': []}]
#     )
#     def put(self, request):
#         """
#         ###Handles updating a retailer bank account object identified by 'rtl_bnk_id'.
#         """
#         try:
#             with transaction.atomic():
#                 savepoint = transaction.savepoint()
#                 rtl_bnk_id = request.data.get('rtl_bnk_id')
#                 if not rtl_bnk_id:
#                     return Response({
#                         'status': 'fail',
#                         'message': 'Retailer Bank Account ID is required'
#                     }, status=status.HTTP_400_BAD_REQUEST)

#                 rtl_instance = RetailerBankAccounts.objects.get(
#                     rtl_bnk_id=rtl_bnk_id, is_deleted=False)

#                 if rtl_instance.is_deleted:
#                     return Response({
#                         'status': 'fail',
#                         'message': f'Retailer Bank Account with ID {rtl_bnk_id} not found'
#                     }, status=status.HTTP_404_NOT_FOUND)

#                 serializer = RetailerBankAccountsSerializer(
#                     rtl_instance, data=request.data, partial=True, context={'request': request})
#                 if serializer.is_valid():
#                     # serializer.validated_data['updated_at']= datetime.now()
#                     serializer.save(updated_at=datetime.now(),
#                                     updated_by=request.user)

#                     transaction.savepoint_commit(savepoint)
#                     return Response({
#                         'status': 'success',
#                         'message': 'Retailer Bank Account details updated successfully',
#                     })

#                 return Response({
#                     'status': 'fail',
#                     'message': 'Failed to update retailer bank account.',
#                     'data': serializer.errors
#                 }, status=status.HTTP_400_BAD_REQUEST)

#         except RetailerBankAccounts.DoesNotExist:
#             return Response({
#                 'status': 'fail',
#                 'message': f'Service with ID {rtl_bnk_id} does not exist'
#             }, status=status.HTTP_404_NOT_FOUND)

#         except Exception as e:
#             return Response({
#                 'status': 'error',
#                 'message': str(e)
#             }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     @swagger_auto_schema(
#         tags=['Retailer Bank Account'],
#         manual_parameters=[
#             openapi.Parameter('rtl_bnk_id', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=True),
#         ],
#         security=[{'Bearer': []}]
#     )
#     def delete(self, request):
#         """
#         Delete a retailer bank account.
#         """
#         try:
#             with transaction.atomic():
#                 savepoint = transaction.savepoint()
#                 rtl_bnk_id = request.data.get('rtl_bnk_id')
#                 if not rtl_bnk_id:
#                     response_data = {
#                         'status': 'fail',
#                         'message': 'ID is required'
#                     }
#                     return Response(response_data, status=status.HTTP_400_BAD_REQUEST)

#                 rtl_data = RetailerBankAccounts.objects.get(
#                     rtl_bnk_id=rtl_bnk_id)
#                 if rtl_data.is_deleted:
#                     response_data = {
#                         'status': 'success',
#                         'message': 'Already, this bank account has been Deleted'
#                     }
#                 else:
#                     rtl_data.is_deleted = True
#                     rtl_data.is_deactive = True
#                     rtl_data.save()

#                     transaction.savepoint_commit(savepoint)
#                     response_data = {
#                         'status': 'success',
#                         'message': 'Retailer Bank Account Deleted Successfully'
#                     }
#                 return Response(response_data, status=status.HTTP_200_OK)

#         except RetailerBankAccounts.DoesNotExist:
#             response_data = {
#                 'status': 'fail',
#                 'message': 'Retailer Bank Account not found'
#             }
#             return Response(response_data, status=status.HTTP_404_NOT_FOUND)

#         except Exception as e:
#             response_data = {
#                 'status': 'error',
#                 'message': f'Internal server error: {str(e)}'
#             }
#             return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# from django.db import connections
# class RazorpayPaymentAPIView(APIView):
#     """
#     API view to handle the razorpay payment gateway.
#     """
#     authentication_classes = [CustomJWTAuthentication]
#     permission_classes = [IsRetailer]
#     parser_classes = (MultiPartParser, FormParser)

#     @swagger_auto_schema(
#         tags=['Razorpay PG'],
#         manual_parameters=[
#             openapi.Parameter('customer_contact_no', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),
#             openapi.Parameter('contact_otp', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),
#             openapi.Parameter('customer_aadhaar_no', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),
#             openapi.Parameter('ref_id', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),
#             openapi.Parameter('aadhaar_otp', openapi.IN_FORM,
#                               type=openapi.TYPE_INTEGER, required=False),
#             openapi.Parameter('customer_name', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=False),
#             openapi.Parameter('customer_email', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=False),
#             openapi.Parameter('order_amount', openapi.IN_FORM,
#                               type=openapi.TYPE_NUMBER, required=False),
#             openapi.Parameter('razorpay_order_id', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=False),
#             openapi.Parameter('razorpay_payment_id', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=False),
#             openapi.Parameter('razorpay_signature', openapi.IN_FORM,
#                               type=openapi.TYPE_STRING, required=False),
#         ]
#     )
#     def post(self, request):
#         try:
#             # if 'customer_contact_no' in request.data and 'customer_aadhaar_no' in request.data and 'customer_name' in request.data and 'customer_email' in request.data and 'order_amount' in request.data:
#             if 'customer_contact_no' in request.data and 'customer_name' in request.data and 'customer_email' in request.data and 'order_amount' in request.data:
#                 return self.create_order(request)
#             elif ('ref_id' in request.data and 'aadhaar_otp' in request.data) or (
#                     'customer_contact_no' in request.data and 'contact_otp' in request.data):
#                 return self.verify_otp(request)
#             elif 'customer_contact_no' in request.data:
#                 return self.verify_contact(request)
#             elif 'customer_aadhaar_no' in request.data:
#                 return self.verify_aadhaar(request)
#             elif 'razorpay_order_id' in request.data and 'razorpay_payment_id' in request.data and 'razorpay_signature' in request.data:
#                 return self.verify_payment(request)
#             elif 'page_number' in request.data and 'page_size' in request.data or 'distributor_id' in request.data:
#                 return self.fetch_transaction(request)
#             else:
#                 return Response({'status': 'error','message': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)
#         except Exception as e:
#             response_data = {
#                 'status': 'error',
#                 'message': str(e)
#             }
#             return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def verify_contact(self, request):
#         customer_contact_no = request.data.get('customer_contact_no')
#         try:
#             cu_obj = Customer.objects.get(customer_contact_no=customer_contact_no)
#             # Generate and store the verification code
#             verify_code = get_random_string(
#                 length=6, allowed_chars='0123456789')
#             pg_customer_id = get_random_string(length=13)

#             cu_obj.verify_code = verify_code
#             cu_obj.verify_code_expire_at = timezone.now() + timedelta(minutes=10)
#             cu_obj.save()

#             response_data = {
#                 'status': 'success',
#                 'message': 'Verification code sent successfully.',
#                 'data': {'verify_code': verify_code}
#             }
#             return Response(response_data, status=status.HTTP_200_OK)
#         except Customer.DoesNotExist:
#             # Generate and store the verification code
#             verify_code = get_random_string(
#                 length=6, allowed_chars='0123456789')
#             pg_customer_id = get_random_string(length=13)

#             Customer.objects.create(customer_contact_no=customer_contact_no,
#                                     verify_code=verify_code,
#                                     verify_code_expire_at=timezone.now() + timedelta(minutes=10),
#                                     pg_customer_id=pg_customer_id)

#             response_data = {
#                 'status': 'success',
#                 'message': 'Verification code sent successfully.',
#                 'data': {'verify_code': verify_code}
#             }
#             return Response(response_data, status=status.HTTP_200_OK)
#         except Exception as e:
#             response_data = {
#                 'status': 'error',
#                 'message': 'Internal server error occurred.',
#                 # Optional: include the error details for debugging
#                 'details': str(e)
#             }
#             return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def verify_otp(self, request):
#         if 'ref_id' in request.data and 'aadhaar_otp' in request.data:
#             ref_id = request.data.get('ref_id')
#             aadhaar_otp = request.data.get('aadhaar_otp')

#             otp_url = "https://api.cashfree.com/verification/offline-aadhaar/verify"

#             otp_payload = {
#                 "otp": aadhaar_otp,
#                 "ref_id": ref_id
#             }
#             otp_headers = {
#                 "accept": "application/json",
#                 "content-type": "application/json",
#                 "x-client-id": "CF449777CRQG8U0O577S73AHL800",
#                 "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
#             }

#             otp_response = requests.post(otp_url, json=otp_payload, headers=otp_headers)

#             res = otp_response.json()
#             if otp_response.status_code == 200:

#                 response_data = {
#                     'status': 'success',
#                     'message': 'Aadhaar verified successfully',
#                     'data': res
#                 }
#                 # Return a success response with status code 200
#                 return Response(response_data, status=status.HTTP_200_OK)
#             else:
#                 return Response(res, otp_response.status_code)
#         else:
#             customer_contact_no = request.data.get('customer_contact_no')
#             verify_code = request.data.get('contact_otp')

#             try:
#                 cu_obj = Customer.objects.get(
#                     customer_contact_no=customer_contact_no)

#                 if cu_obj.verify_code == verify_code and cu_obj.verify_code_expire_at > timezone.now():
#                     response_data = {
#                         'status': 'success',
#                         'message': 'Code verified successfully.'
#                     }
#                     return Response(response_data, status=status.HTTP_200_OK)
#                 else:
#                     response_data = {
#                         'status': 'error',
#                         'message': 'Invalid or expired verification code.'
#                     }
#                     return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
#             except Customer.DoesNotExist:
#                 response_data = {
#                     'status': 'error',
#                     'message': 'Customer with this contact number does not exist.'
#                 }
#                 return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
#             except Exception as e:
#                 response_data = {
#                     'status': 'error',
#                     'message': 'Internal server error occurred.',
#                     # Optional: include the error details for debugging
#                     'details': str(e)
#                 }
#                 return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def verify_aadhaar(self, request):
#         aadhaar_card = request.data.get('customer_aadhaar_no')

#         aadhaar_url = "https://api.cashfree.com/verification/offline-aadhaar/otp"

#         aadhaar_payload = {"aadhaar_number": aadhaar_card}
#         aadhaar_headers = {
#             "accept": "application/json",
#             "content-type": "application/json",
#             "x-client-id": "CF449777CRQG8U0O577S73AHL800",
#             "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
#         }

#         aadhaar_response = requests.post(aadhaar_url, json=aadhaar_payload, headers=aadhaar_headers)

#         res = aadhaar_response.json()
#         if aadhaar_response.status_code == 200:

#             response_data = {
#                 'status': 'success',
#                 'message': 'OTP sent successfully',
#                 'data': {'aadhaar_otp': 267987, 'ref_id': res['ref_id']}
#             }
#             # Return a success response with status code 200
#             return Response(response_data, status=status.HTTP_200_OK)
#         else:
#             return Response(res, aadhaar_response.status_code)

#     def create_order(self, request):
#         try:
#             customer_contact_no = request.data.get('customer_contact_no')
#             customer_name = request.data.get('customer_name')
#             customer_email = request.data.get('customer_email')
#             order_amount = request.data.get('order_amount')

#             data = {
#                     'name': customer_name,
#                     'email': customer_email,
#                     'contact_no': customer_contact_no,
#                     'amount': order_amount,
#                 }

#             response = create_razorpay_pg_order(request, data)

#             return Response(response)

#         except Exception as e:
#             return Response({'status': 'error', 'message': 'Internal server error.', 'data': str(e)},
#                             status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def verify_payment(self, request):
#         user = request.user
#         razorpay_order_id = request.data.get('razorpay_order_id')
#         razorpay_payment_id = request.data.get('razorpay_payment_id')
#         razorpay_signature = request.data.get('razorpay_signature')
#         method = request.method

#         api_key = "rzp_test_rEAW6ojdmqFEbn"
#         secret_key = "mPPJMnQtFd0o5Q1hKTXTgZSe"

#         try:
#             with transaction.atomic():
#                 if method == "POST":

#                     if 'razorpay_order_id' not in request.data or 'razorpay_payment_id' not in request.data or 'razorpay_signature' not in request.data:
#                         return Response(
#                                 {'status': 'fail', 'message': 'razorpay_order_id, razorpay_payment_id and razorpay_signature are required'},
#                                 status=status.HTTP_400_BAD_REQUEST
#                             )

#                     params_dict={
#                         'razorpay_order_id': razorpay_order_id,
#                         'razorpay_payment_id' : razorpay_payment_id,
#                         'razorpay_signature': razorpay_signature
#                     }

#                     message = f"{razorpay_order_id}|{razorpay_payment_id}"
#                     generated_signature = hmac.new(secret_key.encode("utf-8"), message.encode("utf-8"), hashlib.sha256).hexdigest()
                    
#                     if generated_signature != razorpay_signature:
#                         return JsonResponse({'status': 'Invalid Signature'}, 
#                                             status=status.HTTP_400_BAD_REQUEST)

#                     # Fetch the order amount from Razorpay API
#                     order_details = self.fetch_order_details(razorpay_order_id, api_key, secret_key)
#                     order_amount = order_details['amount'] / 100  # Convert from paise to INR
                    
#                     # Distribute commission among parents and update wallet
#                     # remaining_amount = self.distribute_commission(user, order_amount)

#                     # Update the current user's cash-in wallet with the remaining amount
#                     user_wallet = PortalUserWallet.objects.get(pu=user)
#                     user_wallet.pg_wallet = float((user_wallet.pg_wallet or 0.00)) + float(order_amount)
#                     user_wallet.save()

#                     PyGTransaction.objects.create(created_by=user, voucher_id=user_wallet.puw_id,
#                                                       voucher_type='Payment Gateway',
#                                                       pg_transfer_id=order_details['id'],
#                                                       pg_trn_amount=order_amount, pg_trn_mode='UPI',
#                                                       pg_trn_status=order_details['status'])

#                     return Response({'status': 'Payment Verified Successfully', 
#                                         'main_wallet': user_wallet.main_wallet})
#                 else:
#                     return Response({'status': 'fail', 'message': 'Payment is failed'}, status=status.HTTP_404_NOT_FOUND)

#         except Exception as e:
#             return Response(
#                     {'status': 'error', 'message': str(e)},
#                     status=status.HTTP_500_INTERNAL_SERVER_ERROR
#                 )
        
#     def fetch_order_details(self, order_id, api_key, secret_key):
#         """Fetch Razorpay order details using Razorpay API."""
#         url = f"https://api.razorpay.com/v1/orders/{order_id}"
#         response = requests.get(url, auth=(api_key, secret_key))
#         response_data = response.json()

#         if response.status_code != 200:
#             raise Exception("Failed to fetch order details from Razorpay")
        
#         return response_data

#     # def distribute_commission(self):
#     #     order_amount = 100.00
#     #     user = PortalUser.object.get(id=9)
#     #     """Distribute commission to parents based on PortalUserCharges and return remaining amount."""
#     #     try:
#     #         # Fetch user's charges from PortalUserCharges
#     #         user_charges = PortalUserCharges.objects.filter(pu_id=user.id)

#     #         total_commission = Decimal(0)

#     #         # Iterate through each charge to find relevant distributor hierarchies
#     #         for charge in user_charges:
#     #             charges_data = charge.puc_charges  # JSON with commission percentage

#     #             # Distribute commissions to parents
#     #             for parent in parents:
#     #                 commission_percent = Decimal(commission_data.get('mark_value', 0))
#     #                 commission_amount = (order_amount * commission_percent) / 100

#     #                 # Get or create the parent's wallet and update the commission wallet
#     #                 parent_wallet = PortalUserWallet.objects.get(pu=parent)
#     #                 parent_wallet.commission_wallet += commission_amount
#     #                 parent_wallet.save()

#     #                 total_commission += commission_amount

#     #         # Calculate the remaining amount for the current user
#     #         remaining_amount = order_amount - total_commission
#     #         return remaining_amount

#     #     except Exception as e:
#     #         raise Exception(f"Error distributing commissions: {str(e)}")
#     def get(self, request):
#         return self.after_tx_cal(request)
    
#     def after_tx_cal(self, request):
#         order_amount = 100.00
#         user = PortalUser.objects.get(id=9)
#         """Distribute commission to parents based on PortalUserCharges and return remaining amount."""
#         try:
#             # Fetch user's charges from PortalUserCharges
#             user_charges = PortalUserCharges.objects.filter(pu_id=user.id).first()

#             parent_hierarchy_id = PortalUserCharges.objects.filter(pu_id=user_charges.parent_id).first().dh_id

#             cursor1 = connections['tcpl_admin_db'].cursor()

#             descendant_query = f'''WITH RECURSIVE "Descendants" AS (
#                 SELECT "pu_id", "parent_id", "puc_charges", "mark_type", "sp_id", "dh_id"
#                 FROM "ad_portal_user_charges"
#                 WHERE "pu_id" = 9 AND "sp_id" = 2
#                 UNION ALL
#                 SELECT n."pu_id", n."parent_id", n."puc_charges", n."mark_type", n."sp_id", n."dh_id"
#                 FROM "ad_portal_user_charges" n
#                 JOIN "Descendants" d ON n."pu_id" = d."parent_id" AND n."sp_id" = d."sp_id"
#                 )
#                 SELECT * FROM "Descendants";'''
            
#             cursor1.execute(descendant_query)
            
#             result = cursor1.fetchall()

#             cursor1.close()
#             for res in result:
#                 print(res)
#             # hsn_rate = AdHSNSAC.objects.get(hsnsac_id=user_charges.sp.hsn_sac_id).tax_rate

#             # total_commission = 0.00

#             # # Iterate through each charge to find relevant distributor hierarchies
#             # charges_data = user_charges.puc_charges  # JSON with commission percentage

#             # charges_percent = charges_data.get('rate', 0)
#             # charges_amount = (order_amount * charges_percent) / 100

#             # percent_amount, base_amount = self.bifurcate_amount(hsn_rate, charges_amount)

#             # # Calculate the remaining amount for the current user
#             # effective_amount = order_amount - charges_amount
#             return 0

#         except Exception as e:
#             raise Exception(f"Error distributing commissions: {str(e)}")

#     def bifurcate_amount(self, percent_rate, total_amount):
#         percent_amount = round(total_amount * (percent_rate/(100+percent_rate)))
        
#         base_amount = total_amuont - percent_amount

#         return percent_amount, base_amount


class HsnSacAPIView(APIView):
    """
    """
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAdmin]
    parser_classes = (MultiPartParser, FormParser)

    @swagger_auto_schema(
        tags=['Admin HSN/SAC'],
        manual_parameters=[
            openapi.Parameter('hsnsac_code', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('tax_rate', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('description', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('page_number', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('page_size', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('search', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('hsnsac_id', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
        ]
    )
    def post(self, request):
        if 'page_number' in request.data and 'page_size' in request.data:
            return self.fetch_hsnsac(request)
        elif 'hsnsac_code' in request.data and 'tax_rate' in request.data:
            return self.create_hsnsac(request)
        else:
            return Response({'status': 'error', 'message': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)

    def fetch_hsnsac(self, request):
        hsnsac_id = request.data.get('hsnsac_id')
        search_txt = request.data.get('search')
        page_number = int(request.data.get('page_numbr', 1))
        page_size = int(request.data.get('page_size', 10))

        try:

            queryset = AdHSNSAC.objects.filter(is_deleted=False).order_by('-pk')

            if hsnsac_id:
                queryset = queryset.filter(pk=hsnsac_id)
            if search_txt:
                queryset = queryset.filter(
                    Q(hsnsac_code__icontains=search_txt) |
                    Q(tax_rate__icontains=search_txt)
                )

            queryset = queryset.order_by('-pk')

            paginator = Paginator(queryset, page_size)
            try:
                page_obj = paginator.page(page_number)
            except EmptyPage:
                return Response({
                    'status': 'fail',
                    'message': 'Page not found.',
                    'data': {}
                }, status=status.HTTP_404_NOT_FOUND)

            if page_obj is not None:
                if not queryset.exists():
                    paginated_response_data = {
                        'total_pages': 0,
                        'current_page': 0,
                        'total_items': 0,
                        'results': []
                    }
                    response_data = {
                        'status': 'fail',
                        'message': 'HSNSAC Data not found.',
                        'data': paginated_response_data
                    }
                    return Response(response_data, status=status.HTTP_200_OK)
                serializer = HSNSACSerializer(page_obj.object_list, many=True, context={'request': request,
                                                                                        'exclude_fields': ["created_at",
                                                                                                           "updated_at",
                                                                                                           "is_deleted"]})
                paginated_response_data = {
                    'total_pages': paginator.num_pages,
                    'current_page': page_obj.number,
                    'total_items': paginator.count,
                    'results': serializer.data
                }
                return Response({
                    'status': 'success',
                    'message': 'HSNSAC Data',
                    'data': paginated_response_data
                }, status=status.HTTP_200_OK)

            serializer = HSNSACSerializer(queryset, many=True, context={'request': request,
                                                                        'exclude_fields': ["created_at", "updated_at",
                                                                                           "is_deleted"]})
            response_data = {
                'status': 'success',
                'message': 'HSNSAC Data',
                'data': serializer.data
            }
            return Response(response_data, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'status': 'fail',
                'message': str(e),
                'data': {}
            }, status=status.HTTP_400_BAD_REQUEST)

    def create_hsnsac(self, request):
        request_data = request.data.copy()
        hsnsac_code = request.data.get('hsnsac_code')
        tax_rate = request.data.get('tax_rate')
        description = request.data.get('description')

        if 'hsnsac_code' not in request_data and 'tax_rate' not in request_data:
            return Response({"status": "fail", "message": "HSNSAC Code and Tax Rate is required"},
                            status=status.HTTP_400_BAD_REQUEST)

        try:
            hsnsac_queryset = AdHSNSAC.objects.get(hsnsac_code=hsnsac_code)

            response_data = {
                "status": "success",
                "message": "HSNSAC Code already exists"
            }

            if hsnsac_queryset.tax_rate == float(tax_rate):
                response_data['message'] = "Same HSNSAC code and tax rate already exists."

            return Response(response_data, status=status.HTTP_200_OK)

        except AdHSNSAC.DoesNotExist:
            hsnsac_query = AdHSNSAC.objects.create(
                hsnsac_code=hsnsac_code,
                tax_rate=float(tax_rate),
                description=description if description else None,
                created_at=timezone.now(),
                created_by=request.user
            )

            response_data = {
                'status': 'success',
                'message': 'HSNSAC Entry Created Successfully'
            }
            # Return a success response with status code 201 (Created)
            return Response(response_data, status=status.HTTP_201_CREATED)

        except Exception as e:
            # Handle any exceptions and return an error response
            response_data = {
                'status': 'error',
                'message': f'{str(e)}'
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @swagger_auto_schema(
        tags=['Admin HSN/SAC'],
        manual_parameters=[
            openapi.Parameter('hsnsac_id', openapi.IN_FORM, description="ID of the HSNSAC entry to update",
                              type=openapi.TYPE_STRING, required=True),
            openapi.Parameter('hsnsac_code', openapi.IN_FORM, type=openapi.TYPE_STRING,
                              description='Code of the HSNSAC entry', required=False),
            openapi.Parameter('tax_rate', openapi.IN_FORM, type=openapi.TYPE_STRING,
                              description='Tax rate associated with the HSNSAC entry', required=False),
            openapi.Parameter('description', openapi.IN_FORM, type=openapi.TYPE_STRING,
                              description='Description of the HSNSAC entry', required=False),
            openapi.Parameter('is_deactive', openapi.IN_FORM, type=openapi.TYPE_BOOLEAN,
                              description='Deactivate/activate the HSNSAC entry', required=False),
        ]
    )
    def put(self, request):
        hsnsac_id = request.data.get('hsnsac_id')
        hsnsac_code = request.data.get('hsnsac_code')
        tax_rate = request.data.get('tax_rate')
        description = request.data.get('description')

        if not hsnsac_id:
            return Response({
                "status": "fail",
                "message": "hsnsac_id is required"
            }, status=status.HTTP_400_BAD_REQUEST)

        try:
            hsnsac_queryset = AdHSNSAC.objects.get(hsnsac_id=hsnsac_id)

            if 'is_deactive' in request.data:
                is_deactive = request.data.get('is_deactive')
                is_deactive = True if is_deactive == "true" else False
                hsnsac_queryset.is_deactive = is_deactive
                hsnsac_queryset.updated_at = timezone.now()
                hsnsac_queryset.save()

                if is_deactive:
                    message = 'HSNSAC Entry Deactivated Successfully'
                else:
                    message = 'HSNSAC Entry Activated Successfully'

                # Return a success response with the appropriate message
                response_data = {
                    "status": "success",
                    "message": message
                }
                return Response(response_data, status=status.HTTP_200_OK)

            else:
                query_set = AdHSNSAC.objects.filter(hsnsac_code=hsnsac_code).exclude(hsnsac_id=hsnsac_id)
                if query_set:
                    return Response({
                        "status": "fail",
                        "message": "HSNSAC code already exists."
                    }, status=status.HTTP_400_BAD_REQUEST)

                if hsnsac_code:
                    hsnsac_queryset.hsnsac_code = hsnsac_code

                if tax_rate:
                    hsnsac_queryset.tax_rate = float(tax_rate)

                if description:
                    hsnsac_queryset.description = description

                hsnsac_queryset.updated_at = timezone.now()
                hsnsac_queryset.save()

                # Return a success response with the appropriate message
                response_data = {
                    "status": "success",
                    "message": "HSNSAC Entry Updated Successfully"
                }
                return Response(response_data, status=status.HTTP_200_OK)

        except AdHSNSAC.DoesNotExist:
            response_data = {
                'status': 'fail',
                'message': "HSNSAC entry not found."
            }
            return Response(response_data, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            response_data = {
                "status": "fail",
                "message": f"{str(e)}"
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def delete(self, request):
        hsnsac_id = request.data.get("hsnsac_id")

        # Check if hsnsac_id is provided
        if not hsnsac_id:
            response_data = {
                'status': 'fail',
                'message': "hsnsac_id is required."
            }
            return Response(response_data, status=status.HTTP_400_BAD_REQUEST)

        try:
            with transaction.atomic():
                hsnsac = AdHSNSAC.objects.get(hsnsac_id=hsnsac_id, is_deleted=False)
                hsnsac.is_deleted = True
                hsnsac.save()

                response_data = {
                    'status': 'success',
                    'message': 'HSNSAC Deleted Successfully'
                }

                return Response(response_data, status=status.HTTP_200_OK)
        except AdHSNSAC.DoesNotExist:
            # Handle case where HSNSAC is not found
            response_data = {
                'status': 'fail',
                'message': "HSNSAC not found."
            }
            return Response(response_data, status=status.HTTP_404_NOT_FOUND)

        except ProtectedError as e:
            protected_objects = list(e.protected_objects)
            protected_object_names = [str(obj) for obj in protected_objects]
            print(protected_object_names)
            return Response(
                {'status': 'fail', 'message': 'Cannot delete the record because it is referenced in other tables'},
                status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            # Handle any exceptions and return an error response
            response_data = {
                'status': 'error',
                'message': f'{str(e)}'
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ServiceAPIView(APIView):
    """
    """
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAdmin]
    parser_classes = (MultiPartParser, FormParser)

    @swagger_auto_schema(
        tags=['Admin Service'],
        manual_parameters=[
            openapi.Parameter('page_number', openapi.IN_FORM, type=openapi.TYPE_INTEGER,
                              description='Page number for pagination', required=False),
            openapi.Parameter('page_size', openapi.IN_FORM, type=openapi.TYPE_INTEGER,
                              description='Number of items per page', required=False),
            openapi.Parameter('search', openapi.IN_FORM, type=openapi.TYPE_STRING,
                              description='Search query for filtering HSNSAC entries', required=False),
            openapi.Parameter('service_id', openapi.IN_FORM, type=openapi.TYPE_STRING,
                              description='ID of the HSNSAC entry to retrieve', required=False),
        ]
    )
    def post(self, request):
        service_id = request.data.get('service_id')
        search_txt = request.data.get('search')
        page_number = int(request.data.get('page_numbr', 1))
        page_size = int(request.data.get('page_size', 10))

        try:
            queryset = AdService.objects.filter(is_deleted=False).order_by('-pk')

            if service_id:
                queryset = queryset.filter(pk=service_id)
            if search_txt:
                queryset = queryset.filter(
                    Q(service_name__icontains=search_txt) |
                    Q(description__icontains=search_txt)
                )

            queryset = queryset.order_by('-pk')

            paginator = Paginator(queryset, page_size)
            try:
                page_obj = paginator.page(page_number)
            except EmptyPage:
                return Response({
                    'status': 'fail',
                    'message': 'Page not found.',
                    'data': {}
                }, status=status.HTTP_404_NOT_FOUND)

            if page_obj is not None:
                if not queryset.exists():
                    paginated_response_data = {
                        'total_pages': 0,
                        'current_page': 0,
                        'total_items': 0,
                        'results': []
                    }
                    response_data = {
                        'status': 'fail',
                        'message': 'HSNSAC Data not found.',
                        'data': paginated_response_data
                    }
                    return Response(response_data, status=status.HTTP_200_OK)
                serializer = ServiceSerializer(page_obj.object_list, many=True, context={'request': request,
                                                                                         'exclude_fields': [
                                                                                             "created_at", "updated_at",
                                                                                             "is_deleted"]})
                paginated_response_data = {
                    'total_pages': paginator.num_pages,
                    'current_page': page_obj.number,
                    'total_items': paginator.count,
                    'results': serializer.data
                }
                return Response({
                    'status': 'success',
                    'message': 'Service Data',
                    'data': paginated_response_data
                }, status=status.HTTP_200_OK)

            serializer = ServiceSerializer(queryset, many=True, context={'request': request,
                                                                         'exclude_fields': ["created_at", "updated_at",
                                                                                            "is_deleted"]})
            response_data = {
                'status': 'success',
                'message': 'Service Data',
                'data': serializer.data
            }
            return Response(response_data, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'status': 'fail',
                'message': str(e),
                'data': {}
            }, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request):
        try:
            with transaction.atomic():
                savepoint = transaction.savepoint()
                service_id = request.data.get('service_id')

                if not service_id:
                    return Response({
                        'status': 'fail',
                        'message': 'Service ID is required'
                    }, status=status.HTTP_400_BAD_REQUEST)

                service_instance = AdService.objects.get(service_id=service_id, is_deleted=False)
                service_provider_instance = AdServiceProvider.objects.filter(service=service_instance)

                if service_instance.is_deleted:
                    return Response({
                        'status': 'fail',
                        'message': f'Service with ID {service_id} not found'
                    }, status=status.HTTP_404_NOT_FOUND)

                if service_id:
                    if service_instance.is_deactive == True:
                        service_instance.is_deactive = False
                        service_instance.updated_at = datetime.now()

                        for sp_instance in service_provider_instance:
                            sp_instance.is_deactive = False
                            commission_charges = AdCommissionCharges.objects.filter(service_provider=sp_instance.pk, is_deleted=False)
                            for charges in commission_charges:
                                charges.is_deactive = False
                                charges.save()
                            hierarchy_charges = HierarchyCharges.objects.filter(sp=sp_instance.pk, is_deleted=False)
                            for charges in hierarchy_charges:
                                charges.is_deactive = False
                                charges.save()
                            service_transaction_charges = PortalUserCharges.objects.filter(sp=sp_instance.pk)
                            for charges in service_transaction_charges:
                                charges.is_deactive = False
                                charges.save()
                            sp_instance.save()

                        service_instance.save()
                        message = "Service activate succussfully"
                        transaction.savepoint_commit(savepoint)
                    else:
                        service_instance.is_deactive = True
                        service_instance.updated_at = datetime.now()

                        for sp_instance in service_provider_instance:
                            sp_instance.is_deactive = True
                            commission_charges = AdCommissionCharges.objects.filter(service_provider=sp_instance.pk, is_deleted=False)
                            for charges in commission_charges:
                                charges.is_deactive = True
                                charges.save()
                            hierarchy_charges = HierarchyCharges.objects.filter(sp=sp_instance.pk, is_deleted=False)
                            for charges in hierarchy_charges:
                                charges.is_deactive = True
                                charges.save()
                            service_transaction_charges = PortalUserCharges.objects.filter(sp=sp_instance.pk)
                            for charges in service_transaction_charges:
                                charges.is_deactive = True
                                charges.save()
                            sp_instance.save()

                        service_instance.save()
                        message = "Service deactivate succussfully"
                        transaction.savepoint_commit(savepoint)

                    return Response({
                        'status': 'success',
                        'message': message,
                    }, status=status.HTTP_200_OK)

                return Response({
                    'status': 'fail',
                    'message': 'Failed to update service',
                }, status=status.HTTP_400_BAD_REQUEST)

        except AdService.DoesNotExist:
            return Response({
                'status': 'fail',
                'message': f'Service with ID {service_id} does not exist'
            }, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({
                'status': 'error',
                'message': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class ServiceProviderAPIView(APIView):
    """
    """
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAdmin]
    parser_classes = (MultiPartParser, FormParser)

    @swagger_auto_schema(
        tags = ['Admin Service Provider'],
        manual_parameters=[
            openapi.Parameter('page_number', openapi.IN_FORM, type=openapi.TYPE_INTEGER, description='Page number for pagination', required=False),
            openapi.Parameter('page_size', openapi.IN_FORM, type=openapi.TYPE_INTEGER, description='Number of items per page', required=False),
            openapi.Parameter('search', openapi.IN_FORM, type=openapi.TYPE_STRING, description='Search query for filtering HSNSAC entries', required=False),
            openapi.Parameter('sp_id', openapi.IN_FORM, type=openapi.TYPE_STRING, description='ID of the HSNSAC entry to retrieve', required=False),
            openapi.Parameter('service_id', openapi.IN_FORM, type=openapi.TYPE_STRING, description='ID of the HSNSAC entry to retrieve', required=False),
            openapi.Parameter('hsn_sac_id', openapi.IN_FORM, type=openapi.TYPE_STRING, description='ID of the HSNSAC entry to retrieve', required=False),
        ]
    )
    def post(self, request):
        try:
            if 'page_number' in request.data and 'page_size' in request.data:
                return self.fetch_service_provider(request)
            else:
                return Response({'status': 'error','message': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': str(e)
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def fetch_service_provider(self, request):
        sp_id = request.data.get('sp_id')
        service_id = request.data.get('service_id')
        hsn_sac_id = request.data.get('hsn_sac_id')
        search_txt = request.data.get('search')
        page_number = request.data.get('page_number', 1)
        page_size = request.data.get('page_size')

        try:
            if not page_size: return Response({'status': 'fail','message': 'page_size is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if isnumber(page_size) == False: return Response({'status': 'fail','message': 'page_size must contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)

            if page_number:
                if isnumber(page_number) == False: return Response({'status': 'fail','message': 'page_number must contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)

            if sp_id:
                if isnumber(sp_id) == False: return Response({'status': 'fail','message': 'sp_id must contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)

            if service_id:
                if isnumber(service_id) == False: return Response({'status': 'fail','message': 'service_id must contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)

            if hsn_sac_id:
                if isnumber(hsn_sac_id) == False: return Response({'status': 'fail','message': 'hsn_sac_id must contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)

            queryset = AdServiceProvider.objects.filter(is_deleted=False)

            if sp_id:
                queryset = queryset.filter(pk=sp_id)
            if service_id:
                queryset = queryset.filter(service_id=service_id)
            if hsn_sac_id:
                queryset = queryset.filter(hsn_sac_id=hsn_sac_id)
            if search_txt:
                queryset = queryset.filter(
                    Q(service__service_name__icontains=search_txt) |
                    Q(sp_name__icontains=search_txt) |
                    Q(label__icontains=search_txt) |
                    Q(hsn_sac__hsnsac_code__icontains=search_txt)
                )

            queryset = queryset.order_by('-pk')

            paginator = Paginator(queryset, page_size)
            try:
                page_obj = paginator.page(page_number)
            except EmptyPage:
                return Response({
                    'status': 'fail',
                    'message': 'Page not found.',
                    'data': {}
                }, status=status.HTTP_404_NOT_FOUND)

            # If no data found, return an empty result with pagination metadata
            if not queryset.exists():
                return Response({
                    'status': 'fail',
                    'message': 'Service Provider Data not found.',
                    'data': {
                        'total_pages': 0,
                        'current_page': 0,
                        'total_items': 0,
                        'results': []
                    }
                }, status=status.HTTP_200_OK)
            
            # For each service provider, fetch related charges
            service_provider_data = []
            for provider in page_obj:
                # Fetch related charges (assuming 'to_provide' charges category)
                to_us_charges = AdCharges.objects.filter(service_provider=provider, charge_category='to_us')
                if len(to_us_charges) > 0:
                    charge_serializer = ChargeSerializer(to_us_charges, many=True, context={'request': request})

                    # Assuming all charges under the service provider have the same charge_type
                    charge_type = to_us_charges.first().charges_type if to_us_charges.exists() else None
                    charge_serializer_update = charge_serializer.data
                    for charge in charge_serializer_update:
                        charge.pop("created_at")
                        charge.pop("updated_at")
                        charge.pop("is_deactive")
                        charge.pop("is_deleted")
                        charge.pop("created_by")

                        if charge.get("minimum") == "0.00" and charge.get("maximum") == "0.00":
                            charge.update({"is_slab": False})
                        else:
                            charge.update({"is_slab": True})

                    # Assuming all charges under the service provider have the same charge_type
                    # charge_type = to_us_charges.first().charges_type if to_us_charges.exists() else None

                else:
                    charge_serializer_update = []
                    charge_type = None
                
                ad_commission_queryset = AdCommissionCharges.objects.filter(service_provider=provider, is_deleted=False)
                if len(ad_commission_queryset) > 0:
                    global_commission_list = []

                    for commission_value in ad_commission_queryset:
                        global_commission_list.append({
                            "commission_charges_id": commission_value.commission_charges_id,
                            "service_provider": commission_value.service_provider.pk,
                            "rate_type": commission_value.rate_type,
                            "minimum": commission_value.minimum,
                            "maximum": commission_value.maximum,
                        })
                else:
                    global_commission_list = []
                
                service_name = AdService.objects.get(service_id=provider.service_id).service_name
                # Append the service provider data along with charges and charge_type
                service_provider_data.append({
                    'sp_id': provider.sp_id,
                    'service_name': service_name,
                    'provider_name': provider.sp_name,
                    'provider_label': provider.label,
                    'tds_rate': provider.tds_rate,
                    'hsn_sac': provider.hsn_sac.hsnsac_id if provider.hsn_sac else None,
                    'hsn_sac_code': provider.hsn_sac.hsnsac_code if provider.hsn_sac else None,
                    'tax_rate': provider.hsn_sac.tax_rate if provider.hsn_sac else None,
                    'charge_type': charge_type,  # Include charge_type as a separate value
                    'is_deactive': provider.is_deactive,
                    'to_provide_charges': charge_serializer_update,
                    'global_commission': global_commission_list
                })

            # Response data with pagination metadata
            paginated_response_data = {
                'total_pages': paginator.num_pages,
                'current_page': page_obj.number,
                'total_items': paginator.count,
                'results': service_provider_data
            }

            return Response({
                'status': 'success',
                'message': 'Service Provider Data with Charges',
                'data': paginated_response_data
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'status': 'fail',
                'message': str(e),
                'data': {}
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def add_commission_structure(self, request):
        sp_id = request.data.get('sp_id')
        global_commission = request.data.get('global_commission')
        commission_value = request.data.get('commissions')
        try:
            try:
                global_commission_list = json.loads(global_commission)
            except json.JSONDecodeError:
                raise ValidationError("Invalid JSON format for global commission")

            try:
                commission_list = json.loads(commission_value)
            except json.JSONDecodeError:
                raise ValidationError("Invalid JSON format for commission value")

            try:
                service_provider = AdServiceProvider.objects.get(sp_id=sp_id, is_deleted=False)
            except AdServiceProvider.DoesNotExist:
                return Response({
                    'status': 'fail',
                    'message': 'Service Provider not found'
                }, status=status.HTTP_404_NOT_FOUND)
            
            queryset = AdCommissionCharges.objects.filter(service_provider=sp_id, is_deleted=False)
            
            if queryset:
                return Response({'status': 'success', 'message': 'service provider commission already addedd.'}, status=status.HTTP_200_OK)
            else:

                for commission_data in global_commission_list:
                    commission_charge_object = AdCommissionCharges.objects.create(
                        service_provider=service_provider,
                        charges_type=commission_data.get("charges_type"),
                        rate_type=commission_data.get("rate_type"),
                        minimum=commission_data.get("minimum"),
                        maximum=commission_data.get("maximum"),
                        rate=commission_data.get("rate"),
                        created_at=timezone.now(),
                        created_by=request.user
                    )

                for value in commission_list:
                    try:
                        if value['dh_id'] != 0:
                            dh = DistributorHierarchy.objects.get(dh_id=value['dh_id'], is_deleted=False)
                        else:
                            dh=None
                    except Exception as e:
                        return Response({'status': 'fail', 'message': 'dh ID is not exists.'}, status=status.HTTP_404_NOT_FOUND)

                    HierarchyCharges.objects.create(
                        # mark_type=value['charges_type'],
                        hc_charges=value['commission'],
                        dh=dh,
                        sp=service_provider,
                        created_at=timezone.now(),
                        created_by=request.user
                    )

                return Response({'status': 'success', 'message': 'service provider commission added successfully.'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    charges_parameter = openapi.Parameter(
    'charges',
    openapi.IN_FORM,
    description="List of charges (JSON string)",
    type=openapi.TYPE_STRING,
    required=False
    )
    @swagger_auto_schema(
        tags = ['Admin Service Provider'],
        manual_parameters=[
            charges_parameter,
            openapi.Parameter('sp_id', openapi.IN_FORM, type=openapi.TYPE_STRING, required=True, description='ID of the service provider'),
            openapi.Parameter('label', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False, description='Updated fees for the service provider'),
            openapi.Parameter('hsn_sac', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False, description='Updated HSN/SAC code for the service provider'),
            openapi.Parameter('charges_type', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False, description='Updated charges type for the service provider'),
            openapi.Parameter('tds_rate', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False, description='Updated TDS rate for the service provider'),
            openapi.Parameter('is_deactive', openapi.IN_FORM, type=openapi.TYPE_BOOLEAN, required=False, description='Set service provider as inactive (True) or active (False)'),
        ],
        security=[{'Bearer': []}]
    )
    def put(self, request):
        try:
            with transaction.atomic():
                savepoint_1 = transaction.savepoint()
                sp_id = request.data.get('sp_id')
                charges_type = request.data.get('charges_type', None)
                tds_rate = request.data.get('tds_rate', None)
                message = 'Service Provider updated successfully'

                if not sp_id: return Response({'status': 'fail', 'message': 'Service Provider ID is required'}, status=status.HTTP_400_BAD_REQUEST)
                if isnumber(sp_id) == False: return Response({'status': 'fail','message': 'sp_id must contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)
                
                try:
                    service_provider = AdServiceProvider.objects.get(sp_id=sp_id, is_deleted=False)
                except AdServiceProvider.DoesNotExist:
                    return Response({'status': 'fail', 'message': 'Service Provider not found'}, status=status.HTTP_404_NOT_FOUND)

                if sp_id and not charges_type and not tds_rate:

                    commission_structure_queryset = AdCommissionCharges.objects.filter(service_provider=service_provider)
                    if not commission_structure_queryset:
                        return Response({'status': 'fail', 'message': 'The service provider commission structure must be set up to activate this service.'}, status=status.HTTP_400_BAD_REQUEST)

                    if service_provider.is_deactive == True:
                        service_provider.is_deactive = False
                        try:
                            # Activating service and commission charges
                            service = AdService.objects.get(service_id=service_provider.service.service_id)
                            service.is_deactive = False
                            service.save()

                            commission_charges = AdCommissionCharges.objects.filter(service_provider=service_provider, is_deleted=False)
                            for charges in commission_charges:
                                charges.is_deactive = False
                                charges.save()

                            hierarchy_charges = HierarchyCharges.objects.filter(sp=service_provider, is_deleted=False)
                            for charges in hierarchy_charges:
                                charges.is_deactive = False
                                charges.save()

                            service_transaction_charges = PortalUserCharges.objects.filter(sp=service_provider)

                            # Adding PortalUserCharges if not exist
                            if not service_transaction_charges:
                                all_portal_users = PortalUser.objects.filter(pu_role__in=["DISTRIBUTOR", "RETAILER"])
                                for pt_user in all_portal_users:
                                    portal_user_id = pt_user.id

                                    dh_value = PortalUserCharges.objects.filter(pu_id=portal_user_id).select_related('dh', 'sp').first()
                                    dh_id = dh_value.dh.dh_id if dh_value.dh else None

                                    hierarchy_charges = HierarchyCharges.objects.get(dh=dh_id, sp=service_provider.sp_id, is_deleted=False)
                                    PortalUserCharges.objects.create(
                                        sp=hierarchy_charges.sp,
                                        dh=hierarchy_charges.dh,
                                        pu_id=pt_user.id,
                                        parent_id=dh_value.parent_id,
                                        mark_type=hierarchy_charges.mark_type,
                                        puc_charges=hierarchy_charges.hc_charges,
                                        is_deactive=False,
                                        created_by=request.user
                                    )
                            else:
                                for charges in service_transaction_charges:
                                    charges.is_deactive = False
                                    charges.save()

                            # Commit the first savepoint
                            transaction.savepoint_commit(savepoint_1)
                            message = 'Service Provider activated Successfully.'
                        
                        except Exception as e:
                            # Rollback to the first savepoint if activation fails
                            transaction.savepoint_rollback(savepoint_1)
                            return Response({
                                'status': 'error',
                                'message': f'Error activating Service Provider: {str(e)}'
                            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

                    else:
                        # Deactivation process with savepoint rollback support
                        service_provider.is_deactive = True
                        try:
                            commission_charges = AdCommissionCharges.objects.filter(service_provider=service_provider, is_deleted=False)
                            for charges in commission_charges:
                                charges.is_deactive = True
                                charges.save()
                            
                            hierarchy_charges = HierarchyCharges.objects.filter(sp=service_provider, is_deleted=False)
                            for charges in hierarchy_charges:
                                charges.is_deactive = True
                                charges.save()
                            
                            service_transaction_charges = PortalUserCharges.objects.filter(sp=service_provider)
                            for charges in service_transaction_charges:
                                charges.is_deactive = False
                                charges.save()

                            # Commit the first savepoint after successful deactivation
                            transaction.savepoint_commit(savepoint_1)
                            message = 'Service Provider Deactivated Successfully.'

                        except Exception as e:
                            # Rollback to the first savepoint if deactivation fails
                            transaction.savepoint_rollback(savepoint_1)
                            return Response({
                                'status': 'error',
                                'message': f'Error deactivating Service Provider: {str(e)}'
                            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

                    service_provider.updated_at = timezone.now()
                    service_provider.save()
                
                else:

                    if not tds_rate: return Response({'status': 'fail', 'message': 'TDS rate is required'}, status=status.HTTP_400_BAD_REQUEST)
                    if isfloat(tds_rate) == False: return Response({'status': 'fail', 'message': 'Invalid value for TDS rate. Please provide a numeric value.'}, status=status.HTTP_400_BAD_REQUEST)

                    tds_rate = float(tds_rate)

                    if tds_rate < 0: return Response({'status': 'fail', 'message': 'TDS rate must be a positive number.'}, status=status.HTTP_400_BAD_REQUEST)
                    if tds_rate > 100: return Response({'status': 'fail', 'message': 'TDS rate must be between 0 and 100.'}, status=status.HTTP_400_BAD_REQUEST)
                    
                    # Second savepoint for TDS update
                    savepoint_2 = transaction.savepoint()
                    try:
                        serializer = ServiceProviderSerializer(service_provider, data=request.data, partial=True, context={'request': request})
                        if serializer.is_valid():
                            service_provider_instance = serializer.save(updated_at=timezone.now(), updated_by=request.user)

                            if 'to_us_charges' in request.data:
                                to_us_charges_str = request.data.get('to_us_charges', '[]')
                                self.process_charges(to_us_charges_str, service_provider_instance, request, 'to_us', charges_type)

                            self.add_commission_structure(request)

                            # Commit the second savepoint after successful TDS rate update
                            transaction.savepoint_commit(savepoint_2)
                        else:
                            transaction.savepoint_rollback(savepoint_2)
                            return Response({
                                'status': 'fail',
                                'message': 'Failed to update Service Provider',
                                'data': serializer.errors
                            }, status=status.HTTP_400_BAD_REQUEST)
                    
                    except Exception as e:
                        transaction.savepoint_rollback(savepoint_2)
                        return Response({
                            'status': 'error',
                            'message': f'Error updating TDS rate: {str(e)}'
                        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


                return Response({
                    'status': 'success',
                    'message': message,
                })

            return Response({
                'status': 'fail',
                'message': 'Failed to update Service Provider',
                'data': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    def process_charges(self, charges_str, service_provider_instance, request, charge_category, charges_type):
        try:
            charges = json.loads(charges_str)
        except json.JSONDecodeError:
            raise ValidationError("Invalid JSON format for charges")

        # fetch charges related service provider and charge category
        charge_filter_object = AdCharges.objects.filter(service_provider=service_provider_instance.pk, charge_category=charge_category, is_deleted=False)

        # check if charges record exist then update the charges otherwise create the charges
        if charge_filter_object:

            # delete the object if charge filter record more then one
            if len(charge_filter_object) > 1:
                for del_record in charge_filter_object[1:]:
                    del_record.delete()

            for charge in charges:
                if charge["minimum"] == "null":
                    charge["minimum"] = None
                if charge["maximum"] == "null":
                    charge["maximum"] = None
                charge["service_provider"] = service_provider_instance.pk
                charge["charge_category"] = charge_category
                charge["charges_type"] = charges_type

            if len(charges) > 1:
                for index, charge in enumerate(charges):
                    if index == 0:
                        charge_record = AdCharges.objects.get(charges_id=charge_filter_object[0].pk)
                        charges_serializer = ChargeSerializer(charge_record, data=charge, partial=True,
                                                               context={'request': request})
                        if charges_serializer.is_valid():
                            charges_instance = charges_serializer.save(updated_at=datetime.now(), updated_by=request.user)
                    else:
                        charges_serializer = ChargeSerializer(data=charge, context={'request': request})
                        if charges_serializer.is_valid():
                            charges_instance = charges_serializer.save()
            else:
                charges_serializer = ChargeSerializer(charge_filter_object[0], data=charges[0], partial=True, context={'request': request})
                if charges_serializer.is_valid():
                    charges_instance = charges_serializer.save(updated_at=datetime.now(), updated_by=request.user)

            # Log the creation activity for each charge
            # activity = UserActivity(
            #     table_id=charges_instance.pk,
            #     table_name='charges',
            #     ua_action='update',
            #     ua_description='Charge updated successfully',
            #     created_by=request.user,
            #     request_data=request.data,
            #     response_data=charges_serializer.data
            # )
            # activity.save()

        else:
            for charge in charges:
                if charge["minimum"] == "null":
                    charge["minimum"] = None
                if charge["maximum"] == "null":
                    charge["maximum"] = None
                charge["service_provider"] = service_provider_instance.pk
                charge["charge_category"] = charge_category
                charge["charges_type"] = charges_type

                charges_serializer = ChargeSerializer(data=charge, context={'request': request})
                if charges_serializer.is_valid():
                    charges_instance = charges_serializer.save()

                    # Log the creation activity for each charge
                    # activity = UserActivity(
                    #     table_id=charges_instance.pk,
                    #     table_name='charges',
                    #     ua_action='create',
                    #     ua_description='Charge created successfully',
                    #     created_by=request.user,
                    #     request_data=request.data,
                    #     response_data=charges_serializer.data
                    # )
                    # activity.save()
                else:
                    raise ValidationError(charges_serializer.errors)


class PartnerAPIView(APIView):
    """
    """
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsDistributor | IsAdmin]
    parser_classes = (MultiPartParser, FormParser)

    @swagger_auto_schema(
        tags=['Distributors'],
        manual_parameters=[
            openapi.Parameter('aadhaar_card', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('ref_id', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('aadhaar_otp', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('pan_card', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('pan_response', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('email', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('email_otp', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('contact_no', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('contact_otp', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('name', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('alternate_contact_no', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('address', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('state', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('city', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('zip_code', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('partner_category', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('profile_image', openapi.IN_FORM, type=openapi.TYPE_FILE, required=False),
            openapi.Parameter('page_number', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('page_size', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('distributor_id', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
        ]
    )
    def post(self, request):
        try:
            if 'aadhaar_card' in request.data and 'pan_card' in request.data and 'name' in request.data and 'email' in request.data and 'contact_no' in request.data:
                return self.add_distributor(request)
            elif 'aadhaar_card' in request.data:
                return self.verify_aadhaar(request)
            elif ('ref_id' in request.data and 'aadhaar_otp' in request.data) or (
                    'email' in request.data and 'email_otp' in request.data) or (
                    'contact_no' in request.data and 'contact_otp' in request.data):
                return self.verify_otp(request)
            elif 'pan_card' in request.data:
                return self.verify_pan(request)
            elif 'email' in request.data:
                return self.verify_email(request)
            elif 'contact_no' in request.data:
                return self.verify_contact(request)
            elif 'page_number' in request.data and 'page_size' in request.data:
                return self.fetch_distributor(request)
            else:
                return Response({'status': 'error', 'message': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': str(e)
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def verify_aadhaar(self, request):
        aadhaar_card = request.data.get('aadhaar_card')

        aadhaar_url = "https://api.cashfree.com/verification/offline-aadhaar/otp"

        aadhaar_payload = {"aadhaar_number": aadhaar_card}
        aadhaar_headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "x-client-id": "CF449777CRQG8U0O577S73AHL800",
            "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
        }

        aadhaar_response = requests.post(aadhaar_url, json=aadhaar_payload, headers=aadhaar_headers)

        res = aadhaar_response.json()
        if aadhaar_response.status_code == 200:

            response_data = {
                'status': 'success',
                'message': 'OTP sent successfully',
                'data': {'aadhaar_otp': 267987, 'ref_id': res['ref_id']}
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            return Response(res, aadhaar_response.status_code)

    def verify_otp(self, request):
        if 'ref_id' in request.data and 'aadhaar_otp' in request.data:
            ref_id = request.data.get('ref_id')
            aadhaar_otp = request.data.get('aadhaar_otp')

            otp_url = "https://api.cashfree.com/verification/offline-aadhaar/verify"

            otp_payload = {
                "otp": aadhaar_otp,
                "ref_id": ref_id
            }
            otp_headers = {
                "accept": "application/json",
                "content-type": "application/json",
                "x-client-id": "CF449777CRQG8U0O577S73AHL800",
                "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
            }

            otp_response = requests.post(otp_url, json=otp_payload, headers=otp_headers)

            res = otp_response.json()
            if otp_response.status_code == 200:

                response_data = {
                    'status': 'success',
                    'message': 'Aadhaar verified successfully',
                    'data': res
                }
                # Return a success response with status code 200
                return Response(response_data, status=status.HTTP_200_OK)
            else:
                return Response(res, otp_response.status_code)
        elif 'email' in request.data and 'email_otp' in request.data:
            email = request.data.get('email')
            email_otp = request.data.get('email_otp')

            try:
                user = UserCodeVerification.objects.get(ucv_data=email)

                if user.verify_code == email_otp and user.verify_code_expire_at > timezone.now():
                    user.verify_code = None
                    user.verify_code_expire_at = None
                    user.is_everify = True
                    user.save()

                    response_data = {
                        'status': 'success',
                        'message': 'Email verification code verified successfully.',
                    }
                    return Response(response_data, status=status.HTTP_200_OK)
                else:
                    response_data = {
                        'status': 'fail',
                        'message': 'Invalid or expired verification code.'
                    }
                    return Response(response_data, status=status.HTTP_400_BAD_REQUEST)

            except UserCodeVerification.DoesNotExist:
                response_data = {
                    'status': 'error',
                    'message': 'User with this email does not exist.'
                }
                return Response(response_data, status=status.HTTP_404_NOT_FOUND)

            except Exception as e:
                response_data = {
                    'status': 'error',
                    'message': str(e),
                }
                # Return a success response with status code 200
                return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            contact_no = request.data.get('contact_no')
            contact_otp = request.data.get('contact_otp')

            try:
                user = UserCodeVerification.objects.get(ucv_data=contact_no)

                if user.verify_code == contact_otp and user.verify_code_expire_at > timezone.now():
                    user.verify_code = None
                    user.verify_code_expire_at = None
                    user.is_everify = True
                    user.save()

                    response_data = {
                        'status': 'success',
                        'message': 'Contact verification code verified successfully.',
                    }
                    return Response(response_data, status=status.HTTP_200_OK)
                else:
                    response_data = {
                        'status': 'fail',
                        'message': 'Invalid or expired verification code.'
                    }
                    return Response(response_data, status=status.HTTP_400_BAD_REQUEST)

            except UserCodeVerification.DoesNotExist:
                response_data = {
                    'status': 'error',
                    'message': 'User with this contact no does not exist.'
                }
                return Response(response_data, status=status.HTTP_404_NOT_FOUND)

            except Exception as e:
                response_data = {
                    'status': 'error',
                    'message': str(e),
                }
                # Return a success response with status code 200
                return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def verify_pan(self, request):
        pan_card = request.data.get('pan_card')

        pan_url = "https://api.cashfree.com/verification/pan/advance"

        pan_payload = {
            "pan": pan_card,
            "verification_id": get_random_string(length=10)
        }
        pan_headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "x-client-id": "CF449777CRQG8U0O577S73AHL800",
            "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
        }

        pan_response = requests.post(pan_url, json=pan_payload, headers=pan_headers)

        res = pan_response.json()
        if pan_response.status_code == 200:

            response_data = {
                'status': 'success',
                'message': 'Pan verified successfully',
                'data': res
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            return Response(res, pan_response.status_code)

    def verify_email(self, request):
        email = request.data.get('email')

        otp = get_random_string(length=6, allowed_chars='0123456789')
        try:
            if not email: return Response({"status": "fail", "message": "Email is required."}, status=status.HTTP_400_BAD_REQUEST)
            if not validation_email_address(email): return Response({"status": "fail", "message": "Invalid email address format."}, status=status.HTTP_400_BAD_REQUEST)

            try:
                pu_obj = UserCodeVerification.objects.get(ucv_data=email)
                pu_obj.verify_code = otp
                pu_obj.verify_code_expire_at = timezone.now() + timedelta(minutes=10)
                pu_obj.save()
            except UserCodeVerification.DoesNotExist:
                UserCodeVerification.objects.create(ucv_data=email, verify_code=otp,
                                                    verify_code_expire_at=timezone.now() + timedelta(minutes=10))

            with transaction.atomic():
                # Prepare HTML content for email
                subject = 'Verify Code for Email Verification'

                # HTML content
                html_content = f"""
                    <html>
                    <head>
                        <style>
                            body {{
                                font-family: Arial, sans-serif;
                                background-color: #f4f4f4;
                                padding: 20px;
                            }}
                            .container {{
                                background-color: #ffffff;
                                border-radius: 5px;
                                padding: 20px;
                                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                            }}
                            h2 {{
                                color: #333;
                            }}
                            p {{
                                color: #555;
                            }}
                            .footer {{
                                margin-top: 20px;
                                font-size: 0.8em;
                                color: #999;
                            }}
                        </style>
                    </head>
                    <body>
                        <div class="container">
                            <h4>Hello Distributor,</h4>
                            <p>We hope this message finds you well!</p>
                            <p>Your OTP for email verification is: <strong>{otp}</strong></p>
                            <p>Please make sure to keep it confidential and do not share it with anyone.</p>
                            <p>If you did not request this, please disregard this email.</p>
                            <p>If you have any questions or need further assistance, feel free to contact our support team.</p>
                            <p>Best regards,<br>TCPL</p>
                        </div>
                        <div class="footer">
                            <p>This email is generated automatically, please do not reply.</p>
                        </div>
                    </body>
                    </html>
                """

                # Create a plain text version by stripping HTML tags (for email clients that don't support HTML)
                text_content = strip_tags(html_content)
                # Create the email object
                email_message = EmailMultiAlternatives(subject, text_content, settings.EMAIL_HOST_USER, [email])
                # Attach the HTML version of the email
                email_message.attach_alternative(html_content, "text/html")
                email_message.send(fail_silently=False)

            response_data = {
                'status': 'success',
                'message': 'Email sent successfully',
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_200_OK)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def verify_contact(self, request):
        contact_no = request.data.get('contact_no')

        otp = get_random_string(length=6, allowed_chars='0123456789')
        try:
            try:
                pu_obj = UserCodeVerification.objects.get(ucv_data=contact_no)
                pu_obj.verify_code = otp
                pu_obj.verify_code_expire_at = timezone.now() + timedelta(minutes=10)
                pu_obj.save()
            except UserCodeVerification.DoesNotExist:
                UserCodeVerification.objects.create(ucv_data=contact_no, verify_code=otp,
                                                    verify_code_expire_at=timezone.now() + timedelta(minutes=10))

            # Prepare the SMS content
            message = f"Your One Time Verification Code for Tapi Cashless login is {otp},Please do not share it with anyone. Thanks Tapi Cashless."

            # Replace the placeholders with actual values
            sms_url = "https://mobicomm.dove-sms.com/submitsms.jsp"
            sms_params = {
                'user': 'TAPICASH',
                'key': '66a1621a84XX',
                'mobile': f"+91{contact_no}",
                'message': message,
                'senderid': 'TAPICL',
                'accusage': '1',
                'entityid': '1701172165114242200',
                'tempid': '1707172206814737429'
            }

            # Send the SMS using a GET request
            response = requests.get(sms_url, params=sms_params)

            # Check the SMS API response status
            if response.status_code == 200:
                response_data = {
                    'status': 'success',
                    'message': 'The provided contact number is registered, and the OTP has been sent via SMS.',
                    'data': {'contact_otp': otp}
                }
                return Response(response_data, status=status.HTTP_200_OK)
            else:
                response_data = {
                    'status': 'error',
                    'message': 'Failed to send the OTP via SMS.',
                    'details': response.text  # Include the response for debugging
                }
                return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': str(e),
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def add_distributor(self, request):
        aadhaar_card = request.data.get('aadhaar_card')
        pan_card = request.data.get('pan_card')
        pan_response = request.data.get('pan_response')
        pu_name = request.data.get('name')
        pu_email = request.data.get('email')
        pu_contact_no = request.data.get('contact_no')
        alternate_contact_no = request.data.get('alternate_contact_no')
        address = request.data.get('address')
        state = request.data.get('state')
        city = request.data.get('city')
        zip_code = request.data.get('zip_code')
        partner_category = request.data.get('partner_category')
        profile_image = request.data.get('profile_image')

        try:
            with transaction.atomic():
                state_obj = State.objects.filter(state_name=state).first()
                state_id = state_obj.state_id
                city_obj = City.objects.filter(city_name=city).first()
                city_id = city_obj.city_id
                
                parsed_data = json.loads(pan_response)
                masked_aadhaar_number = parsed_data.get('masked_aadhaar_number')[-4:]
                if masked_aadhaar_number != aadhaar_card[-4:]:
                    return Response({'status': 'fail', 'message': 'Aadhaar number mismatch. Please verify the Aadhaar details.'}, status=status.HTTP_400_BAD_REQUEST)
                
                if parsed_data.get('aadhaar_linked') == False:
                    return Response({'status': 'fail', 'message': 'Aadhaar is not linked to the provided PAN card.'}, status=status.HTTP_400_BAD_REQUEST)

                # Create PortalUser
                pu_obj = PortalUser.objects.create(
                    pu_name=pu_name,
                    pu_email=pu_email,
                    pu_contact_no=pu_contact_no,
                    pu_role="DISTRIBUTOR"
                )

                # Fetch DistributorHierarchy
                try:
                    distributor_hierarchy = DistributorHierarchy.objects.get(pk=partner_category)
                except DistributorHierarchy.DoesNotExist:
                    return Response({
                        'status': 'fail',
                        'message': 'Partner Category Does Not Exist'
                    }, status=status.HTTP_404_NOT_FOUND)

                # Fetch Hierarchy Charges
                hierarchy_charges = HierarchyCharges.objects.filter(dh=distributor_hierarchy, is_deactive=False,
                                                                    is_deleted=False)

                # Fetch dh_prefix and generate puc_unique_id
                dh_prefix = distributor_hierarchy.dh_prefix

                # Get the last entry for the same dh_prefix
                last_puc_id = PortalUserDetails.objects.filter(pud_unique_id__startswith=dh_prefix).order_by(
                    '-pud_unique_id').first()
                if last_puc_id:
                    # Extract the number part and increment by 1
                    last_number = int(last_puc_id.pud_unique_id[-4:])  # Get the last 4 digits
                    new_number = f"{last_number + 1:04d}"  # Increment and format as 4-digit number
                else:
                    # Start from '0001' if no previous record exists
                    new_number = "0001"

                file_path1 = handle_uploaded_file(profile_image, 'Distributor/Docs') if profile_image else None

                # Combine all paths into a single dictionary
                file_paths = {
                    'profile_image': file_path1,
                }

                # Create PortalUserDetails
                PortalUserDetails.objects.create(
                    pu=pu_obj,
                    pud_unique_id=f"{dh_prefix}{new_number}",
                    alternate_contact_no=alternate_contact_no,
                    address=address,
                    doc_images=file_paths,
                    state_id=state_id,
                    city_id=city_id,
                    zip_code=zip_code,
                    aadhaar_card=aadhaar_card,
                    pan_card=pan_card,
                    pan_response=pan_response
                )

                for charge in hierarchy_charges:
                    PortalUserCharges.objects.create(
                        sp=charge.sp,
                        dh=charge.dh,
                        pu_id=pu_obj.id,  # Assuming pu_id refers to the primary key of PortalUser
                        parent_id=request.user.id,
                        # Adjust if you have a logic for parent_id
                        mark_type=charge.mark_type,
                        puc_charges=charge.hc_charges,
                        created_by=request.user
                    )

                PortalUserWallet.objects.create(
                    main_wallet = 0.00,
                    commission_wallet = 0.00,
                    pu = pu_obj
                )

                return Response({
                    'status': 'success',
                    'message': 'Partner Created Successfully'
                }, status=status.HTTP_201_CREATED)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': str(e)
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def fetch_distributor(self, request):
        user_id = request.user.id  # Get the ID of the currently authenticated user
        try:
            distributor_data = {}
            page_number = request.data.get('page_number', 1)
            page_size = request.data.get('page_size', 10)
            distributor_id = request.data.get('distributor_id', None)

            if distributor_id == None:
                distributor_ids = PortalUser.objects.filter(pu_role='DISTRIBUTOR').values_list('id', flat=True)

                # Fetch PortalUserCharges created by the current user
                charges = PortalUserCharges.objects.filter(created_by=user_id, pu_id__in=distributor_ids).select_related(
                    'sp', 'dh')
                
            else:
                distributor_ids = PortalUser.objects.filter(pu_role='DISTRIBUTOR', id=distributor_id)
                print('===>', distributor_id)

                # Fetch PortalUserCharges created by the current user
                charges = PortalUserCharges.objects.filter(created_by=user_id, pu_id__in=distributor_ids).select_related(
                    'sp', 'dh')

            # Paginate the results
            paginator = Paginator(charges, page_size)
            try:
                page_obj = paginator.page(page_number)
            except EmptyPage:
                return Response({
                    'status': 'fail',
                    'message': 'Page not found.',
                    'data': {}
                }, status=status.HTTP_404_NOT_FOUND)

            if not charges.exists():
                paginated_response_data = {
                    'total_pages': 0,
                    'current_page': 0,
                    'total_items': 0,
                    'results': []
                }
                response_data = {
                    'status': 'success',
                    'message': 'Partner Data not found.',
                    'data': paginated_response_data
                }
                return Response(response_data, status=status.HTTP_200_OK)

            # Iterate through each charge and structure data
            for charge in page_obj:
                distributor = PortalUser.objects.get(id=charge.pu_id, pu_role='DISTRIBUTOR')
                distributor_details = PortalUserDetails.objects.get(pu_id=charge.pu_id)
                distributor_serializer = PortalUserDetailsSerializers(distributor_details)
                service_provider = charge.sp
                distributor_hierarchy = charge.dh

                # Prepare distributor data only if not already added
                if distributor.id not in distributor_data:
                    distributor_data[distributor.id] = {
                        'distributor': {
                            'id': distributor.id,
                            'name': distributor.pu_name,
                            'email': distributor.pu_email,
                            'contact_no': distributor.pu_contact_no,
                            'unique_id': distributor_details.pud_unique_id,
                        },
                        'distributor_details': distributor_serializer.data,
                        'distributor_hierarchy': {
                            'id': distributor_hierarchy.dh_id,
                            'name': distributor_hierarchy.dh_name  # Adjust according to your DistributorHierarchy model
                        },
                        'service_providers': []  # This will store a list of service providers under this distributor
                    }

                # Append the service provider under the respective distributor
                distributor_data[distributor.id]['service_providers'].append({
                    'id': service_provider.sp_id,
                    'service_name': service_provider.service.service_name,
                    'name': service_provider.sp_name,  # Adjust according to your ServiceProvider model
                    'mark_type': charge.mark_type,
                    'puc_charges': charge.puc_charges,
                })

            # Format data for pagination and response
            paginated_response_data = {
                'total_pages': paginator.num_pages,
                'current_page': page_obj.number,
                'total_items': paginator.count,
                'results': list(distributor_data.values())
                # Convert the distributor data to a list format for the response
            }

            return Response({
                'status': 'success',
                'message': 'Partner Data',
                'data': paginated_response_data
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'status': 'error',
                'message': 'Internal server error',
                'data': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def put(self, request):
        try:
            distributor_id = request.data.get('distributor_id')
            service_provider = request.data.get('service_provider')
            
            try:
                print('===>', service_provider)
                convert_service_provider = json.loads(service_provider)
            except json.JSONDecodeError:
                return Response({"status": "fail", "message": "service_provider must be valid JSON."}, status=status.HTTP_400_BAD_REQUEST)
            
            if not distributor_id:
                return Response({'status': 'fail', 'message': 'Distributor ID is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not service_provider:
                return Response({'status': 'fail', 'message': 'Service provider data is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
            distributor = PortalUser.objects.get(pu_role='DISTRIBUTOR', id=distributor_id)
            
            if not distributor:
                return Response({'status': 'fail', 'message': 'Distributor does not exist.'}, status=status.HTTP_404_NOT_FOUND)
            for data in convert_service_provider :
                if data['sp_id'] == '':
                    return Response({'status': 'fail', 'message': 'service provider ID is requried.'}, status=status.HTTP_400_BAD_REQUEST)
                service_provider_data = AdServiceProvider.objects.get(sp_id=data['sp_id'])
                distributor_charges = PortalUserCharges.objects.get(pu_id=distributor.id, sp=service_provider_data) 
                for i in distributor_charges.puc_charges:
                    user_charge_data = i
                for i in convert_service_provider:
                    mark_value = i
                if not distributor_charges:
                    return Response({'status': 'fail', 'message': 'Distributor charges do not exist.'}, status=status.HTTP_404_NOT_FOUND)

                if data['mark_value'] in ['', 'None']:
                    return Response({'status': 'fail', 'message': 'mark value are required.'}, status=status.HTTP_400_BAD_REQUEST)

                user_charge_data['rate'] = float(user_charge_data['rate'])
                mark_value['mark_value'] = float(mark_value['mark_value'])

                user_charge_data['rate'] += mark_value['mark_value']

                user_charge_data['rate'] = format(user_charge_data['rate'], ".2f")
                distributor_charges.puc_charges = [user_charge_data]
                distributor_charges.save()

            return Response({'status': 'success', 'message': 'Distributor charges updated successfully.'}, status=status.HTTP_200_OK)

        except AdServiceProvider.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Service provider does not exist.'}, status=status.HTTP_404_NOT_FOUND)

        except PortalUserCharges.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Distributor charges do not exist.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class UserAPIView(APIView):
    """
    """
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsDistributor | IsAdmin | IsRetailer]  # kishan: add retailer permission on 11-11-2024
    parser_classes = (MultiPartParser, FormParser)

    @swagger_auto_schema(
        tags=['Users'],
        manual_parameters=[
            openapi.Parameter('aadhaar_card', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('ref_id', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('aadhaar_otp', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('pan_card', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('pan_response', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('email', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('email_otp', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('contact_no', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('contact_otp', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('name', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('alternate_contact_no', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('address', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('state', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('city', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('zip_code', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('partner_category', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('profile_image', openapi.IN_FORM, type=openapi.TYPE_FILE, required=False),
            openapi.Parameter('page_number', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('page_size', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
        ]
    )
    def post(self, request):
        try:
            if 'aadhaar_card' in request.data and 'pan_card' in request.data and 'name' in request.data and 'email' in request.data and 'contact_no' in request.data:
                return self.add_users(request)
            elif 'aadhaar_card' in request.data:
                return self.verify_aadhaar(request)
            elif ('ref_id' in request.data and 'aadhaar_otp' in request.data) or (
                    'email' in request.data and 'email_otp' in request.data) or (
                    'contact_no' in request.data and 'contact_otp' in request.data):
                return self.verify_otp(request)
            elif 'pan_card' in request.data:
                return self.verify_pan(request)
            elif 'email' in request.data:
                return self.verify_email(request)
            elif 'contact_no' in request.data:
                return self.verify_contact(request)
            elif 'page_number' in request.data and 'page_size' in request.data or 'distributor_id' in request.data:
                return self.fetch_users(request)
            else:
                return Response({'status': 'error','message': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    def verify_aadhaar(self, request):
        aadhaar_card = request.data.get('aadhaar_card')
        if not aadhaar_card: return Response({"status": "fail", "message": "Aadhaar card is required."}, status=status.HTTP_400_BAD_REQUEST)
        if not isnumber(aadhaar_card): return Response({"status": "fail", "message": "Aadhaar card number must contain only digits."}, status=status.HTTP_400_BAD_REQUEST)
        if len(aadhaar_card) != 12: return Response({"status": "fail", "message": "Aadhaar card number must be exactly 12 digits long."}, status=status.HTTP_400_BAD_REQUEST)

        aadhaar_response = aadhaar_verify(aadhaar_card)
        return Response(aadhaar_response['data'], status=aadhaar_response['status'])

    def verify_otp(self, request):
        ref_id = request.data.get('ref_id')
        aadhaar_otp = request.data.get('aadhaar_otp')

        if not ref_id: return Response({"status": "fail", "message": "Referance id is required."}, status=status.HTTP_400_BAD_REQUEST)
        if not aadhaar_otp: return Response({"status": "fail", "message": "Aadhaar OTP is required."}, status=status.HTTP_400_BAD_REQUEST)

        if not isnumber(aadhaar_otp): return Response({"status": "fail", "message": "Aadhaar OTP must contain only digits."}, status=status.HTTP_400_BAD_REQUEST)
        if len(aadhaar_otp) != 6: return Response({"status": "fail", "message": "OTP code must be exactly 6 digits long."}, status=status.HTTP_400_BAD_REQUEST)

        aadhaar_otp_response = aadhaar_otp_verify(aadhaar_otp, ref_id)
        return Response(aadhaar_otp_response['data'], status=aadhaar_otp_response['status'])

    def verify_pan(self, request):
        pan_card = request.data.get('pan_card')
        if not pan_card: return Response({"status": "fail", "message": "Pan card is required."}, status=status.HTTP_400_BAD_REQUEST)
        if not checkpancardvalidation(pan_card): return Response({"status": "fail", "message": "Invalid PAN card format."}, status=status.HTTP_400_BAD_REQUEST)
        
        pan_card_response = verify_pan_card(pan_card)
        return Response(pan_card_response['data'], status=pan_card_response['status'])

    def verify_email(self, request):
        email = request.data.get('email')
        otp = get_random_string(length=6, allowed_chars='0123456789')
        try:
            if not email: return Response({"status": "fail", "message": "Email is required."}, status=status.HTTP_400_BAD_REQUEST)
            if not validation_email_address(email): return Response({"status": "fail", "message": "Invalid email address format."}, status=status.HTTP_400_BAD_REQUEST)

            try:
                pu_obj = UserCodeVerification.objects.get(ucv_data=email)
                pu_obj.verify_code = otp
                pu_obj.verify_code_expire_at = timezone.now() + timedelta(minutes=10)
                pu_obj.save()
            except UserCodeVerification.DoesNotExist:
                UserCodeVerification.objects.create(ucv_data=email, verify_code=otp,
                                                    verify_code_expire_at=timezone.now() + timedelta(minutes=10))

            with transaction.atomic():
                send_email = send_email_otp(email, otp, 'Distributor')

            response_data = {
                'status': 'success',
                'message': 'Email sent successfully',}
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_200_OK)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def verify_contact(self, request):
        contact_no = request.data.get('contact_no')
        otp = get_random_string(length=6, allowed_chars='0123456789')
        try:
            if not contact_no: return Response({"status": "fail", "message": "Contact number is required."}, status=status.HTTP_400_BAD_REQUEST)
            if not isnumber(contact_no): return Response({"status": "fail", "message": "Contact number must contain only digits."}, status=status.HTTP_400_BAD_REQUEST)
            if len(contact_no) != 10: return Response({"status": "fail", "message": "Contact number must be exactly 10 digits long."}, status=status.HTTP_400_BAD_REQUEST)
            try:
                pu_obj = UserCodeVerification.objects.get(ucv_data=contact_no)
                pu_obj.verify_code = otp
                pu_obj.verify_code_expire_at = timezone.now() + timedelta(minutes=10)
                pu_obj.save()
            except UserCodeVerification.DoesNotExist:
                UserCodeVerification.objects.create(ucv_data=contact_no, verify_code=otp,
                                                    verify_code_expire_at=timezone.now() + timedelta(minutes=10))

            # Prepare the SMS content
            response = mobicomm_submit_sms(contact_no, otp)

            # Check the SMS API response status
            if response.status_code == 200:
                response_data = {
                    'status': 'success',
                    'message': 'The provided contact number is registered, and the OTP has been sent via SMS.',
                    'data': {'contact_otp': otp}
                }
                return Response(response_data, status=status.HTTP_200_OK)
            else:
                response_data = {
                    'status': 'error',
                    'message': 'Failed to send the OTP via SMS.',
                    'details': response.text  # Include the response for debugging
                }
                return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def add_users(self, request):
        aadhaar_card = request.data.get('aadhaar_card')
        pan_card = request.data.get('pan_card')
        pan_response = request.data.get('pan_response')
        pu_name = request.data.get('name')
        pu_email = request.data.get('email')
        pu_contact_no = request.data.get('contact_no')
        alternate_contact_no = request.data.get('alternate_contact_no')
        address = request.data.get('address')
        state = request.data.get('state')
        city = request.data.get('city')
        zip_code = request.data.get('zip_code')
        partner_category = request.data.get('partner_category')
        profile_image = request.data.get('profile_image')

        try:
            with transaction.atomic():
                if not aadhaar_card: return Response({"status": "fail", "message": "Aadhaar card is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not pan_card: return Response({"status": "fail", "message": "Pan card is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not pan_response: return Response({"status": "fail", "message": "Pan response is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not pu_name: return Response({"status": "fail", "message": "Name is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not pu_email: return Response({"status": "fail", "message": "Email is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not pu_contact_no: return Response({"status": "fail", "message": "Contact number is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not alternate_contact_no: return Response({"status": "fail", "message": "Alternate contact number is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not address: return Response({"status": "fail", "message": "Address is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not state: return Response({"status": "fail", "message": "State name is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not city: return Response({"status": "fail", "message": "City name is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not zip_code: return Response({"status": "fail", "message": "Zip code is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not partner_category: return Response({"status": "fail", "message": "Partner category is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not profile_image: return Response({"status": "fail", "message": "Profile image is required."}, status=status.HTTP_400_BAD_REQUEST)

                if not isnumber(aadhaar_card): return Response({"status": "fail", "message": "Aadhaar card number must contain only digits."}, status=status.HTTP_400_BAD_REQUEST)
                if len(aadhaar_card) != 12: return Response({"status": "fail", "message": "Aadhaar card number must be exactly 12 digits long."}, status=status.HTTP_400_BAD_REQUEST)
                if not checkpancardvalidation(pan_card): return Response({"status": "fail", "message": "Invalid PAN card format."}, status=status.HTTP_400_BAD_REQUEST)

                try:
                    parsed_data = json.loads(pan_response)
                except json.JSONDecodeError:
                    return Response({"status": "fail", "message": "PAN response must be valid JSON."}, status=status.HTTP_400_BAD_REQUEST)
                
                if not validation_email_address(pu_email): return Response({"status": "fail", "message": "Invalid email address format."}, status=status.HTTP_400_BAD_REQUEST)
                if not isnumber(pu_contact_no): return Response({"status": "fail", "message": "Contact number must contain only digits."}, status=status.HTTP_400_BAD_REQUEST)
                if len(pu_contact_no) != 10: return Response({"status": "fail", "message": "Contact number must be exactly 10 digits long."}, status=status.HTTP_400_BAD_REQUEST)
                if not isnumber(alternate_contact_no): return Response({"status": "fail", "message": "Alternate contact number must be digit."}, status=status.HTTP_400_BAD_REQUEST)
                if len(alternate_contact_no) != 10: return Response({"status": "fail", "message": "Alternate contact number must be exactly 10 digits long."}, status=status.HTTP_400_BAD_REQUEST)

                state_obj = State.objects.filter(state_name__icontains=state).first()
                if not state_obj: return Response({'status': 'fail', 'message': 'State not found.'}, status=status.HTTP_404_NOT_FOUND)
                state_id = state_obj.state_id

                city_obj = City.objects.filter(city_name__icontains=city).first()
                if not city_obj: return Response({'status': 'fail', 'message': 'City not found.'}, status=status.HTTP_404_NOT_FOUND)
                city_id = city_obj.city_id

                if not isnumber(zip_code): return Response({"status": "fail", "message": "Zip code must contain only digits."}, status=status.HTTP_400_BAD_REQUEST)
                if len(zip_code) != 6: return Response({"status": "fail", "message": "Zip code must be exactly 6 digits long."}, status=status.HTTP_400_BAD_REQUEST)

                masked_aadhaar_number = parsed_data.get('masked_aadhaar_number')[-4:]
                if masked_aadhaar_number != aadhaar_card[-4:]:
                    return Response({'status': 'fail', 'message': 'Aadhaar number mismatch. Please verify the Aadhaar details.'}, status=status.HTTP_400_BAD_REQUEST)
                
                if parsed_data.get('aadhaar_linked') == False:
                    return Response({'status': 'fail', 'message': 'Aadhaar is not linked to the provided PAN card.'}, status=status.HTTP_400_BAD_REQUEST)

                if int(partner_category) != 0:
                    # Fetch DistributorHierarchy
                    try:
                        distributor_hierarchy = DistributorHierarchy.objects.get(pk=partner_category)
                    except DistributorHierarchy.DoesNotExist:
                        return Response({
                            'status': 'fail',
                            'message': 'Partner Category Does Not Exist'
                        }, status=status.HTTP_404_NOT_FOUND)
                else:
                    distributor_hierarchy = None

                
                if int(partner_category) != 0:
                    # Create PortalUser
                    pu_obj = PortalUser.objects.create(
                        pu_name=pu_name,
                        pu_email=pu_email,
                        pu_contact_no=pu_contact_no,
                        pu_role="DISTRIBUTOR"
                    )
                else:
                    pu_obj = PortalUser.objects.create(
                        pu_name=pu_name, 
                        pu_email=pu_email, 
                        pu_contact_no=pu_contact_no,
                        pu_role="RETAILER"
                    )

                # Fetch Hierarchy Charges
                hierarchy_charges = HierarchyCharges.objects.filter(dh=distributor_hierarchy, is_deactive=False,
                                                                    is_deleted=False)
                
                if int(partner_category) != 0:
                    # Fetch dh_prefix and generate pud_unique_id
                    prefix_value = distributor_hierarchy.dh_prefix
                else:
                    prefix_value = "RTL"

                # Get the last entry for the same dh_prefix
                last_puc_id = PortalUserDetails.objects.filter(pud_unique_id__startswith=prefix_value).order_by(
                    '-pud_unique_id').first()
                    
                if last_puc_id:
                    # Extract the number part and increment by 1
                    last_number = int(last_puc_id.pud_unique_id[-4:])  # Get the last 4 digits
                    new_number = f"{last_number + 1:04d}"  # Increment and format as 4-digit number
                else:
                    # Start from '0001' if no previous record exists
                    new_number = "0001"

                if int(partner_category) != 0:
                    file_path1 = handle_uploaded_file(profile_image, 'Distributor/Docs') if profile_image else None
                else:
                    file_path1 = handle_uploaded_file(profile_image, 'Retailer/Docs') if profile_image else None

                # Combine all paths into a single dictionary
                file_paths = {
                    'profile_image': file_path1,
                }

                # Create PortalUserDetails
                PortalUserDetails.objects.create(
                    pu=pu_obj,
                    pud_unique_id=f"{prefix_value}{new_number}",
                    alternate_contact_no=alternate_contact_no,
                    address=address,
                    doc_images=file_paths,
                    state_id=state_id,
                    city_id=city_id,
                    zip_code=zip_code,
                    aadhaar_card=aadhaar_card,
                    pan_card=pan_card,
                    pan_response=pan_response
                )

                for charge in hierarchy_charges:
                    PortalUserCharges.objects.create(
                        sp=charge.sp,
                        dh=charge.dh,
                        pu_id=pu_obj.id,  # Assuming pu_id refers to the primary key of PortalUser
                        parent_id=request.user.id,
                        # Adjust if you have a logic for parent_id
                        mark_type=charge.mark_type,
                        puc_charges=charge.hc_charges,
                        created_by=request.user
                    )

                if int(partner_category) != 0: 
                    PortalUserWallet.objects.create(
                        main_wallet = 0.00,
                        commission_wallet = 0.00,
                        pu = pu_obj
                    )
                else:
                    PortalUserWallet.objects.create(
                        main_wallet = 0.00,
                        commission_wallet = 0.00,
                        cashin_wallet = 0.00,
                        pg_wallet = 0.00,
                        pu = pu_obj
                    )

                return Response({
                    'status': 'success',
                    'message': 'User Created Successfully'
                }, status=status.HTTP_201_CREATED)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def fetch_users(self, request):
        user_id = request.user.id  # Get the ID of the currently authenticated user

        try:
            users_data = {}
            page_number = request.data.get('page_number', 1)
            page_size = request.data.get('page_size', 10)

            request_user_id = request.data.get('user_id', None)
            search_query = request.data.get('search', None)
            filter_field = request.data.get('filter_field', None)
            filter_value = request.data.get('filter_value', None)
            order_by = request.data.get('order_by', "ascending")

            if request_user_id is None:
                users_queryset = PortalUser.objects.filter(is_deleted=False)

                # Apply filtering by field
                if filter_field and filter_value:
                    if filter_field == "user_category":                        
                        if filter_value == "ALL DISTRIBUTOR":
                            portal_user_chareges = PortalUser.objects.filter(is_deleted=False).values_list('id', flat=True)
                        elif filter_value == "RETAILER":
                            portal_user_chareges = PortalUserCharges.objects.filter(dh=None).values_list('pu_id', flat=True)
                        else:
                            portal_user_chareges = PortalUserCharges.objects.filter(dh__dh_name=filter_value).values_list('pu_id', flat=True)

                        users_queryset = users_queryset.filter(id__in=portal_user_chareges)

                if search_query:
                    users_queryset = users_queryset.filter(
                        Q(pu_name__icontains=search_query) |
                        Q(pu_email__icontains=search_query) |
                        Q(pu_contact_no__icontains=search_query)
                        # Q(pu_role__icontains=search_query)
                    )

                if request.user.pu_role == "ADMIN":
                    if not users_queryset.exists() and search_query:
                        users_queryset = PortalUser.objects.filter(is_deleted=False)
                        users_ids = PortalUserCharges.objects.filter(pu_id__in=users_queryset.values_list('id', flat=True), dh__dh_name__icontains=search_query).values_list('pu_id', flat=True)
                    else:
                        users_ids = PortalUserCharges.objects.filter(pu_id__in=users_queryset.values_list('id', flat=True)).values_list('pu_id', flat=True)
                else:
                    if not users_queryset.exists() and search_query:
                        users_queryset = PortalUser.objects.filter(is_deleted=False)
                        users_ids = PortalUserCharges.objects.filter(created_by=user_id, pu_id__in=users_queryset.values_list('id', flat=True), dh__dh_name__icontains=search_query).values_list('pu_id', flat=True)
                    else:
                        users_ids = PortalUserCharges.objects.filter(created_by=user_id, pu_id__in=users_queryset.values_list('id', flat=True)).values_list('pu_id', flat=True)

                portal_user_queryset = PortalUser.objects.filter(id__in=users_ids)

                if order_by == "descending":
                    portal_user_queryset = portal_user_queryset.order_by('-pk')
                         
            else:
                portal_user_queryset = PortalUser.objects.filter(id=request_user_id)

            # Paginate the results
            paginator = Paginator(portal_user_queryset, page_size)
            try:
                page_obj = paginator.page(page_number)
            except EmptyPage:
                return Response({
                    'status': 'fail',
                    'message': 'Page not found.',
                    'data': {}
                }, status=status.HTTP_404_NOT_FOUND)

            if not portal_user_queryset.exists():
                paginated_response_data = {
                    'total_pages': 0,
                    'current_page': 0,
                    'total_items': 0,
                    'results': []
                }
                response_data = {
                    'status': 'success',
                    'message': 'Partner Data not found.',
                    'data': paginated_response_data
                }
                return Response(response_data, status=status.HTTP_200_OK)

            # Iterate through each charge and structure data
            for usr in page_obj:
                portal_user = PortalUser.objects.get(id=usr.id)
                portal_user_details = PortalUserDetails.objects.get(pu_id=usr.id)
                portal_user_serializer = PortalUserDetailsSerializers(portal_user_details, context={'request': request})

                # Prepare distributor data only if not already added
                if portal_user.id not in users_data:
                    users_data[portal_user.id] = {
                        'user': {
                            'id': portal_user.id,
                            'name': portal_user.pu_name,
                            'email': portal_user.pu_email,
                            'contact_no': portal_user.pu_contact_no,
                            'unique_id': portal_user_details.pud_unique_id,
                        },
                        'user_details': portal_user_serializer.data,
                        'service_providers': []  # This will store a list of service providers under this distributor
                    }


                charges = PortalUserCharges.objects.filter(pu_id=usr.id).select_related('sp', 'dh')
                
                for charge in charges:
                    service_provider = charge.sp
                    distributor_hierarchy = charge.dh
                    parent_id = charge.parent_id

                    parent_category = PortalUserCharges.objects.filter(pu_id=parent_id).select_related(
                    'sp', 'dh').first()

                    if parent_category:
                        perent_hierarchy = parent_category.dh

                        users_data[portal_user.id].update({'parent_user_hierarchy': {
                                'id': perent_hierarchy.dh_id if perent_hierarchy else 0,
                                'name': perent_hierarchy.dh_name  if perent_hierarchy else "RETAILER" # Adjust according to your DistributorHierarchy model
                            }
                        })
                    else:
                        users_data[portal_user.id].update({'parent_user_hierarchy': {
                                'id': 1,
                                'name': "ADMIN" # Adjust according to your DistributorHierarchy model
                            }
                        })

                    users_data[portal_user.id].update({'user_hierarchy': {
                            'id': distributor_hierarchy.dh_id if distributor_hierarchy else 0,
                            'name': distributor_hierarchy.dh_name  if distributor_hierarchy else "RETAILER" # Adjust according to your DistributorHierarchy model
                        }
                    })

                    # Append the service provider under the respective distributor
                    users_data[portal_user.id]['service_providers'].append({
                        'id': service_provider.sp_id,
                        'service_name': service_provider.service.service_name,
                        'name': service_provider.sp_name,  # Adjust according to your ServiceProvider model
                        'provider_label': service_provider.label,
                        'tds_rate': service_provider.tds_rate,
                        'hsn_sac': service_provider.hsn_sac.hsnsac_id if service_provider.hsn_sac else None,
                        'hsn_sac_code': service_provider.hsn_sac.hsnsac_code if service_provider.hsn_sac else None,
                        'tax_rate': service_provider.hsn_sac.tax_rate if service_provider.hsn_sac else None,
                        'mark_type': charge.mark_type,
                        'is_deactive': charge.is_deactive,
                        'puc_charges': charge.puc_charges
                    })

            # Format data for pagination and response
            paginated_response_data = {
                'total_pages': paginator.num_pages,
                'current_page': page_obj.number,
                'total_items': paginator.count,
                'results': list(users_data.values())
                # Convert the distributor data to a list format for the response
            }

            return Response({
                'status': 'success',
                'message': 'Partner Data',
                'data': paginated_response_data
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def put(self, request):
        try:
            distributor_id = request.data.get('distributor_id')
            service_provider = request.data.get('service_provider')
            
            try:
                convert_service_provider = json.loads(service_provider)
            except json.JSONDecodeError:
                return Response({"status": "fail", "message": "service_provider must be valid JSON."}, status=status.HTTP_400_BAD_REQUEST)
            
            if not distributor_id:
                return Response({'status': 'fail', 'message': 'Distributor ID is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not service_provider:
                return Response({'status': 'fail', 'message': 'Service provider data is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
            # distributor = PortalUser.objects.get(pu_role='DISTRIBUTOR', id=distributor_id)
            users = PortalUser.objects.get(id=distributor_id)
            
            if not users:
                return Response({'status': 'fail', 'message': 'Users does not exist.'}, status=status.HTTP_404_NOT_FOUND)
            for data in convert_service_provider :
                if data['sp_id'] == '':
                    return Response({'status': 'fail', 'message': 'service provider ID is requried.'}, status=status.HTTP_400_BAD_REQUEST)
                service_provider_data = AdServiceProvider.objects.get(sp_id=data['sp_id'])
                distributor_charges = PortalUserCharges.objects.get(pu_id=users.id, sp=service_provider_data)
                for i in distributor_charges.puc_charges:
                    user_charge_data = i
                for i in convert_service_provider:
                    mark_value = i
                if not distributor_charges:
                    return Response({'status': 'fail', 'message': 'Users charges do not exist.'}, status=status.HTTP_404_NOT_FOUND)

                if data['mark_value'] in ['', 'None']:
                    return Response({'status': 'fail', 'message': 'mark value are required.'}, status=status.HTTP_400_BAD_REQUEST)

                user_charge_data['rate'] = float(user_charge_data['rate'])
                mark_value['mark_value'] = float(mark_value['mark_value'])

                user_charge_data['rate'] += mark_value['mark_value']

                user_charge_data['rate'] = format(user_charge_data['rate'], ".2f")
                distributor_charges.puc_charges = [user_charge_data]
                distributor_charges.save()

            return Response({'status': 'success', 'message': 'Users charges updated successfully.'}, status=status.HTTP_200_OK)

        except AdServiceProvider.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Service provider does not exist.'}, status=status.HTTP_404_NOT_FOUND)

        except PortalUserCharges.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Users charges do not exist.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PartnerCategoryAPIView(APIView):
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAdmin | IsDistributor]
    parser_classes = (MultiPartParser, FormParser)

    @swagger_auto_schema(
        tags=['Partner Category'],
        manual_parameters=[
            openapi.Parameter('name', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('parent_id', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('description', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('partner_prefix', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('service_provider', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('page_number', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('page_size', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('search', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('dh_id', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('is_deactive', openapi.IN_FORM, type=openapi.TYPE_BOOLEAN, required=False),
            openapi.Parameter('in_parent', openapi.IN_FORM, type=openapi.TYPE_BOOLEAN, required=False),
            openapi.Parameter('order_by', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
        ]
    )
    def post(self, request):
        try:
            if ('page_number' in request.data and 'page_size' in request.data) or 'dh_id' in request.data:
                return self.fetch_data(request)
            elif 'name' in request.data and 'partner_prefix' in request.data:
                return self.create_hierarchy(request)
            else:
                return Response({'status': 'error', 'message': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': f'{str(e)}'
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def create_hierarchy(self, request):
        try:
            with transaction.atomic():
                name = request.data.get('name')
                parent_id = request.data.get('parent_id', 0)
                description = request.data.get('description')
                partner_prefix = request.data.get('partner_prefix')
                service_provider_str = request.data.get('service_provider', '[]')
                service_provider = json.loads(service_provider_str)

                if len(partner_prefix) >= 4:
                    return Response({'status': 'fail', 'message': 'Partner prefix must be fewer than 4 characters.'}, status=status.HTTP_400_BAD_REQUEST)

                if parent_id:
                    try:
                        dh_obj = DistributorHierarchy.objects.get(dh_id=parent_id)

                        if dh_obj.is_used:
                            response_data = {
                                'status': 'success',
                                'message': 'Parent id is already used'
                            }
                            # Return a success response with status code 201 (Created)
                            return Response(response_data, status=status.HTTP_201_CREATED)
                        else:
                            dh_obj.is_used = True
                            dh_obj.save()
                    except DistributorHierarchy.DoesNotExist:
                        response_data = {
                            'status': 'fail',
                            'message': 'Parent id does not exist'
                        }
                        # Return a success response with status code 201 (Created)
                        return Response(response_data, status=status.HTTP_404_NOT_FOUND)

                # Assuming DistributorHierarchy is created here
                hierarchy = DistributorHierarchy.objects.create(
                    dh_name=name, dh_parent_id=parent_id if parent_id else None, dh_description=description,
                    dh_prefix=partner_prefix
                )

                for provider in service_provider:
                    sp_id = provider.get('sp_id')
                    mark_type = provider.get('charge_type')
                    mark_value = provider.get('mark_value')
                    is_deactive = provider.get('is_deactive')

                    charges = AdCharges.objects.filter(service_provider_id=sp_id)

                    # Prepare charges data
                    charges_list = []
                    for charge in charges:
                        rate = charge.rate
                        minimum = charge.minimum
                        maximum = charge.maximum

                        # Apply markup based on the type
                        updated_rate = float(rate) + mark_value

                        charges_list.append({
                            'rate': updated_rate,
                            'minimum': float(minimum),
                            'maximum': float(maximum),
                        })

                    # Store the charges data in HierarchyCharges model
                    HierarchyCharges.objects.create(
                        hc_charges=charges_list,
                        sp_id=sp_id,
                        dh_id=hierarchy.dh_id,
                        mark_type=mark_type,
                        mark_value=float(mark_value),
                        is_deactive=is_deactive
                    )

                response_data = {
                    'status': 'success',
                    'message': 'Partner Category Created Successfully'
                }
                # Return a success response with status code 201 (Created)
                return Response(response_data, status=status.HTTP_201_CREATED)

        except ValidationError as e:
            response_data = {
                'status': 'fail',
                'message': f'{str(e)}'
            }
            return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            # Handle any exceptions and return an error response
            response_data = {
                'status': 'error',
                'message': f'{str(e)}'
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def fetch_data(self, request):
        # Logged in user's ID and role from the token
        user_id = request.user.id
        user_role = request.user.pu_role  # Assuming `user_role` is available in request.user

        # Get parameters from the request
        dh_id = request.data.get('dh_id')
        search_txt = request.data.get('search')
        in_parent = request.data.get('in_parent', None)
        in_partner = request.data.get('in_partner', None)
        is_app = request.data.get('is_app', None)
        page_number = int(request.data.get('page_numbr', 1))
        page_size = int(request.data.get('page_size', 10))

        try:
            if user_role == 'ADMIN':
                queryset = DistributorHierarchy.objects.filter(
                    is_deleted=False
                ).order_by('pk')
                if in_parent:
                    queryset = queryset.filter(is_used=False)
                if in_partner:
                    queryset = queryset.filter(dh_parent_id=None)
            else:
                # Fetch the distributor hierarchy ID of the user
                user_hierarchy = PortalUserCharges.objects.filter(pu_id=user_id).first()

                # Check if user has an associated hierarchy
                if not user_hierarchy:
                    return Response({
                        'status': 'fail',
                        'message': 'No associated partner category found for this user.',
                        'data': {}
                    }, status=status.HTTP_400_BAD_REQUEST)

                # Get the hierarchy ID to filter with
                user_dh_id = user_hierarchy.dh_id
                if user_dh_id == 1:
                    queryset = DistributorHierarchy.objects.filter(
                        is_deleted=False).order_by('pk')[1:3] 
                else:
                    queryset = DistributorHierarchy.objects.filter(
                        is_deleted=False, dh_parent_id=user_dh_id
                    ).order_by('-pk')

            # Apply additional filters if provided
            if dh_id:
                queryset = queryset.filter(pk=dh_id)
            if search_txt:
                queryset = queryset.filter(
                    Q(service_name__icontains=search_txt) |
                    Q(description__icontains=search_txt)
                )

            # Paginator setup
            paginator = Paginator(queryset, page_size)
            try:
                page_obj = paginator.page(page_number)
            except EmptyPage:
                return Response({
                    'status': 'fail',
                    'message': 'Page not found.',
                    'data': {}
                }, status=status.HTTP_404_NOT_FOUND)

            # Return paginated response if data exists
            if page_obj is not None:
                if not queryset.exists():
                    paginated_response_data = {
                        'total_pages': 0,
                        'current_page': 0,
                        'total_items': 0,
                        'results': []
                    }
                    response_data = {
                        'status': 'success',
                        'message': 'Partner Category Data not found.',
                        'data': paginated_response_data
                    }
                    return Response(response_data, status=status.HTTP_200_OK)
                serializer = DistributorHierarchySerializer(page_obj.object_list, many=True,
                                                            context={'request': request,
                                                                     'exclude_fields': ["created_at", "updated_at",
                                                                                        "is_deleted"]})

                if is_app:
                    try:
                        hc_charges = HierarchyCharges.objects.get(dh=None, sp=request.data.get('sp_id')).hc_charges
                    except:
                        hc_charges = []

                    data = {
                        "dh_id": 0,
                        "parent_category_name": None,
                        "hc_charges": hc_charges,
                        "dh_name": "Retailer",
                        "dh_parent_id": None,
                        "dh_description": "retailer",
                        "dh_prefix": "RT",
                        "is_used": False,
                        "is_deactive": False,
                        "is_deleted": False,
                        "created_at": "2024-10-16T12:31:48.621432Z",
                        "updated_at": None,
                        "updated_by": None,
                        "created_by": None  
                    }

                    paginated_response_data = {
                        'total_pages': paginator.num_pages,
                        'current_page': page_obj.number,
                        'total_items': paginator.count,
                        'results': serializer.data
                    }
                    paginated_response_data['results'].append(data)
                    return Response({
                        'status': 'success',
                        'message': 'Partner Cateogry Data',
                        'data': paginated_response_data
                    }, status=status.HTTP_200_OK)

                paginated_response_data = {
                    'total_pages': paginator.num_pages,
                    'current_page': page_obj.number,
                    'total_items': paginator.count,
                    'results': serializer.data
                }
                return Response({
                    'status': 'success',
                    'message': 'Partner Cateogry Data',
                    'data': paginated_response_data
                }, status=status.HTTP_200_OK)

            # Non-paginated response if page object is None
            serializer = DistributorHierarchySerializer(queryset, many=True, context={'request': request,
                                                                                      'exclude_fields': ["created_at",
                                                                                                         "updated_at",
                                                                                                         "is_deleted"]})
            response_data = {
                'status': 'success',
                'message': 'Partner Category Data',
                'data': serializer.data
            }
            return Response(response_data, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'status': 'fail',
                'message': str(e),
                'data': {}
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @swagger_auto_schema(
        tags=['Partner Category'],
        manual_parameters=[
            openapi.Parameter('dh_id', openapi.IN_FORM, type=openapi.TYPE_STRING, required=True),
            openapi.Parameter('service_provider', openapi.IN_FORM, type=openapi.TYPE_STRING, required=True),
        ]
    )
    def put(self, request):
        try:
            dh_id = request.data.get('dh_id')
            prefix = request.data.get('prefix', None)

            if prefix:
                prefix_validation = isstring(prefix)
                if prefix_validation == False:
                    return Response({'status': 'fail', 'message': 'Invalid input: prefix must be a string.'}, status=status.HTTP_400_BAD_REQUEST)
                if len(prefix) >= 4:
                    return Response({'status': 'fail', 'message': 'Partner prefix must be fewer than 4 characters.'}, status=status.HTTP_400_BAD_REQUEST)
            
            distributor_hierachy = DistributorHierarchy.objects.get(dh_id=dh_id)

            if prefix:
                distributor_hierachy.dh_prefix = prefix

            distributor_hierachy.save()

            return Response({'status': 'success', 'message': 'hierarchy charges updated successfully..'}, status=status.HTTP_200_OK) 

        except HierarchyCharges.DoesNotExist:
            return Response({'status': 'fail', 'message': 'hierarchy charges dose not exists.'}, status=status.HTTP_404_NOT_FOUND)    

        except DistributorHierarchy.DoesNotExist:
            return Response({'status': 'fail', 'message': 'distributor hierarchy dose not exists.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'status': 'error', 'message': 'Internal server error.', 'data': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class RetailerAPIView(APIView):
    """
    """
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAdmin | IsDistributor]
    parser_classes = (MultiPartParser, FormParser)

    @swagger_auto_schema(
        tags=['Retailers'],
        manual_parameters=[
            openapi.Parameter('aadhaar_card', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('ref_id', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('aadhaar_otp', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('pan_card', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('pan_response', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('name', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('email', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('email_otp', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('contact_no', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('contact_otp', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('address', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('state', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('city', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('zip_code', openapi.IN_FORM, type=openapi.TYPE_STRING, required=False),
            openapi.Parameter('profile_image', openapi.IN_FORM, type=openapi.TYPE_FILE, required=False),
            openapi.Parameter('page_number', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
            openapi.Parameter('page_size', openapi.IN_FORM, type=openapi.TYPE_INTEGER, required=False),
        ]
    )
    def post(self, request):
        try:
            if 'aadhaar_card' in request.data and 'pan_card' in request.data and 'name' in request.data and 'email' in request.data and 'contact_no' in request.data:
                return self.add_retailer(request)
            elif 'aadhaar_card' in request.data:
                return self.verify_aadhaar(request)
            elif ('ref_id' in request.data and 'aadhaar_otp' in request.data) or (
                    'email' in request.data and 'email_otp' in request.data) or (
                    'contact_no' in request.data and 'contact_otp' in request.data):
                return self.verify_otp(request)
            elif 'pan_card' in request.data:
                return self.verify_pan(request)
            elif 'email' in request.data:
                return self.verify_email(request)
            elif 'contact_no' in request.data:
                return self.verify_contact(request)
            elif 'page_number' in request.data and 'page_size' in request.data:
                return self.fetch_retailer(request)
            else:
                return Response({'status': 'error', 'message': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': str(e)
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def verify_aadhaar(self, request):
        aadhaar_card = request.data.get('aadhaar_card')

        aadhaar_url = "https://api.cashfree.com/verification/offline-aadhaar/otp"

        aadhaar_payload = {"aadhaar_number": aadhaar_card}
        aadhaar_headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "x-client-id": "CF449777CRQG8U0O577S73AHL800",
            "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
        }

        aadhaar_response = requests.post(aadhaar_url, json=aadhaar_payload, headers=aadhaar_headers)

        res = aadhaar_response.json()
        if aadhaar_response.status_code == 200:

            response_data = {
                'status': 'success',
                'message': 'OTP sent successfully',
                'data': {'aadhaar_otp': 267987, 'ref_id': res['ref_id']}
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            return Response(res, aadhaar_response.status_code)

    def verify_otp(self, request):
        if 'ref_id' in request.data and 'aadhaar_otp' in request.data:
            ref_id = request.data.get('ref_id')
            aadhaar_otp = request.data.get('aadhaar_otp')

            otp_url = "https://api.cashfree.com/verification/offline-aadhaar/verify"

            otp_payload = {
                "otp": aadhaar_otp,
                "ref_id": ref_id
            }
            otp_headers = {
                "accept": "application/json",
                "content-type": "application/json",
                "x-client-id": "CF449777CRQG8U0O577S73AHL800",
                "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
            }

            otp_response = requests.post(otp_url, json=otp_payload, headers=otp_headers)

            res = otp_response.json()
            if otp_response.status_code == 200:

                response_data = {
                    'status': 'success',
                    'message': 'Aadhaar verified successfully',
                    'data': res
                }
                # Return a success response with status code 200
                return Response(response_data, status=status.HTTP_200_OK)
            else:
                return Response(res, otp_response.status_code)
        elif 'email' in request.data and 'email_otp' in request.data:
            email = request.data.get('email')
            email_otp = request.data.get('email_otp')

            try:
                user = UserCodeVerification.objects.get(ucv_data=email)

                if user.verify_code == email_otp and user.verify_code_expire_at > timezone.now():
                    user.verify_code = None
                    user.verify_code_expire_at = None
                    user.is_everify = True
                    user.save()

                    response_data = {
                        'status': 'success',
                        'message': 'Email verification code verified successfully.',
                    }
                    return Response(response_data, status=status.HTTP_200_OK)
                else:
                    response_data = {
                        'status': 'fail',
                        'message': 'Invalid or expired verification code.'
                    }
                    return Response(response_data, status=status.HTTP_400_BAD_REQUEST)

            except UserCodeVerification.DoesNotExist:
                response_data = {
                    'status': 'error',
                    'message': 'User with this email does not exist.'
                }
                return Response(response_data, status=status.HTTP_404_NOT_FOUND)

            except Exception as e:
                response_data = {
                    'status': 'error',
                    'message': str(e),
                }
                # Return a success response with status code 200
                return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            contact_no = request.data.get('contact_no')
            contact_otp = request.data.get('contact_otp')

            try:
                user = UserCodeVerification.objects.get(ucv_data=contact_no)

                if user.verify_code == contact_otp and user.verify_code_expire_at > timezone.now():
                    user.verify_code = None
                    user.verify_code_expire_at = None
                    user.is_everify = True
                    user.save()

                    response_data = {
                        'status': 'success',
                        'message': 'Contact verification code verified successfully.',
                    }
                    return Response(response_data, status=status.HTTP_200_OK)
                else:
                    response_data = {
                        'status': 'fail',
                        'message': 'Invalid or expired verification code.'
                    }
                    return Response(response_data, status=status.HTTP_400_BAD_REQUEST)

            except UserCodeVerification.DoesNotExist:
                response_data = {
                    'status': 'error',
                    'message': 'User with this contact no does not exist.'
                }
                return Response(response_data, status=status.HTTP_404_NOT_FOUND)

            except Exception as e:
                response_data = {
                    'status': 'error',
                    'message': str(e),
                }
                # Return a success response with status code 200
                return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def verify_pan(self, request):
        pan_card = request.data.get('pan_card')

        pan_url = "https://api.cashfree.com/verification/pan/advance"

        pan_payload = {
            "pan": pan_card,
            "verification_id": get_random_string(length=10)
        }
        pan_headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "x-client-id": "CF449777CRQG8U0O577S73AHL800",
            "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
        }

        pan_response = requests.post(pan_url, json=pan_payload, headers=pan_headers)

        res = pan_response.json()
        if pan_response.status_code == 200:

            response_data = {
                'status': 'success',
                'message': 'Pan verified successfully',
                'data': res
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            return Response(res, pan_response.status_code)

    def verify_email(self, request):
        email = request.data.get('email')

        otp = get_random_string(length=6, allowed_chars='0123456789')
        try:
            if not email: return Response({"status": "fail", "message": "Email is required."}, status=status.HTTP_400_BAD_REQUEST)
            if not validation_email_address(email): return Response({"status": "fail", "message": "Invalid email address format."}, status=status.HTTP_400_BAD_REQUEST)
            
            try:
                pu_obj = UserCodeVerification.objects.get(ucv_data=email)
                pu_obj.verify_code = otp
                pu_obj.verify_code_expire_at = timezone.now() + timedelta(minutes=10)
                pu_obj.save()
            except UserCodeVerification.DoesNotExist:
                UserCodeVerification.objects.create(ucv_data=email, verify_code=otp,
                                                    verify_code_expire_at=timezone.now() + timedelta(minutes=10))

            with transaction.atomic():
                # Prepare HTML content for email
                subject = 'Verify Code for Email Verification'

                # HTML content
                html_content = f"""
                    <html>
                    <head>
                        <style>
                            body {{
                                font-family: Arial, sans-serif;
                                background-color: #f4f4f4;
                                padding: 20px;
                            }}
                            .container {{
                                background-color: #ffffff;
                                border-radius: 5px;
                                padding: 20px;
                                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                            }}
                            h2 {{
                                color: #333;
                            }}
                            p {{
                                color: #555;
                            }}
                            .footer {{
                                margin-top: 20px;
                                font-size: 0.8em;
                                color: #999;
                            }}
                        </style>
                    </head>
                    <body>
                        <div class="container">
                            <h4>Hello Retailer,</h4>
                            <p>We hope this message finds you well!</p>
                            <p>Your OTP for email verification is: <strong>{otp}</strong></p>
                            <p>Please make sure to keep it confidential and do not share it with anyone.</p>
                            <p>If you did not request this, please disregard this email.</p>
                            <p>If you have any questions or need further assistance, feel free to contact our support team.</p>
                            <p>Best regards,<br>TCPL</p>
                        </div>
                        <div class="footer">
                            <p>This email is generated automatically, please do not reply.</p>
                        </div>
                    </body>
                    </html>
                """

                # Create a plain text version by stripping HTML tags (for email clients that don't support HTML)
                text_content = strip_tags(html_content)
                # Create the email object
                email_message = EmailMultiAlternatives(subject, text_content, settings.EMAIL_HOST_USER, [email])
                # Attach the HTML version of the email
                email_message.attach_alternative(html_content, "text/html")
                email_message.send(fail_silently=False)

            response_data = {
                'status': 'success',
                'message': 'Email sent successfully',
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_200_OK)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def verify_contact(self, request):
        contact_no = request.data.get('contact_no')

        otp = get_random_string(length=6, allowed_chars='0123456789')
        try:
            try:
                pu_obj = UserCodeVerification.objects.get(ucv_data=contact_no)
                pu_obj.verify_code = otp
                pu_obj.verify_code_expire_at = timezone.now() + timedelta(minutes=10)
                pu_obj.save()
            except UserCodeVerification.DoesNotExist:
                UserCodeVerification.objects.create(ucv_data=contact_no, verify_code=otp,
                                                    verify_code_expire_at=timezone.now() + timedelta(minutes=10))

            # Prepare the SMS content
            message = f"Your One Time Verification Code for Tapi Cashless login is {otp},Please do not share it with anyone. Thanks Tapi Cashless."

            # Replace the placeholders with actual values
            sms_url = "https://mobicomm.dove-sms.com/submitsms.jsp"
            sms_params = {
                'user': 'TAPICASH',
                'key': '66a1621a84XX',
                'mobile': f"+91{contact_no}",
                'message': message,
                'senderid': 'TAPICL',
                'accusage': '1',
                'entityid': '1701172165114242200',
                'tempid': '1707172206814737429'
            }

            # Send the SMS using a GET request
            response = requests.get(sms_url, params=sms_params)

            # Check the SMS API response status
            if response.status_code == 200:
                response_data = {
                    'status': 'success',
                    'message': 'The provided contact number is registered, and the OTP has been sent via SMS.',
                    'data': {'contact_otp': otp}
                }
                return Response(response_data, status=status.HTTP_200_OK)
            else:
                response_data = {
                    'status': 'error',
                    'message': 'Failed to send the OTP via SMS.',
                    'details': response.text  # Include the response for debugging
                }
                return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': str(e),
            }
            # Return a success response with status code 200
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def add_retailer(self, request):
        aadhaar_card = request.data.get('aadhaar_card')
        pan_card = request.data.get('pan_card')
        pan_response = request.data.get('pan_response')
        pu_name = request.data.get('name')
        pu_email = request.data.get('email')
        pu_contact_no = request.data.get('contact_no')
        address = request.data.get('address')
        state = request.data.get('state')
        city = request.data.get('city')
        zip_code = request.data.get('zip_code')
        profile_image = request.data.get('profile_image')

        try:
            with transaction.atomic():
                if not aadhaar_card: return Response({"status": "fail", "message": "Aadhaar card is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not pan_card: return Response({"status": "fail", "message": "Pan card is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not pan_response: return Response({"status": "fail", "message": "Pan response is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not pu_name: return Response({"status": "fail", "message": "Name is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not pu_email: return Response({"status": "fail", "message": "Email is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not pu_contact_no: return Response({"status": "fail", "message": "Contact number is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not address: return Response({"status": "fail", "message": "Address is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not state: return Response({"status": "fail", "message": "State name is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not city: return Response({"status": "fail", "message": "City name is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not zip_code: return Response({"status": "fail", "message": "Zip code is required."}, status=status.HTTP_400_BAD_REQUEST)
                if not profile_image: return Response({"status": "fail", "message": "Profile image is required."}, status=status.HTTP_400_BAD_REQUEST)

                if not isnumber(aadhaar_card): return Response({"status": "fail", "message": "Aadhaar card number must contain only digits."}, status=status.HTTP_400_BAD_REQUEST)
                if len(aadhaar_card) != 12: return Response({"status": "fail", "message": "Aadhaar card number must be exactly 12 digits long."}, status=status.HTTP_400_BAD_REQUEST)
                if not checkpancardvalidation(pan_card): return Response({"status": "fail", "message": "Invalid PAN card format."}, status=status.HTTP_400_BAD_REQUEST)

                try:
                    parsed_data = json.loads(pan_response)
                except json.JSONDecodeError:
                    return Response({"status": "fail", "message": "PAN response must be valid JSON."}, status=status.HTTP_400_BAD_REQUEST)
                
                if not validation_email_address(pu_email): return Response({"status": "fail", "message": "Invalid email address format."}, status=status.HTTP_400_BAD_REQUEST)
                if not isnumber(pu_contact_no): return Response({"status": "fail", "message": "Contact number must contain only digits."}, status=status.HTTP_400_BAD_REQUEST)
                if len(pu_contact_no) != 10: return Response({"status": "fail", "message": "Contact number must be exactly 10 digits long."}, status=status.HTTP_400_BAD_REQUEST)
                if not isnumber(zip_code): return Response({"status": "fail", "message": "Zip code must contain only digits."}, status=status.HTTP_400_BAD_REQUEST)
                if len(zip_code) != 6: return Response({"status": "fail", "message": "Zip code must be exactly 6 digits long."}, status=status.HTTP_400_BAD_REQUEST)

                state_obj = State.objects.filter(state_name__icontains=state).first()
                if not state_obj: return Response({'status': 'fail', 'message': 'State not found.'}, status=status.HTTP_404_NOT_FOUND)
                state_id = state_obj.state_id

                city_obj = City.objects.filter(city_name__icontains=city).first()
                if not city_obj: return Response({'status': 'fail', 'message': 'City not found.'}, status=status.HTTP_404_NOT_FOUND)
                city_id = city_obj.city_id
                
                masked_aadhaar_number = parsed_data.get('masked_aadhaar_number')[-4:]
                if masked_aadhaar_number != aadhaar_card[-4:]:
                    return Response({'status': 'fail', 'message': 'Aadhaar number mismatch. Please verify the Aadhaar details.'}, status=status.HTTP_400_BAD_REQUEST)
                
                if parsed_data.get('aadhaar_linked') == False:
                    return Response({'status': 'fail', 'message': 'Aadhaar is not linked to the provided PAN card.'}, status=status.HTTP_400_BAD_REQUEST)

                rtl_prefix = "RTL"

                # Get the last entry for the same dh_prefix
                last_puc_id = PortalUserDetails.objects.filter(pud_unique_id__startswith="RTL").order_by(
                    '-pud_unique_id').first()
                if last_puc_id:
                    # Extract the number part and increment by 1
                    last_number = int(last_puc_id.pud_unique_id[-4:])  # Get the last 4 digits
                    new_number = f"{last_number + 1:04d}"  # Increment and format as 4-digit number
                else:
                    # Start from '0001' if no previous record exists
                    new_number = "0001"

                file_path1 = handle_uploaded_file(profile_image, 'Retailer/Docs') if profile_image else None
                # Combine all paths into a single dictionary
                file_paths = {
                    'profile_image': file_path1,
                }

                pu_obj = PortalUser.objects.create(pu_name=pu_name, pu_email=pu_email, pu_contact_no=pu_contact_no,
                                                   pu_role="RETAILER")

                PortalUserDetails.objects.create(pu=pu_obj, pud_unique_id=f"{rtl_prefix}{new_number}", aadhaar_card=aadhaar_card,
                                                 pan_card=pan_card, pan_response=pan_response, address=address,
                                                 doc_images=file_paths, state_id=state_id, city_id=city_id,
                                                 zip_code=zip_code)

                # Fetch Hierarchy Charges
                hierarchy_charges = HierarchyCharges.objects.filter(dh_id=None, is_deactive=False, is_deleted=False)

                for charge in hierarchy_charges:
                    PortalUserCharges.objects.create(
                        sp=charge.sp,
                        pu_id=pu_obj.id,  # Assuming pu_id refers to the primary key of PortalUser
                        parent_id=request.user.id,
                        # Adjust if you have a logic for parent_id
                        mark_type=charge.mark_type,
                        puc_charges=charge.hc_charges,
                        created_by=request.user
                    )

                PortalUserWallet.objects.create(
                    main_wallet = 0.00,
                    commission_wallet = 0.00,
                    cashin_wallet = 0.00,
                    pg_wallet = 0.00,
                    pu = pu_obj
                )    

                response_data = {
                    'status': 'success',
                    'message': 'Retailer Created Successfully'
                }
            # Return a success response with status code 201 (Created)
            return Response(response_data, status=status.HTTP_201_CREATED)
        except Exception as e:
            response_data = {
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def fetch_retailer(self, request):
        user_id = request.user.id  # Get the ID of the currently authenticated user
        try:
            retailer_data = {}
            page_number = request.data.get('page_number', 1)
            page_size = request.data.get('page_size', 10)

            retailer_id = request.data.get('retailer_id', None)
            
            if retailer_id == None:

                retailer_ids = PortalUser.objects.filter(pu_role='RETAILER').values_list('id', flat=True)

                charges = PortalUserCharges.objects.filter(created_by=user_id, pu_id__in=retailer_ids).select_related('sp', 'dh')
            
            else:
                retailer_ids = PortalUser.objects.filter(pu_role='RETAILER', id=retailer_id)

                charges = PortalUserCharges.objects.filter(created_by=user_id, pu_id__in=retailer_ids).select_related('sp', 'dh')

            # Fetch PortalUser IDs that are RETAILERs
            retailer_ids = PortalUser.objects.filter(pu_role='RETAILER').values_list('id', flat=True)

            # Fetch PortalUserCharges created by the current user and associated with DISTRIBUTORs only
            charges = PortalUserCharges.objects.filter(created_by=user_id, pu_id__in=retailer_ids).select_related('sp',
                                                                                                                  'dh')

            # Paginate the results
            paginator = Paginator(charges, page_size)
            try:
                page_obj = paginator.page(page_number)
            except EmptyPage:
                return Response({
                    'status': 'fail',
                    'message': 'Page not found.',
                    'data': {}
                }, status=status.HTTP_404_NOT_FOUND)

            if not charges.exists():
                paginated_response_data = {
                    'total_pages': 0,
                    'current_page': 0,
                    'total_items': 0,
                    'results': []
                }
                response_data = {
                    'status': 'success',
                    'message': 'Partner Data not found.',
                    'data': paginated_response_data
                }
                return Response(response_data, status=status.HTTP_200_OK)

            # Iterate through each charge and structure data
            for charge in page_obj:
                retailer = PortalUser.objects.get(id=charge.pu_id, pu_role='RETAILER')
                retailer_details = PortalUserDetails.objects.get(pu_id=charge.pu_id)
                retailer_details_serializer = PortalUserDetailsSerializers(retailer_details)
                service_provider = charge.sp

                # Prepare distributor data only if not already added
                if retailer.id not in retailer_data:
                    retailer_data[retailer.id] = {
                        'distributor': {
                            'id': retailer.id,
                            'name': retailer.pu_name,
                            'email': retailer.pu_email,
                            'contact_no': retailer.pu_contact_no,
                            'unique_id': retailer_details.pud_unique_id,
                        },
                        'retailers_details': retailer_details_serializer.data,
                        'service_providers': []  # This will store a list of service providers under this distributor
                    }

                # Append the service provider under the respective distributor
                retailer_data[retailer.id]['service_providers'].append({
                    'id': service_provider.sp_id,
                    'service_name': service_provider.service.service_name,
                    'name': service_provider.sp_name,  # Adjust according to your ServiceProvider model
                    'mark_type': charge.mark_type,
                    'puc_charges': charge.puc_charges,
                })

            # Format data for pagination and response
            paginated_response_data = {
                'total_pages': paginator.num_pages,
                'current_page': page_obj.number,
                'total_items': paginator.count,
                'results': list(retailer_data.values())
                # Convert the distributor data to a list format for the response
            }

            return Response({
                'status': 'success',
                'message': 'Partner Data',
                'data': paginated_response_data
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({
                'status': 'error',
                'message': 'Internal server error',
                'data': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    def put(self, request):
        try:
            retailer_id = request.data.get('retailer_id')
            service_provider = request.data.get('service_provider')
            convert_service_provider = json.loads(service_provider)
            if not retailer_id:
                return Response({'status': 'fail', 'message': 'retailer_id ID is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not service_provider:
                return Response({'status': 'fail', 'message': 'Service provider data is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
            retailer = PortalUser.objects.get(pu_role='RETAILER', id=retailer_id)
            
            if not retailer:
                return Response({'status': 'fail', 'message': 'Retailer does not exist.'}, status=status.HTTP_404_NOT_FOUND)

            for data in convert_service_provider :
                # Ensure data is a dictionary and has required keys

                if data['sp_id'] == '':
                    return Response({'status': 'fail', 'message': 'service provider ID is requried.'}, status=status.HTTP_400_BAD_REQUEST)

                service_provider_data = AdServiceProvider.objects.get(sp_id=data['sp_id'])
                retailer_charges = PortalUserCharges.objects.get(pu_id=retailer.id, sp=service_provider_data)

                for i in retailer_charges.puc_charges:
                    user_charge_data = i
                for i in convert_service_provider:
                    mark_value = i
                if not retailer_charges:
                    return Response({'status': 'fail', 'message': 'Retailer charges do not exist.'}, status=status.HTTP_404_NOT_FOUND)

                if data['mark_value'] in ['', 'None']:
                    return Response({'status': 'fail', 'message': 'mark value are required.'}, status=status.HTTP_400_BAD_REQUEST)

                user_charge_data['rate'] += mark_value['mark_value']
                retailer_charges.puc_charges = [user_charge_data]
                retailer_charges.save()

            return Response({'status': 'success', 'message': 'Retailer charges updated successfully.'}, status=status.HTTP_200_OK)

        except AdServiceProvider.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Service provider does not exist.'}, status=status.HTTP_404_NOT_FOUND)

        except PortalUserCharges.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Retailer charges do not exist.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'status': 'error', 'message': 'Internal server error', 'data': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# class CustomerAPIView(APIView):
#     authentication_classes = [CustomJWTAuthentication]
#     permission_classes = [IsRetailer]

#     def post(self, request):
#         try:
#             if 'customer_contact_no' in request.data:
#                 return self.verify_contact_no(request)
#             elif 'step' in request.data and 'customer_name' in request.data and 'customer_contact_no' in request.data:
#                 return self.create_customer(request)
#             elif 'customer_contact_no' in request.data and 'otp' in request.data:
#                 return self.verify_otp(request)
#             else:
#                 return self.get_customer(request)
#         except Exception as e:
#             return Response({'status': 'error', 'message': 'Internal server error.', 'data': str(e)},
#                             status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def verify_contact_no(self, request):
#         try:
#             customer_contact_no = request.data.get('customer_contact_no')
#             if not customer_contact_no:
#                 return Response({'status': 'fail', 'message': 'Contact number is required.'},
#                                 status=status.HTTP_400_BAD_REQUEST)

#             otp = get_random_string(length=6, allowed_chars='0123456789')
#             pg_customer_id = get_random_string(length=13)
#             try:
#                 customer = Customer.objects.get(customer_contact_no=customer_contact_no)
#                 customer.verify_code = otp
#                 customer.verify_code_expire_at = timezone.now() + timedelta(minutes=10)
#                 customer.save()
#             except Customer.DoesNotExist:
#                 Customer.objects.create(customer_contact_no=customer_contact_no, verify_code=otp,
#                                         verify_code_expire_at=timezone.now() + timedelta(minutes=10),
#                                         pg_customer_id=pg_customer_id)

#             data = {'otp': otp}
#             return Response({'status': 'success', 'message': 'OTP sent successfully.', 'data': data},
#                             status=status.HTTP_200_OK)

#         except Exception as e:
#             return Response({'status': 'error', 'message': 'Internal server error.', 'data': str(e)},
#                             status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def verify_otp(self, request):
#         try:
#             customer_contact_no = request.data.get('customer_contact_no')
#             otp = request.data.get('otp')

#             if not customer_contact_no or not otp:
#                 return Response({'status': 'fail', 'message': 'Contact number and OTP are required.'},
#                                 status=status.HTTP_400_BAD_REQUEST)

#             try:
#                 customer = Customer.objects.get(customer_contact_no=customer_contact_no)
#                 response_data = {
#                     'customer_name': customer.customer_name,
#                     'customer_email': customer.customer_email,
#                     'customer_contact_no': customer.customer_contact_no,
#                 }
#             except Customer.DoesNotExist:
#                 response_data = {}

#             if customer.verify_code == otp and customer.verify_code_expire_at > timezone.now():
#                 return Response(
#                     {'status': 'success', 'message': 'Customer verified successfully.', 'data': response_data},
#                     status=status.HTTP_200_OK)
#             else:
#                 return Response({'status': 'fail', 'message': 'Invalid OTP or OTP expired.'},
#                                 status=status.HTTP_400_BAD_REQUEST)

#         except Exception as e:
#             return Response({'status': 'error', 'message': 'Internal server error.', 'data': str(e)},
#                             status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def create_customer(self, request):
#         customer_name = request.data.get('customer_name')
#         customer_email = request.data.get('customer_email', None)
#         customer_contact_no = request.data.get('customer_contact_no')
#         step = request.data.get('step')
#         amount = request.data.get('amount', None)

#         try:
#             if not customer_name or not customer_contact_no:
#                 return Response({'status': 'fail', 'message': 'Customer name and contact number are required.'},
#                                 status=status.HTTP_400_BAD_REQUEST)

#             try:
#                 customer = Customer.objects.get(customer_contact_no=customer_contact_no)

#                 customer.customer_name = customer_name
#                 customer.customer_email = customer_email
#                 customer.save()
#             except Customer.DoesNotExist:
#                 Customer.objects.create(
#                     customer_name=customer_name,
#                     customer_email=customer_email,
#                     customer_contact_no=customer_contact_no,
#                 )

#             data = {
#                 'name': customer_name,
#                 'email': customer_email,
#                 'contact_no': customer_contact_no,
#                 'amount': amount,
#             }

#             if step == 'razorpay' and amount != None:
#                 response = create_razorpay_pg_order(request, data)

#             return Response(response)

#         except Exception as e:
#             return Response({'status': 'error', 'message': 'Internal server error.', 'data': str(e)},
#                             status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#     def get_customer(self, request):
#         try:
#             page_number = int(request.data.get('page_number', 1))
#             page_size = int(request.data.get('page_size', 10))

#             customers = Customer.objects.all()
#             paginator = Paginator(customers, page_size)

#             try:
#                 page_obj = paginator.page(page_number)
#             except EmptyPage:
#                 return Response({'status': 'fail', 'message': 'Invalid page number.'},
#                                 status=status.HTTP_400_BAD_REQUEST)

#             customer_serializer = CustomerSerializer(page_obj, many=True)

#             paginated_response_data = {
#                 'total_pages': paginator.num_pages,
#                 'current_page': page_obj.number,
#                 'total_items': paginator.count,
#                 'results': customer_serializer.data,
#             }

#             return Response({'status': 'success', 'message': 'Customer data retrieved successfully.',
#                              'data': paginated_response_data}, status=status.HTTP_200_OK)

#         except Exception as e:
#             return Response({'status': 'error', 'message': 'Internal server error.', 'data': str(e)},
#                             status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# def create_razorpay_pg_order(request, data):
#     name = data.get('name')
#     email = data.get('email')
#     contact_no = data.get('contact_no')
#     amount = data.get('amount')
#     currency = "INR"

#     api_key = "rzp_test_rEAW6ojdmqFEbn"
#     secret_key = "mPPJMnQtFd0o5Q1hKTXTgZSe"

#     try:
#         order_payload = {
#             "amount": float(amount) * 100,
#             "currency": currency
#         }

#         # scheme = "https" if request.is_secure() else "http"
#         callback_url = "admin_hub/payment-gateway/razorpay/verify/"

#         details = {
#             "api_key": api_key,
#             "name": name,
#             "email": email,
#             "contact_no": contact_no,
#             "callback_url": callback_url
#         }

#         url = "https://api.razorpay.com/v1/orders"

#         new_order_response = requests.post(url, auth=(api_key, secret_key), json=order_payload)

#         if new_order_response.status_code == 200:
#             details['order'] = json.loads(new_order_response.text)
#             response = {'status': 'success', 'data': details}

#         else:
#             details['order'] = json.loads(new_order_response.text)
#             response = {'status': 'fail', 'data': details}

#         return response
#     except Exception as e:
#         response = {'status': 'error', 'message': str(e)}

#         return response


# @authentication_classes([CustomJWTAuthentication])
# @permission_classes([IsRetailer])
# @parser_classes([MultiPartParser])
# @swagger_auto_schema(
#     tags=['Razorpay PG'],
#     manual_parameters=[
#         openapi.Parameter('razorpay_order_id', openapi.IN_FORM,
#                           type=openapi.TYPE_STRING, required=False),
#         openapi.Parameter('razorpay_payment_id', openapi.IN_FORM,
#                           type=openapi.TYPE_STRING, required=False),
#         openapi.Parameter('razorpay_signature', openapi.IN_FORM,
#                           type=openapi.TYPE_STRING, required=False),
#     ]
# )
# def verify_payment_gateway(self, request):
#     razorpay_order_id = request.data.get('razorpay_order_id')
#     razorpay_payment_id = request.data.get('razorpay_payment_id')
#     razorpay_signature = request.data.get('razorpay_signature')
#     method = request.data.get('method')

#     api_key = "rzp_test_rEAW6ojdmqFEbn"
#     secret_key = "mPPJMnQtFd0o5Q1hKTXTgZSe"

#     try:
#         with transaction.atomic():
#             if method == "POST":

#                 if 'razorpay_order_id' not in request.data or 'razorpay_payment_id' not in request.data or 'razorpay_signature' not in request.data or 'method' not in request.data:
#                     return Response(
#                         {'status': 'fail',
#                          'message': 'razorpay_order_id, razorpay_payment_id and razorpay_signature are required'},
#                         status=status.HTTP_400_BAD_REQUEST
#                     )

#                 params_dict = {
#                     'razorpay_order_id': razorpay_order_id,
#                     'razorpay_payment_id': razorpay_payment_id,
#                     'razorpay_signature': razorpay_signature
#                 }

#                 message = f"{razorpay_order_id}|{razorpay_payment_id}"
#                 generated_signature = hmac.new(api_key.encode(), message.encode(), hashlib.sha256).hexdigest()

#                 if generated_signature == razorpay_signature:

#                     url = "https://api.razorpay.com/v1/payments/{razorpay_payment_id}"

#                     payment_response = requests.get(url, auth=(api_key, secret_key))

#                     if payment_response.status_code == 200:
#                         return Response({'status': 'success', 'message': 'Payment is successful',
#                                          'response': payment_response.text}, status=status.HTTP_200_OK)

#                     else:
#                         return Response({'status': 'fail', 'data': payment_response.text},
#                                         status=payment_response.status_code)

#                 else:
#                     return Response({'status': 'fail', 'message': 'Signature verification failed'},
#                                     status=status.HTTP_404_NOT_FOUND)
#             else:
#                 return Response({'status': 'fail', 'message': 'Payment is failed'}, status=status.HTTP_404_NOT_FOUND)

#     except Exception as e:
#         return Response(
#             {'status': 'error', 'message': str(e)},
#             status=status.HTTP_500_INTERNAL_SERVER_ERROR
#         )


class DeviceAPIView(APIView):

    def post(self, request):
        if 'device_active' in request.data and 'number' in request.data:
            return self.add_device_number(request)
        else:
            return self.get_device_number(request)

    def add_device_number(self, request):
        load_dotenv()

        device_active = request.data.get('device_active')
        number = request.data.get('number')

        if not device_active or not number:
            return Response({"error": "Both device_active and number are required"}, status=status.HTTP_400_BAD_REQUEST)

        env_path = os.path.join(os.path.dirname(__file__), '../../.env')

        set_key(env_path, device_active, number)

        return Response({"message": f"'{device_active}' saved successfully"}, status=status.HTTP_200_OK)

    def get_device_number(self, request):

        device_active = request.data.get('device_active')

        load_dotenv()

        number = os.getenv(device_active)

        if number:
            return Response({device_active: number}, status=status.HTTP_200_OK)
        else:
            return Response({"error": "Key not found"}, status=status.HTTP_404_NOT_FOUND)


class SessionByPassUserAPIView(APIView):
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAdmin]

    def post(self, request):
        distributor_id = request.data.get('distributor_id')

        try:
            get_distributor = PortalUser.objects.get(id=distributor_id)

            access_token = get_tokens_for_user(get_distributor, timedelta(days=1))

            response_data = {
                'status': 'success',
                'message': 'Distributor Login successfully.',
                'data': {'user_role': get_distributor.pu_role, 'is_generated': False, 'token': str(access_token)}
            }

            return Response(response_data, status=status.HTTP_200_OK)

        except PortalUser.DoesNotExist:
            return Response(
                {'status': 'error', 'message': "Distributor not found."},
                status=status.HTTP_404_NOT_FOUND
            )

        except Exception as e:
            return Response(
                {'status': 'error', 'message': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class KYCVerifiedAPIView(APIView):
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsDistributor | IsRetailer]

    def post(self, request):
        try:
            if 'front_aadhaar_image' in request.data and 'back_aadhaar_image' in request.data and 'pan_card_image' in request.data and 'profile_image' in request.data and 'passbook_cheque_image' in request.data and 'upline_image' in request.data:
                return self.verify_kyc(request)
            elif 'shop_name' in request.data and 'email' in request.data and 'contact_number' in request.data and 'shop_address' in request.data and 'pin_code' in request.data and 'state' in request.data and 'city' in request.data and 'business_type' in request.data and 'shop_image' in request.data:
                return self.verify_shop(request)
            else:
                return Response({'status': 'error', 'message': 'Invalid request'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        except Exception as e:
            return Response({'status': 'error', 'message': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def verify_kyc(self, request):
        try:
            front_aadhaar_card = request.FILES.getlist('front_aadhaar_image')
            back_aadhaar_card = request.FILES.getlist('back_aadhaar_image')
            pan_card_image = request.FILES.getlist('pan_card_image')
            profile_image = request.FILES.getlist('profile_image')
            passbook_cheque_image = request.FILES.getlist('passbook_cheque_image')
            upline_image = request.FILES.getlist('upline_image')

            if not front_aadhaar_card: return Response({'status': 'fail', 'message': 'front aadhaar card image is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not back_aadhaar_card: return Response({'status': 'fail', 'message': 'back aadhaar card image is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not pan_card_image: return Response({'status': 'fail', 'message': 'pan card image is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not profile_image: return Response({'status': 'fail', 'message': 'profile image is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not passbook_cheque_image: return Response({'status': 'fail', 'message': 'passbook or cheque image is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not upline_image: return Response({'status': 'fail', 'message': 'upline image is required.'}, status=status.HTTP_400_BAD_REQUEST)


            required_files = [front_aadhaar_card, back_aadhaar_card, pan_card_image, profile_image, passbook_cheque_image, upline_image]
            file_names = ['Front Aadhaar Card', 'Back Aadhaar Card', 'PAN Card', 'Profile Image', 'Passbook/Cheque Image', 'Upline Image']
            keys = ['aadhaar_card_front', 'aadhaar_card_back', 'pan_card', 'profile_image', 'passbook_cheque_image', 'upline_image']

            # Check for missing files
            for idx, file in enumerate(required_files):
                if not file or len(file) == 0:
                    return Response({'status': 'error', 'message': f'{file_names[idx]} is missing'}, status=status.HTTP_400_BAD_REQUEST)

            user = PortalUser.objects.filter(id=request.user.id).first()
            if user.is_kyc_verify == True:
                return Response({'status': 'fail', 'message': 'KYC is already verified.'}, status=status.HTTP_400_BAD_REQUEST)
            
            folder_name = f'{user.pu_name}_{user.pu_contact_no}'

            def save_files(files, directory, keys):
                if not os.path.exists(directory):
                    os.makedirs(directory)

                file_dict = {}
                for idx, file in enumerate(files):
                    if not hasattr(file, 'name'):
                        return None

                    file_extension = file.name.split('.')[-1].lower()
                    if file_extension not in ['png', 'jpg', 'jpeg']:
                        return None

                    sanitized_file_name = file.name.replace(' ', '').replace('(', '').replace(')', '')
                    file_path = os.path.join(directory, sanitized_file_name)

                    # Save the file
                    with open(file_path, "wb") as f:
                        f.write(file.read())

                    # Store the URL in the dictionary with the key
                    file_url = f'http://{request.META["HTTP_HOST"]}/media/Kyc/Document/{sanitized_file_name}'
                    file_dict[keys[idx]] = file_url

                return file_dict

            # Save the files and store URLs in a dictionary
            docs_files = [front_aadhaar_card[0], back_aadhaar_card[0], pan_card_image[0], profile_image[0], passbook_cheque_image[0], upline_image[0]]
            user_directory = f'media/Kyc/Document/{folder_name}/'
            logo_image_urls_dict = save_files(docs_files, user_directory, keys)

            if not logo_image_urls_dict:
                return Response({'status': 'fail', 'message': 'Invalid file format. Only PNG, JPG, and JPEG files are allowed.'}, status=status.HTTP_400_BAD_REQUEST)

            # Save the image URLs in the user's details
            user_details = PortalUserDetails.objects.get(pu_id=request.user.id)
            user_details.doc_images = logo_image_urls_dict  # Save as dict
            user_details.save()

            data = {
                'contact_number': user.pu_contact_no,
                'email': user.pu_email
            }
            return Response({'status': 'success', 'message': 'KYC documents uploaded successfully.', 'data': data}, status=status.HTTP_200_OK)

        except PortalUser.DoesNotExist:
            return Response({'status': 'fail', 'message': 'portal user dose not exists.'}, status=status.HTTP_400_BAD_REQUEST)

        except PortalUserDetails.DoesNotExist:
            return Response({'status': 'fail', 'message': 'portal user details do not exist.'}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({'status': 'error', 'message': f"An u`nexpected error occurred: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


    def verify_shop(self, request):
        try:
            shop_name = request.data.get('shop_name')
            email = request.data.get('email')
            contact_number = request.data.get('contact_number')
            shop_address = request.data.get('shop_address')
            pin_code = request.data.get('pin_code')
            state = request.data.get('state')
            city = request.data.get('city')
            business_type = request.data.get('business_type')
            gst_no = request.data.get('gst_no', None)
            shop_image = request.FILES.get('shop_image')

            if not shop_name: return Response({'status': 'fail', 'message': 'shop name is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not email: return Response({'status': 'fail', 'message': 'email is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not contact_number: return Response({'status': 'fail', 'message': 'contact number is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not shop_address: return Response({'status': 'fail', 'message': 'shop address is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not pin_code: return Response({'status': 'fail', 'message': 'pin code is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not state: return Response({'status': 'fail', 'message': 'state is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not city: return Response({'status': 'fail', 'message': 'city is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not business_type: return Response({'status': 'fail', 'message': 'business type is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not shop_image: return Response({'status': 'fail', 'message': 'shop image is required.'}, status=status.HTTP_400_BAD_REQUEST)
            

            shop_name_validation = isstring(shop_name)
            if shop_name_validation == False:
                return Response({'status': 'fail', 'message': 'Invalid shop name. It should contain only alphabetic characters and spaces.'})

            email_validation = validation_email_address(email)
            if email_validation == False:
                return Response({'status': 'fail', 'message': 'Invalid email address.'}, status=status.HTTP_400_BAD_REQUEST)

            contact_number_validation = validate_mobile_number(contact_number)
            if contact_number_validation == False:
                return Response({'status': 'fail', 'message': 'Invalid Mobile Number.'}, status=status.HTTP_400_BAD_REQUEST)

            pin_code_validation = isnumber(pin_code)
            if pin_code_validation == False:
                return  Response({'status': 'fail', 'message': 'Invalid pin code. It must be a positive integer.'}, status=status.HTTP_400_BAD_REQUEST)

            if len(pin_code) != 6:
                return Response({'status': 'fail', 'message': 'Invalid pin code. It must be 6-digit numeric value.'}, status=status.HTTP_400_BAD_REQUEST)

            state_validation = isnumber(state)
            if state_validation == False:
                return Response({'status': 'fail', 'message': 'Invalid state. It must be a positive integer.'}, status=status.HTTP_400_BAD_REQUEST)

            city_validation = isnumber(city)
            if city_validation == False:
                return Response({'status': 'fail', 'message': 'Invalid city. It must be a positive integer.'}, status=status.HTTP_400_BAD_REQUEST)

            if gst_no:
                regex = r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$"
                if not re.match(regex, gst_no):
                    return Response({'status': 'fail', 'message': 'Invalid GST Number.'}, status=status.HTTP_400_BAD_REQUEST)

            busniess_type_validation = isnumber(business_type)
            if busniess_type_validation == False:
                return Response({'status': 'fail', 'message': 'Invalid business type. It must be a positive integer.'}, status=status.HTTP_400_BAD_REQUEST)

            if len(business_type) != 4:
                return Response({'status': 'fail', 'message': 'Invalid business type. It must be 4-digit numeric value.'}, status=status.HTTP_400_BAD_REQUEST)

            if PortalUser.objects.filter(pu_email=email).exclude(id=request.user.id).exists():
                return Response({'status': 'fail', 'message': 'Email address already exists.'}, status=status.HTTP_400_BAD_REQUEST)

            if PortalUser.objects.filter(pu_contact_no=contact_number).exclude(id=request.user.id).exists():
                return Response({'status': 'fail', 'message': 'Contact number already exists.'}, status=status.HTTP_400_BAD_REQUEST)

            user = PortalUser.objects.get(id=request.user.id)
            if user.is_kyc_verify == True:
                return Response({'status': 'fail', 'message': 'KYC is already verified.'}, status=status.HTTP_400_BAD_REQUEST)

            # user = PortalUser.objects.filter(id=request.user.id).first()
            # user.pu_email = email
            # user.pu_contact_no = contact_number
            # user.save()

            folder_name = f'{user.pu_name}_{user.pu_contact_no}'
            user_directory = f'media/Kyc/Document/{folder_name}/'

            def save_file(file, directory):
                if not os.path.exists(directory):
                    os.makedirs(directory)

                file_extension = file.name.split('.')[-1].lower()
                if file_extension not in ['png', 'jpg', 'jpeg']:
                    return None

                sanitized_file_name = file.name.replace(' ', '').replace('(', '').replace(')', '')
                file_path = os.path.join(directory, sanitized_file_name)

                with open(file_path, "wb") as f:
                    f.write(file.read())

                return f'http://{request.META["HTTP_HOST"]}/{directory}{sanitized_file_name}'

            if shop_image:
                new_image_url = save_file(shop_image, user_directory)
                if not new_image_url:
                    return Response({'status': 'fail', 'message': 'Invalid file format. Only PNG, JPG, and JPEG files are allowed.'}, status=status.HTTP_400_BAD_REQUEST)         
            else:
                new_image_url = None


            portal_user_details = PortalUserDetails.objects.get(pu_id=request.user.id)
            if gst_no:
                if portal_user_details.shop_gst_number==gst_no:
                    return Response({'status': 'fail', 'message': 'GST number is already exists.'}, status=status.HTTP_400_BAD_REQUEST)
            portal_user_details.shop_name=shop_name
            portal_user_details.shop_address=shop_address
            portal_user_details.shop_zip_code=pin_code
            portal_user_details.shop_state = state
            portal_user_details.shop_city = city
            portal_user_details.shop_gst_number = gst_no if gst_no else None
            portal_user_details.busniess_type = business_type
            portal_user_details.doc_images['shop_image'] = new_image_url
            portal_user_details.save()

            user.is_kyc_verify = True
            user.save()

            return Response({'status': 'success', 'message': 'Shop details Added successfully.'}, status=status.HTTP_200_OK)

        except PortalUser.DoesNotExist:
            return Response({'status': 'fail', 'message': 'portal user dose not exists'}, status=status.HTTP_400_BAD_REQUEST)

        except PortalUserDetails.DoesNotExist:
            return Response({'status': 'fail', 'message': 'portal user details dose not exists.'}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({'status': 'error', 'message': f'An unexpected error occurred: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        

class BankDetailsAPIView(APIView):
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAdmin | IsDistributor | IsRetailer]

    def post(self, request):
        try:
            if 'deposite_category' in request.data and 'bank_name' in request.data and 'ifsc_code' in request.data and 'branch_name' in request.data and 'account_type' in request.data and 'account_number' in request.data:
                return self.add_bank_details(request)
            elif 'page_size' in request.data or 'page_size' in request.data:
                return self.get_bank_details(request)
            else:
                return Response({'status': 'error', 'message': 'Invalid request'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        except Exception as e:
            return Response({'status': 'error', 'message': 'Internal server error.', 'data': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


    def add_bank_details(self, request):
        try:
            deposite_category = request.data.get('deposite_category')
            bank_name = request.data.get('bank_name')
            ifsc_code = request.data.get('ifsc_code')
            branch_name = request.data.get('branch_name')
            account_type = request.data.get('account_type')
            account_number = request.data.get('account_number')

            if not deposite_category: return Response({'status': 'fail', 'message': 'Deposite category is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not bank_name: return Response({'status': 'fail', 'message': 'Bank name is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not ifsc_code: return Response({'status': 'fail', 'message': 'IFSC code is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not branch_name: return Response({'status': 'fail', 'message': 'Branch name is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not account_type: return Response({'status': 'fail', 'message': 'Account Type is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not account_number: return Response({'status': 'fail', 'message': 'Account number is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
            deposite = json.loads(deposite_category)

            get_exists_bank = BankDetails.objects.filter(bank_name=bank_name, ifsc_code=ifsc_code, account_number=account_number, is_delete=False).first()
            if get_exists_bank:
                return Response({'status': 'fail', 'message': 'Bank details already exist.'}, status.HTTP_400_BAD_REQUEST)
            user = PortalUser.objects.get(id=request.user.id)
            BankDetails.objects.create(
                deposite_category=deposite,
                bank_name=bank_name,
                branch_name=branch_name,
                ifsc_code=ifsc_code,
                account_type=account_type,
                account_number=account_number,
                created_by=user
            )

            return Response({'status': 'success', 'message': 'Bank details added successfully.'}, status=status.HTTP_200_OK)

        except PortalUser.DoesNotExist:
            return Response({'status': 'fail', 'message': 'User dose not exists.'}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({'status': 'error', 'message': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    def get_bank_details(self, request):
        try:
            data = {
                'total_pages': 0,
                'current_page': 0,
                'total_items': 0,
                'results': []
            }
            deposite = {}
            get_bank_details = []
            page_size = int(request.data.get('page_size', 10))
            page_number = int(request.data.get('page_number', 1))
            bank_details_id = request.data.get('bank_details_id', None)
            depostie_category = request.data.get('depostie_category', None)
            search = request.data.get('search', None)

            if not page_size:
                return Response({'status': 'fail', 'message': 'Page size is required.'}, status=status.HTTP_400_BAD_REQUEST)

            get_bank_details = BankDetails.objects.filter(is_delete=False)

            if search is not None:

                # kishan: below condition commented because getting error during fetch data -- 11-11-2024

                # if not search:
                #     return Response({'status': 'fail', 'message': 'Search is required.'}, status=status.HTTP_400_BAD_REQUEST)

                get_bank_details = get_bank_details.filter(Q(bank_name__icontains=search) | Q(ifsc_code__icontains=search) | Q(account_number__icontains=search))
            
            if bank_details_id is not None:
                if not bank_details_id:
                    return Response({'status': 'fail', 'message': 'bank details ID is required.'}, status=status.HTTP_400_BAD_REQUEST)

                bank_id_validation = isnumber(bank_details_id)
                if bank_id_validation == False:
                    return Response({'status': 'fail', 'message': 'Invalid bank details ID. It should contain only digits.'})

                get_bank_detail = get_bank_details.filter(bd_id=bank_details_id).first()

                if get_bank_detail:
                    for key, value in get_bank_detail.deposite_category.items():
                        if value is True:
                            deposite[key] = value

                    result = {
                        'bank_details_id': get_bank_detail.bd_id,
                        'deposite_category': deposite,
                        'bank_name': get_bank_detail.bank_name,
                        'ifsc_code': get_bank_detail.ifsc_code,
                        'branch_name': get_bank_detail.branch_name,
                        'account_type': get_bank_detail.account_type,
                        'account_number': get_bank_detail.account_number
                    }

                    return Response({'status': 'success', 'data': result}, status=status.HTTP_200_OK)
                else:
                    return Response({'status': 'fail', 'message': 'Bank detail not found.'}, status=status.HTTP_404_NOT_FOUND)

            if depostie_category is not None:
                if not depostie_category:
                    return Response({'status': 'fail', 'message': 'depostie category is required.'}, status=status.HTTP_400_BAD_REQUEST)
                # print('====>', depostie_category)
                # deposite_category_validation = isstring(depostie_category)
                # print('===>', deposite_category_validation)
                # if deposite_category_validation == False:
                #     return Response({'status': 'fail', 'message': 'Invalid depostie category. It should be a string.'}, status=status.HTTP_400_BAD_REQUEST)

                filtered_bank_details = []

                for bank_details in get_bank_details:
                    keys = bank_details.deposite_category.items()
                    for key, value in keys:
                        if key == depostie_category and value==True:
                            filtered_bank_details.append(bank_details)

                get_bank_details = filtered_bank_details

            paginator = Paginator(get_bank_details, page_size)

            if page_number > paginator.num_pages:
                return Response({
                    'status': 'success',
                    'data': data
                }, status=status.HTTP_200_OK)

            page_obj = paginator.get_page(page_number)

            for bank_details in page_obj:
                deposite = {}
                for key, value in bank_details.deposite_category.items():
                    if value is True:
                        deposite[key] = value

                results = {
                    'bank_details_id': bank_details.bd_id,
                    'deposite_category': deposite,
                    'bank_name': bank_details.bank_name,
                    'ifsc_code': bank_details.ifsc_code,
                    'branch_name': bank_details.branch_name,
                    'account_type': bank_details.account_type,
                    'account_number': bank_details.account_number
                }
                data['results'].append(results)

            data['total_pages'] = paginator.num_pages
            data['current_page'] = page_number
            data['total_items'] = paginator.count

            return Response({'status': 'success', 'data': data}, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'status': 'error',
                'message': f'Internal server error: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    def delete(self, request):
        try:
            bank_details_id = request.data.get('bank_details_id')

            if not bank_details_id: return Response({'status': 'fail', 'message': 'bank details ID is required,'}, status=status.HTTP_400_BAD_REQUEST)

            bank_detail = BankDetails.objects.get(bd_id=bank_details_id, is_delete=False)
            bank_detail.is_delete = True
            bank_detail.save()
            return Response({'status': 'success', 'message': 'Bank Details deleted successfully.'}, status=status.HTTP_200_OK)

        except BankDetails.DoesNotExist:
            return Response({'status': 'fail', 'message': 'bank details dose not exists.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'status': 'error', 'message': 'Internal server error.', 'data': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class FundRequestAPIView(APIView):
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsAdmin | IsDistributor | IsRetailer]

    def post(self, request):
        try:
            if 'deposit_bank_id' in request.data and 'deposit_amount' in request.data:
                return self.add_fund_request(request)
            elif 'page_number' in request.data or 'page_size' in request.data:
                return self.fetch_fund_request(request)
            else:
                return Response({'status': 'error', 'message': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'status': 'error', 'message': 'Internal server error.', 'data': str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def add_fund_request(self, request):
        deposite_category = request.data.get('deposite_category')
        bd_id = request.data.get('deposit_bank_id')
        deposit_amount = request.data.get('deposit_amount')
        payment_proof = request.data.get('payment_proof')
        remark = request.data.get('remark')
        transaction_id = request.data.get('transaction_id')
        utr_number = request.data.get('utr_number')
        transaction_mode = request.data.get('transaction_mode')

        try:
            if not deposite_category: return Response({'status': 'fail','message': 'deposite_category is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not bd_id: return Response({'status': 'fail','message': 'bd_id is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not deposit_amount: return Response({'status': 'fail','message': 'deposit_amount is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not payment_proof: return Response({'status': 'fail','message': 'payment_proof is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not remark: return Response({'status': 'fail','message': 'remark is required.'}, status=status.HTTP_400_BAD_REQUEST)

            try:
                deposite_category_json = json.loads(deposite_category)
            except json.JSONDecodeError:
                return Response({'status': 'fail', 'message': 'Invalid deposite category format'}, status=status.HTTP_400_BAD_REQUEST)

            if isfloat(deposit_amount) == False: Response({'status': 'fail','message': 'Invalid desposit amount.'}, status=status.HTTP_400_BAD_REQUEST)
            if float(deposit_amount) < 0: Response({'status': 'fail','message': 'Desposit amount must be positive number.'}, status=status.HTTP_400_BAD_REQUEST)

            file_path = handle_uploaded_file(payment_proof, 'Retailer/PaymentProof') if payment_proof else None
            payment_proof_file_paths = {
                'payment_proof': file_path,
            }

            if deposite_category_json.get("counter_deposit") == True or deposite_category_json.get("cdm_deposit") == True:

                if not transaction_id: return Response({'status': 'fail','message': 'transaction_id is required.'}, status=status.HTTP_400_BAD_REQUEST)

                try:
                    bank_detail = BankDetails.objects.get(bd_id=bd_id)
                except BankDetails.DoesNotExist:
                    return Response({'status': 'fail', 'message': 'Bank does not exists.'}, status=status.HTTP_400_BAD_REQUEST)

                if len(transaction_id) < 12 or len(transaction_id) > 16: return Response({'status': 'fail', 'message': 'transaction_id length must be between 12 to 16.'}, status=status.HTTP_400_BAD_REQUEST)

                fund_request = FundRequest.objects.create(deposite_category=deposite_category_json, deposite_bank=bank_detail,
                                                          deposite_amount=deposit_amount, transaction_id=transaction_id, payment_proof=payment_proof_file_paths,
                                                          remark=remark, created_at=timezone.now(), created_by=request.user)

                return Response({"status": "success", "message": "Fund request generated successfully."}, status=status.HTTP_201_CREATED)

            elif deposite_category_json.get("online_transaction") == True:
                if not utr_number: return Response({'status': 'fail','message': 'utr_number is required.'}, status=status.HTTP_400_BAD_REQUEST)
                if not transaction_mode: return Response({'status': 'fail','message': 'transaction_mode is required.'}, status=status.HTTP_400_BAD_REQUEST)

                transaction_mode_list = ["IMPS", "RTGS", "NEFT"]
                if transaction_mode not in transaction_mode_list:
                    return Response({'status': 'fail','message': 'transaction_mode values must be following: IMPS, RTGS and NEFT'}, status=status.HTTP_400_BAD_REQUEST)

                try:
                    bank_detail = BankDetails.objects.get(bd_id=bd_id)
                except BankDetails.DoesNotExist:
                    return Response({'status': 'fail', 'message': 'Bank does not exists.'}, status=status.HTTP_400_BAD_REQUEST)

                # if len(utr_number) < 12 or len(utr_number) > 16: return  ({'status': 'fail', 'message': 'utr_number length must be between 12 to 16.'}, status=status.HTTP_400_BAD_REQUEST)

                fund_request = FundRequest.objects.create(deposite_category=deposite_category_json, deposite_bank=bank_detail,
                                                          deposite_amount=deposit_amount, utr_number=utr_number, payment_proof=payment_proof_file_paths,
                                                          transaction_mode=transaction_mode, remark=remark, created_at=timezone.now(),
                                                          created_by=request.user)

                return Response({"status": "success", "message": "Fund request generated successfully."}, status=status.HTTP_201_CREATED)

            else:
                return Response({'status': 'fail', 'message': 'At least one deposite category must be true.'}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({'status': 'error', 'message': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def fetch_fund_request(self, request):
        fr_id = request.data.get("fr_id")
        page_number = request.data.get('page_number', 1)
        page_size = request.data.get('page_size')

        try:
            if not page_size: return Response({'status': 'fail','message': 'page_size is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if isnumber(page_size) == False: return Response({'status': 'fail','message': 'page_size must contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)

            if page_number:
                if isnumber(page_number) == False: return Response({'status': 'fail','message': 'page_number must contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)

            if fr_id:
                if isnumber(fr_id) == False: return Response({'status': 'fail','message': 'fr_id must contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)

            if request.user.pu_role == "ADMIN":
                queryset = FundRequest.objects.filter(is_delete=False)
            else:
                queryset = FundRequest.objects.filter(is_delete=False, created_by=request.user.pk)

            if fr_id:
                queryset = queryset.filter(pk=fr_id)

            queryset = queryset.order_by('-pk')

            paginator = Paginator(queryset, page_size)
            try:
                page_obj = paginator.page(page_number)
            except EmptyPage:
                return Response({
                    'status': 'fail',
                    'message': 'Page not found.',
                    'data': {}
                }, status=status.HTTP_404_NOT_FOUND)

            if page_obj is not None:
                if not queryset.exists():
                    paginated_response_data = {
                        'total_pages': 0,
                        'current_page': 0,
                        'total_items': 0,
                        'results': []
                    }
                    response_data = {
                        'status': 'fail',
                        'message': 'Fund request Data not found.',
                        'data': paginated_response_data
                    }
                    return Response(response_data, status=status.HTTP_200_OK)
                serializer = FundRequestSerializer(page_obj.object_list, many=True, context={'request': request})
                paginated_response_data = {
                    'total_pages': paginator.num_pages,
                    'current_page': page_obj.number,
                    'total_items': paginator.count,
                    'results': serializer.data
                }
                return Response({
                    'status': 'success',
                    'message': 'Fund request data',
                    'data': paginated_response_data
                }, status=status.HTTP_200_OK)

            serializer = FundRequestSerializer(queryset, many=True, context={'request': request})
            response_data = {
                'status': 'success',
                'message': 'Fund request data',
                'data': serializer.data
            }
            return Response(response_data, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'status': 'fail',
                'message': str(e),
                'data': {}
            }, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request):
        try:
            if 'fr_id' in request.data and 'request_status' in request.data or 'reason' in request.data:
                return self.fund_request_approve(request)
            elif 'fr_id' in request.data and 'deposit_bank_id' in request.data and 'deposite_category' in request.data:
                return self.fund_request_update(request)
            else:
                return Response({'status': 'error', 'message': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'status': 'error', 'message': 'Internal server error.', 'data': str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def fund_request_approve(self, request):
        try:
            fr_id = request.data.get("fr_id")
            request_status = request.data.get("request_status")
            reason = request.data.get("reason")

            if not fr_id: return Response({'status': 'fail', 'message': 'fr_id is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not request_status: return Response({'status': 'fail', 'message': 'request_status is required.'}, status=status.HTTP_400_BAD_REQUEST)

            get_fund_request = FundRequest.objects.get(fr_id=fr_id)
            if get_fund_request.request_status == "REJECTED" or get_fund_request.request_status == "REVERSED": 
                return Response({'status': 'fail', 'message': 'Fund request has already been processed.'}, status=status.HTTP_400_BAD_REQUEST)
            
            if request_status == "APPROVED" and get_fund_request.request_status != "PENDING":
                return Response({'status': 'fail', 'message': 'Fund request has already been processed.'}, status=status.HTTP_400_BAD_REQUEST)

            if request_status == "REVERSED" and get_fund_request.request_status != "APPROVED": 
                return Response({'status': 'fail', 'message': 'Only requests with "APPROVED" status can be reversed.'}, status=status.HTTP_400_BAD_REQUEST)
            
            deposit_amount = get_fund_request.deposite_amount
            request_user = get_fund_request.created_by

            try:
                get_portal_user_wallet = PortalUserWallet.objects.get(pu=request_user)
            except PortalUserWallet.DoesNotExist:
                return Response({'status': 'fail', 'message': 'PortalUser wallet not exists.'},
                            status=status.HTTP_404_NOT_FOUND)
            
            if request_status == "APPROVED" and get_fund_request.request_status == "PENDING":

                main_wallet_amount = get_portal_user_wallet.main_wallet
                get_portal_user_wallet.main_wallet = main_wallet_amount + deposit_amount
                get_portal_user_wallet.save()

                get_fund_request.request_status = request_status
                get_fund_request.reason = reason
                get_fund_request.save()

                return Response({'status': 'success', 'message': 'Fund request accept successfully.'},
                            status=status.HTTP_200_OK)

            elif request_status == "REVERSED" and get_fund_request.request_status == "APPROVED":

                main_wallet_amount = get_portal_user_wallet.main_wallet
                get_portal_user_wallet.main_wallet = main_wallet_amount - deposit_amount
                get_portal_user_wallet.save()

                get_fund_request.request_status = request_status
                get_fund_request.reason = reason
                get_fund_request.save()

                return Response({'status': 'success', 'message': 'Fund request reverse successfully.'},
                            status=status.HTTP_200_OK)  
            
            elif request_status == "REJECTED":
                get_fund_request.request_status = request_status
                get_fund_request.reason = reason
                get_fund_request.save()

                return Response({'status': 'success', 'message': 'Fund request reject successfully.'},
                            status=status.HTTP_200_OK)
            
            else:
                return Response({'status': 'fail', 'message': 'Invalid request status.'},
                            status=status.HTTP_400_BAD_REQUEST) 

        except FundRequest.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Fund request record not exists.'},
                            status=status.HTTP_404_NOT_FOUND) 

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def fund_request_update(self, request):
        fr_id = request.data.get('fr_id')
        deposite_category = request.data.get('deposite_category')
        bd_id = request.data.get('deposit_bank_id')
        deposit_amount = request.data.get('deposit_amount')
        payment_proof = request.data.get('payment_proof', None)
        remark = request.data.get('remark')
        transaction_id = request.data.get('transaction_id')
        utr_number = request.data.get('utr_number')
        transaction_mode = request.data.get('transaction_mode')

        try:
            if not fr_id: return Response({'status': 'fail','message': 'fr_id is required.'}, status=status.HTTP_400_BAD_REQUEST)
            fund_request_queryset = FundRequest.objects.get(fr_id=fr_id, is_delete=False)
            if fund_request_queryset.created_by.pk != request.user.pk: return Response({"status": "fail", "message": "Unauthorized to update fund request."}, status=status.HTTP_401_UNAUTHORIZED)
            if fund_request_queryset.request_status != "PENDING": return Response({"status": "fail", "message": "Fund request has already been processed"}, status=status.HTTP_400_BAD_REQUEST)
            
            if not deposite_category: return Response({'status': 'fail','message': 'deposite_category is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not bd_id: return Response({'status': 'fail','message': 'bd_id is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not deposit_amount: return Response({'status': 'fail','message': 'deposit_amount is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not remark: return Response({'status': 'fail','message': 'remark is required.'}, status=status.HTTP_400_BAD_REQUEST)            

            try:
                deposite_category_json = json.loads(deposite_category)
            except json.JSONDecodeError:
                return Response({'status': 'fail', 'message': 'Invalid deposite category format'}, status=status.HTTP_400_BAD_REQUEST)

            if not isfloat(deposit_amount): Response({'status': 'fail','message': 'Invalid desposit amount.'}, status=status.HTTP_400_BAD_REQUEST)
            if float(deposit_amount) < 0: Response({'status': 'fail','message': 'Desposit amount must be positive number.'}, status=status.HTTP_400_BAD_REQUEST)

            if payment_proof:
                file_path = handle_uploaded_file(payment_proof, 'Retailer/PaymentProof') if payment_proof else None
                payment_proof_file_paths = {'payment_proof': file_path}

            bank_detail = BankDetails.objects.get(bd_id=bd_id)
            
            if deposite_category_json.get("counter_deposit") == True or deposite_category_json.get("cdm_deposit") == True:
                if not transaction_id: return Response({'status': 'fail','message': 'transaction_id is required.'}, status=status.HTTP_400_BAD_REQUEST)
                if len(transaction_id) < 12 or len(transaction_id) > 16: return Response({'status': 'fail', 'message': 'transaction_id length must be between 12 to 16.'}, status=status.HTTP_400_BAD_REQUEST)

                fund_request_queryset.deposite_category = deposite_category_json
                fund_request_queryset.deposite_bank = bank_detail
                fund_request_queryset.deposite_amount = deposit_amount
                fund_request_queryset.transaction_id = transaction_id
                if payment_proof:
                    fund_request_queryset.payment_proof = payment_proof_file_paths
                fund_request_queryset.remark = remark
                fund_request_queryset.save()

                return Response({"status": "success", "message": "Fund request updated successfully."}, status=status.HTTP_200_OK)

            elif deposite_category_json.get("online_transaction") == True:
                if not utr_number: return Response({'status': 'fail','message': 'utr_number is required.'}, status=status.HTTP_400_BAD_REQUEST)
                if not transaction_mode: return Response({'status': 'fail','message': 'transaction_mode is required.'}, status=status.HTTP_400_BAD_REQUEST)

                transaction_mode_list = ["IMPS", "RTGS", "NEFT"]
                if transaction_mode not in transaction_mode_list:
                    return Response({'status': 'fail','message': 'transaction_mode values must be following: IMPS, RTGS and NEFT'}, status=status.HTTP_400_BAD_REQUEST)

                # if len(utr_number) < 12 or len(utr_number) > 16: return  ({'status': 'fail', 'message': 'utr_number length must be between 12 to 16.'}, status=status.HTTP_400_BAD_REQUEST)

                fund_request_queryset.deposite_category = deposite_category_json
                fund_request_queryset.deposite_bank = bank_detail
                fund_request_queryset.deposite_amount = deposit_amount
                fund_request_queryset.utr_number = utr_number
                fund_request_queryset.transaction_mode = transaction_mode
                if payment_proof:
                    fund_request_queryset.payment_proof = payment_proof_file_paths
                fund_request_queryset.remark = remark
                fund_request_queryset.save()

                return Response({"status": "success", "message": "Fund request updated successfully."}, status=status.HTTP_200_OK)
            else:
                return Response({'status': 'fail', 'message': 'At least one deposite category must be true.'}, status=status.HTTP_400_BAD_REQUEST)
            
        except BankDetails.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Bank does not exists.'}, status=status.HTTP_404_NOT_FOUND)
        except FundRequest.DoesNotExist:
            return Response({"status": "fail", "message": "Fund request does not exist."},status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'status': 'error', 'message': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def delete(self, request):
        try:
            fr_id = request.data.get('fr_id')

            if not fr_id: return Response({'status': 'fail', 'message': 'fr_id is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not isnumber(fr_id): return Response({'status': 'fail','message': 'fr_id must contain only digits.'}, status=status.HTTP_400_BAD_REQUEST)

            queryset = FundRequest.objects.get(fr_id=fr_id, is_delete=False)
            if queryset.created_by.pk != request.user.pk: return Response({"status": "fail", "message": "Unauthorized to delete fund request."}, status=status.HTTP_401_UNAUTHORIZED)

            if queryset.request_status == "PENDING":
                queryset.is_delete = True
                queryset.is_deactive = True
                queryset.save()

                return Response({'status': 'success', 'message': 'Fund request deleted successfully.'}, status=status.HTTP_200_OK)
            else:
                return Response({'status': 'fail', 'message': 'Only requests with a pending status can be deleted.'}, status=status.HTTP_400_BAD_REQUEST)

        except FundRequest.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Fund request dose not exists.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'status': 'error', 'message': 'Internal server error.', 'data': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class RetailerDynamicServiceProviderAPIView(APIView):
    authentication_classes=[CustomJWTAuthentication]
    permission_classes = [IsRetailer]

    def post(self, request):
        sp_id = request.data.get('sp_id')

        if not sp_id:
            return Response({'status': 'fail', 'message': 'sp_id is reqired.'}, status=status.HTTP_400_BAD_REQUEST)
        
        user = request.user.id

        try:
            portal_user_charges = PortalUserCharges.objects.filter(pu_id=user)
            
            for charges in portal_user_charges:
                service_provider = AdServiceProvider.objects.get(sp_id=sp_id)
                existing_pinned = PortalUserCharges.objects.filter(pu_id=user, is_pinned=True)
                if charges.sp == service_provider:
                    
                    if charges.is_pinned == False:
                        if len(existing_pinned) >= 7:    
                            return Response({'status': 'fail', 'message': 'You can only pin a maximum of 7 service providers.'}, status=status.HTTP_400_BAD_REQUEST)
                        
                        charges.is_pinned = True
                        charges.save()

                        return Response({'status': 'success', 'message': 'Service provider pinned successfully.'}, status=status.HTTP_200_OK)
                    
                    if charges.is_pinned == True:
                        charges.is_pinned = False
                        charges.save()

                        return Response({'status': 'success', 'message': 'Service provider unpinned successfully.'}, status=status.HTTP_200_OK)

                else:
                    # return Response({'status': 'fail', 'message': 'This service provider is not associated with your account.'}, status=status.HTTP_404_NOT_FOUND)
                    pass
            
            return Response({'status': 'fail', 'message': 'No existing charges found for this user.'}, status=status.HTTP_404_NOT_FOUND)

        except AdServiceProvider.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Service provider dose not exists.'}, status=status.HTTP_404_NOT_FOUND)    

        except PortalUserCharges.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Portal user charges dose not exists.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def get(self, request):
        user_id = request.user.id

        try:
            all_service_provider = AdServiceProvider.objects.filter(is_deleted=False)
            portal_user_charges = PortalUserCharges.objects.filter(pu_id=user_id)
            service_provider_list = []

            for service in all_service_provider:
                for charges in portal_user_charges:
                    if charges.sp == service:
                        exists_portal_user_charges = PortalUserCharges.objects.filter(sp=service, pu_id=user_id).first()
                        if exists_portal_user_charges:
                            pass

                        service_provider_data = {
                            'sp_id': service.sp_id,
                            'sp_name': service.sp_name,
                            'label': service.label,
                            'hsn_sac_id': service.hsn_sac.hsnsac_id if service.hsn_sac.hsnsac_id else None,
                            'hsn_sac_name': service.hsn_sac.hsnsac_code,
                            'service_id': service.service.service_id,
                            'service_name': service.service.service_name,
                            'tds_rate': service.tds_rate,
                            'is_pinned': charges.is_pinned,
                            'is_access': True if exists_portal_user_charges else False
                        }
                        service_provider_list.append(service_provider_data)

            return Response({'status': 'success', 'message': 'Get all service provider.', 'data': {'results': service_provider_list}})

        except PortalUserCharges.DoesNotExist:
            return Response({'stauts': 'fail', 'message': 'Portal user service provider dose not exists.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class WalletAPIView(APIView):
    authentication_classes=[CustomJWTAuthentication]
    permission_classes=[IsRetailer | IsDistributor]

    def post(self, request):
        try:
            if 'from_wallet' in request.data and 'description' in request.data and 'amount' in request.data:
                return self.wallet_to_wallet(request)
            elif 'contact_no' in request.data and 'amount' in request.data and 'from_wallet' in request.data:
                return self.wallet_to_other_wallet(request)
            elif 'contact_no' in request.data:
                return self.get_data_contact_number(request)
            elif 'wallet' in request.data:
                return self.get_wallet_transaction(request)
            else:
                return Response({'status': 'fail', 'message': 'Invalid request data.'}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def wallet_to_wallet(self, request):
        try:
            from_wallet = request.data.get('from_wallet')
            description = request.data.get('description')
            amount = request.data.get('amount')
            to_wallet = 'main_wallet'

            main_wallet = 'main_wallet'

            if not from_wallet:
                return Response({'status': 'fail', 'message': 'from_wallet is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not description:
                return Response({'status': 'fail', 'message': 'description is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not amount:
                return Response({'status': 'fail', 'message': 'amount is required.'}, status=status.HTTP_400_BAD_REQUEST)
            
            validation_ammount = isnumber(amount)
            if validation_ammount == False:
                return Response({'status': 'fail', 'message': 'Invalid amount. It must be a positive integer.'}, status=status.HTTP_400_BAD_REQUEST)
            
            from_wallet_validation = isstring(from_wallet)
            if from_wallet_validation == False:
                return Response({'status': 'fail', 'message': 'Invalid from wallet. It should contain only alphabetic characters.'}, status=status.HTTP_400_BAD_REQUEST)
            
            description_validation = isstring(description)
            if description_validation == False:
                return Response({'status': 'fail', 'message': 'Invalid description. It should contain only alphabetic characters.'}, status=status.HTTP_400_BAD_REQUEST)

            amount = Decimal(amount)

            if main_wallet == to_wallet or main_wallet == from_wallet:

                if main_wallet == to_wallet and main_wallet == from_wallet:
                    return Response({'status': 'fail', 'message': f'Either from_wallet and to_wallet must be {main_wallet}.'}, status=status.HTTP_400_BAD_REQUEST)

                user = request.user.id
                retailer = PortalUser.objects.get(id=user, is_deleted=False)
                retailer_details = PortalUserDetails.objects.get(pu=retailer)
                user_wallet = PortalUserWallet.objects.get(pu=retailer)

                if getattr(user_wallet, from_wallet) < amount:
                    return Response({'status': 'fail', 'message': f'Insufficient funds in {from_wallet}.', 'is_success': False}, status=status.HTTP_400_BAD_REQUEST)

                setattr(user_wallet, from_wallet, getattr(user_wallet, from_wallet) - amount)
                setattr(user_wallet, to_wallet, getattr(user_wallet, to_wallet) + amount)

                user_wallet.save()
                timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
                label = f'{retailer_details.pud_unique_id}_{from_wallet}_DR_To_{to_wallet}_CR_Internal_{timestamp}'
                print('====>', label)
                wallet_transaction = {'CR': main_wallet, 'DR': from_wallet}
                for key, value in wallet_transaction.items():
                    WalletTrn.objects.create(
                        action_type='Internal',
                        pu=retailer,
                        wl_label=label,
                        effectvie_wallet=value,
                        effectvie_amt=amount,
                        effective_type=key,
                        wl_trn_dt=timezone.now()
                    )
                
                return Response({'status': 'success', 'message': f'{amount} transferred from {from_wallet} to {to_wallet}.', 'is_success': True}, status=status.HTTP_200_OK)

            else:
                return Response({'status': 'fail', 'message': f'Either from_wallet or to_wallet must be {main_wallet}.'}, status=status.HTTP_400_BAD_REQUEST)

        except PortalUser.DoesNotExist:
            return Response({'status': 'fail', 'message': 'User does not exist.'}, status=status.HTTP_404_NOT_FOUND)
        except PortalUserWallet.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Wallet not found for the user.'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def get_data_contact_number(self, request):
        try:
            contact_number = request.data.get('contact_no')

            if not contact_number: return Response({'status': 'fail', 'message': 'contact number is required.'}, status=status.HTTP_400_BAD_REQUEST)

            validation_contact_number = validate_mobile_number(contact_number)
            if validation_contact_number == False:
                return Response({'status': 'fail', 'message': 'Invalid Mobile Number.'}, status=status.HTTP_400_BAD_REQUEST)

            get_data = PortalUser.objects.get(pu_contact_no=contact_number, is_deleted=False)
            UserSerializer = PortalUserSerializer(get_data)

            return Response({'status': 'success', 'message': 'user data get successfully.', 'data': UserSerializer.data}, status=status.HTTP_200_OK)

        except PortalUser.DoesNotExist:
            return Response({'status': 'fail', 'message': 'user dose not exists.', 'data': []}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def wallet_to_other_wallet(self, request):
        try:
            contact_no = request.data.get('contact_no')
            amount = request.data.get('amount')
            from_wallet = request.data.get('from_wallet')

            if not contact_no: return Response({'status': 'fail', 'message': 'contact no is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not amount: return Response({'status': 'fail', 'message': 'amount is required.'}, status=status.HTTP_400_BAD_REQUEST)
            if not from_wallet: return Response({'status': 'fail', 'message': 'from wallet is required.'}, status=status.HTTP_400_BAD_REQUEST)

            validation_contact_number = validate_mobile_number(contact_no)
            if validation_contact_number == False:
                return Response({'status': 'fail', 'message': 'Invalid Mobile Number.'}, status=status.HTTP_400_BAD_REQUEST)
            
            validation_amount = isnumber(amount)
            if validation_amount == False:
                return Response({'status': 'fail', 'message': 'Invalid amount. It must be a positive integer.'}, status=status.HTTP_400_BAD_REQUEST)
            
            from_Wallet_validation = isstring(from_wallet)
            if from_Wallet_validation == False:
                return Response({'status': 'fail', 'message': 'Invalid from wallet. It should contain only alphabetic characters.'}, status=status.HTTP_400_BAD_REQUEST)

            amount = Decimal(amount)
            main_wallet = 'main_wallet'

            get_user = PortalUser.objects.get(pu_contact_no=contact_no, is_deleted=False)

            if request.user.id == get_user.id:
                return Response({'status': 'fail', 'message': 'Self-transfer is not allowed. You cannot transfer funds to your own wallet.', 'is_success': False}, status=status.HTTP_400_BAD_REQUEST)

            from_user_wallet = PortalUserWallet.objects.get(pu=get_user)
            to_user_wallet = PortalUserWallet.objects.get(pu=request.user.id)
            from_wallet_balance = Decimal(getattr(to_user_wallet, from_wallet))

            if from_wallet_balance < amount:
                return Response({'status': 'fail', 'message': f'Insufficient funds in {from_wallet}.', 'is_success': False}, status=status.HTTP_400_BAD_REQUEST)

            setattr(from_user_wallet, main_wallet, Decimal(getattr(from_user_wallet, main_wallet)) + amount)
            setattr(to_user_wallet, from_wallet, from_wallet_balance - amount)

            from_user_wallet.save()
            to_user_wallet.save()

            return Response({
                'status': 'success',
                'message': f'{amount} transferred from {from_wallet} of to_user_wallet to {main_wallet} of from_user_wallet.',
                'is_success': True
            }, status=status.HTTP_200_OK)

        except PortalUserWallet.DoesNotExist:
            return Response({'status': 'fail', 'message': 'user wallet dose not exists'}, status=status.HTTP_404_NOT_FOUND)

        except PortalUser.DoesNotExist:
            return Response({'status': 'fail', 'message': 'user dose not exists.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def get_wallet_transaction(self, request):
        data = {
            "total_pages": 0,
            "current_page": 0,
            "total_items": 0,
            "results": []
        }
        page_number = request.data.get('page_number', 1)
        page_size = request.data.get('page_size', 10)
        wallet_name = request.data.get('wallet', None)
        page_size = int(page_size)
        page_number = int(page_number)

        all_wl_data = 'Wallet'
        user = request.user.id
        try:
            retailer = PortalUser.objects.get(id=user, is_deleted=False)
            if not wallet_name:
                filter_wallet_transaction = WalletTrn.objects.filter(pu=retailer)
            else:
                wallet_name_validation = isstring(wallet_name)
                if wallet_name_validation == False:
                    return Response({'status': 'fail', 'message': 'Invalid wallet name. It should contain only alphabetic characters.'}, status=status.HTTP_400_BAD_REQUEST)

                if wallet_name not in ['main_wallet', 'cashin_wallet', 'pg_wallet', 'commission_wallet']:
                    return Response({'status': 'fail', 'message': 'Invalid wallet name. Please choose from main_wallet, cashin_wallet, pg_wallet, or commission_wallet.'}, status=status.HTTP_400_BAD_REQUEST)
                if not wallet_name:
                    return Response({'status': 'fail', 'message': 'wallet name is required.'}, status=status.HTTP_400_BAD_REQUEST)
                filter_wallet_transaction = WalletTrn.objects.filter(pu=retailer, effectvie_wallet=wallet_name)

            start_index = (page_number - 1) * page_size
            end_index = start_index + page_size
            paginated_wallet_transaction = filter_wallet_transaction[start_index:end_index]
            total_items = filter_wallet_transaction.count()
            total_pages = (len(filter_wallet_transaction) + page_size - 1) // page_size
            serializer = WalletTrnSerializer(paginated_wallet_transaction, many=True)
            data = {
                'total_pages': total_pages,
                'current_page': page_number,
                'total_items': total_items,
                'results': serializer.data
            }

            return Response({'status': 'success', 'message': f'Get all {wallet_name if wallet_name else all_wl_data} transaction.', 'data': data}, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PortalUsertWalletAPIView(APIView):
    authentication_classes = [CustomJWTAuthentication]
    permission_classes = [IsRetailer | IsDistributor]

    def get(self, request):
        try:
            user = request.user.id
            wallet_data = []
            user = PortalUser.objects.get(id=user)
            user_wallet = PortalUserWallet.objects.filter(pu_id=user)
            if user.pu_role == 'RETAILER':
                for wallet in user_wallet:
                    wallet_dict = {
                        'main_wallet': wallet.main_wallet,
                        'commission_wallet': wallet.commission_wallet,
                        'pg_wallet': wallet.pg_wallet,
                        'cashin_wallet': wallet.cashin_wallet
                    }
                    wallet_data.append(wallet_dict)
            else:
                for wallet in user_wallet:
                    wallet_dict = {
                        'main_wallet': wallet.main_wallet,
                        'commission_wallet': wallet.commission_wallet
                    }
                    wallet_data.append(wallet_dict)
             
            data = {'results': wallet_data}
            
            return Response({'status': 'success', 'message': f'Get {user.pu_role} wallet and balance.', 'data': data}, status=status.HTTP_200_OK)
        except PortalUser.DoesNotExist:
            return Response({'status': 'fail', 'message': 'Portal user dose not exists.'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'status': 'error', 'message': f'Internal server error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
