from django.urls import path
from .views import *
from .payout_service import *
from .commission_calculations import *

urlpatterns = [
    # Auth Module
    path('auth/verify-contact/', VerifyContactNoAPIView.as_view()),
    path('auth/verify-code/', VerifyCodeAPIView.as_view()),
    path('auth/verify-distributor-details/', VerifyDistributorDetailsAPIView.as_view()),
    path('auth/verify-retailer-details/', VerifyRetailerDetailsAPIView.as_view()),
    path('auth/user-authenticate/', AuthHandlerAPIView.as_view()),
    path('auth/user-login/', UserLoginAPIView.as_view()),

    # kyc verfied api
    path('kyc/kyc-verified/', KYCVerifiedAPIView.as_view()),
    
    # HSN/SAC Module
    path('master/hsn-sac/', HsnSacAPIView.as_view()),

    # Service Module
    path('master/service/', ServiceAPIView.as_view()),

    # Service Provider Module
    path('master/service-provider/', ServiceProviderAPIView.as_view()),

    # User Profile Module
    path('profile/user-profile/', UserProfileAPIView.as_view()),

    # Partner Cateogry Module
    path('partners/partner-category/', PartnerCategoryAPIView.as_view()),

    # Retailer Bank Module
    # path('retailer/bank-accounts', RetailerBankAPIView.as_view()),

    # CashFree Payout APIs
    path('payout/cf/', CfPayOutAPIView.as_view()),
    #customer payout bank account
    path('payout/beneficiary/', CfPayoutBeneficiaryAPIView.as_view()),
    # path('payout/cashfree/', CashfreePayoutAPIView.as_view()),
    # path('payout/csfr/', CsfrPayoutAPIView.as_view()),

    # Razorpay Payment Gateway APIs
    # path('payment-gateway/razorpay/', RazorpayPaymentAPIView.as_view()),

    # CashFree Payment Gateway APIs
    # path('payment-gateway/cashfree/', CashfreePaymentAPIView.as_view()),

    # Razorpay Payment Gateway APIs
    # path('payment-gateway/razorpay/', verify_payment_gateway),
    # path('payment-gateway/razorpay/verify/', verify_razorpay_payment_gateway),

    # Partner/Downline
    path('partners/partner/', PartnerAPIView.as_view()),
    path('users/user/', UserAPIView.as_view()),

    # Fund Request from Distributor/Retailer
    path('retailers/fund-request/', FundRequestAPIView.as_view()),

    # Retailer
    path('retailers/retailer/', RetailerAPIView.as_view()),

    # customer creation and view
    # path('customers/customer/', CustomerAPIView.as_view()),

    # get device active
    path('device/', DeviceAPIView.as_view()),

    # switching portal module
    path('sesionbypass/session-bypass-user/', SessionByPassUserAPIView.as_view()),

    #bank details
    path('banks/bank-details/', BankDetailsAPIView.as_view()),

    #wallet to wallet 
    path('wallet/wallet-transaction/', WalletAPIView.as_view()),

    # retailer dynamic tabs
    path('retailers/dynamic-service-provider/', RetailerDynamicServiceProviderAPIView.as_view()),

    # portal user wallet 
    path('users/user-wallet/', PortalUsertWalletAPIView.as_view()),

]
