import requests
from rest_framework import status
from django.utils.crypto import get_random_string

client_id = 'CF449777CRQG8U0O577S73AHL800'
client_secret = 'cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b'

def aadhaar_verify(aadhaar_card):
    aadhaar_url = "https://api.cashfree.com/verification/offline-aadhaar/otp"

    aadhaar_payload = { "aadhaar_number": aadhaar_card }
    aadhaar_headers = {
        "accept": "application/json",
        "content-type": "application/json",
        "x-client-id": client_id,
        "x-client-secret": client_secret
    }

    aadhaar_response = requests.post(aadhaar_url, json=aadhaar_payload, headers=aadhaar_headers)

    res = aadhaar_response.json()
    if aadhaar_response.status_code == 200:

        response_data = {   'status': status.HTTP_200_OK,
                            'data': {
                                'status': 'success',
                                'message': 'OTP sent successfully',
                                'is_final': False,
                                'data': {'aadhaar_otp': 267987, 'ref_id': res['ref_id']}
                            }
                        }
        
    else:
        response_data = {
            'status': aadhaar_response.status_code,
            'data': res  
        }
    return response_data


def aadhaar_otp_verify(aadhaar_otp, ref_id):
    otp_url = "https://api.cashfree.com/verification/offline-aadhaar/verify"

    otp_payload = {
        "otp": aadhaar_otp,
        "ref_id": ref_id
    }
    otp_headers = {
        "accept": "application/json",
        "content-type": "application/json",
        "x-client-id": client_id,
        "x-client-secret": client_secret
    }

    otp_response = requests.post(otp_url, json=otp_payload, headers=otp_headers)

    res = otp_response.json()
    if otp_response.status_code == 200:

        response_data = {   'status': status.HTTP_200_OK,
                            'data': {
                                'status': 'success',
                                'message': 'Aadhaar verified successfully',
                                'is_final': False,
                            }
                        }
    else:
        response_data = {
            'status': otp_response.status_code,
            'data': res
        }
    return response_data


def verify_pan_card(pan_card):
    pan_url = "https://api.cashfree.com/verification/pan/advance"

    pan_payload = {
        "pan": pan_card,
        "verification_id": get_random_string(length=10)
    }
    pan_headers = {
        "accept": "application/json",
        "content-type": "application/json",
        "x-client-id": "CF449777CRQG8U0O577S73AHL800",
        "x-client-secret": "cfsk_ma_prod_cc00245b0b0baa6a900984e8ecaab99f_9f28681b"
    }

    pan_response = requests.post(pan_url, json=pan_payload, headers=pan_headers)

    res = pan_response.json()
    if pan_response.status_code == 200:

        response_data = {   'status': status.HTTP_200_OK,
                            'data': {
                                'status': 'success',
                                'message': 'Pan verified successfully',
                                'is_final': False,
                                'data': res
                            }                            
                        }
    else:
        response_data = {
            'status': pan_response.status_code,
            'data': res
        }

    return response_data